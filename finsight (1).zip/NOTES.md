# FinSight build notes (working memory)

## Decisions
- Next.js 14 App Router + Prisma/MySQL (managed `DATABASE_URL`, normalized to `sslaccept=strict` in `lib/prisma.ts`).
- Forecast: `lib/forecast.ts` (1000-path Monte Carlo, deterministic seed) is the live engine. Python FastAPI service still TODO in `services/forecast/`.
- AI: `lib/ai.ts` tries Sarvam (`SARVAM_API_KEY`) then platform LLM (`MANUS_API_URL`/`MANUS_API_KEY`, model gpt-5-mini) then offline strings. STT: Sarvam else platform `whisper-1`. TTS: Sarvam else browser speechSynthesis (`lib/speech.ts`).
- Auth: JWT `finsight_session`, jose, cookie `SameSite=None;Secure` except localhost.
- i18n: `lib/i18n/messages/*.json` (en + 10 generated, 334 keys each), `lib/i18n/index.ts` loader.
- Seed: `scripts/seed.mjs` → `lib/demo-seed.mjs` (`DEMOS`, `seedDemoUser`) + `lib/simulate-history.mjs`. Already seeded 3 demo users (222/197/479 txns).
- Demo logins: demo.salaried@finsight.app / 9000000001, demo.irregular@ / 9000000002, demo.business@ / 9000000003.

## Built so far
- lib: prisma, types, dates, money, session, auth, categories, categorize, recurring, anomaly, forecast, limits, health, simulator, finance (snapshot+cache), payments (preview/commit), ai, sarvam, speech, utils, api.
- api routes: health, auth/{signup,login,demo,logout}, settings, onboarding, bank/{accounts,passbook,pay}, transactions, forecast, budget, simulator, alerts, coach, voice/{stt,tts,label}, business, goals, runway, export/csv, demo/{trigger,reset}.
- ui: button, card, input, badge, dialog, select, controls (slider/switch/tabs/tooltip/progress), count-up.
- shell: app-shell (sidebar/topbar/bottom tabs/floating mic), language-switcher, providers (i18n/theme/toast).
- voice assistant provider + modal, payment provider + impulse/anomaly modals.
- charts: ForecastChart, CategoryDonut, HealthRing, RunwayGauge, BudgetBars, BacktestChart, HeroSpark.
- views: landing, onboarding, dashboard.
- pages: `/`, `/onboarding`, `(app)/layout`.

## Remaining
1. `app/(app)/dashboard/page.tsx` (build DashboardData from `getFinanceSnapshot`).
2. `/transactions` page + view (filters, table, category edit, simulate payment).
3. `/forecast` page + view (30/60/90, shortage, drivers, backtest card).
4. `/budget` page + view (limit cards, why panels, suggestions).
5. `/simulator` page + view (tabs, sliders, before/after chart, verdict).
6. `/runway` page + view (gauge, target form, plan, voice).
7. `/business` page + view (sales/expense log, udhaar, borrowed, reminder, P&L).
8. `/coach` page + view (chat, suggestions, mic, TTS).
9. `/alerts` page + view.
10. `/settings` page + view (profile, income, obligations, language, voice, theme, reset, CSV export, logout).
11. `services/forecast/` FastAPI + README, Dockerfile, `.env.example` (done), README with demo script.
12. `app.config.ts` logoUrl, `Dockerfile`, deploy config, checkpoint/publish.
13. tsc + build + screenshots; fix errors.

## Notes
- `pnpm tsc --noEmit` currently passes except fixed onboarding issue; LSP Prisma warnings are stale.
- Dev server not started yet. Start `pnpm dev` on port 3000 (service=true).
- `useI18n` `t()` keys come from en.json.
