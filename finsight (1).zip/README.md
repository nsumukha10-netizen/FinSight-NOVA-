# FinSight — AI Financial Operating System

FinSight forecasts your cash flow, warns you before the money runs out, and explains every number in your own Indian language. It is built for three people: the salaried professional with a month-end squeeze, the freelancer with lumpy income, and the small shop owner juggling daily sales and customer credit.

> Simulated banking data only. No real bank account is connected, and nothing here is regulated financial advice.

## What it does

| Problem statement | Where it lives in FinSight |
| --- | --- |
| Predict cash flow and warn before money runs out | `/dashboard` banner, `/forecast` 30/60/90-day cone, shortage probability and money-empty date |
| Detect overspending, impulse buys and unusual transactions | Payment pipeline in `/transactions` (Spending Checkpoint + "Is this you?" anomaly review), `/alerts` |
| Personalized spending limits with explanations | `/budget` — needs/wants/savings allocation, per-category limits, "Why this limit?" |
| Explainable AI recommendations | "Why this forecast?" panel, limit reasons, simulator verdict reasons |
| What-if simulator | `/simulator` — large purchase, new loan, EMI prepayment, salary change, with before/after paths |
| Voice assistant for expense capture | Floating mic on every page; after a payment it asks *"Whose name should I record this expense under?"* and stores the answer as a payee label |
| Indian language support | 11 languages (English, हिन्दी, ಕನ್ನಡ, தமிழ், తెలుగు, മലയാളം, मराठी, বাংলা, ગુજરાતી, ਪੰਜਾਬੀ, ଓଡ଼ିଆ), switchable at signup and in Settings |
| Survival runway for irregular earners | `/runway` — 3-month survival target, days of runway, red/amber/green gauge, income smoothing plan, "Hear this chart" |
| Business cash-flow and credit tracking | `/business` — daily sales, expenses, Udhaar ledger, borrowed money, due reminders, WhatsApp-style reminder text, profit summary |
| Multilingual money coach | `/coach` — text and voice chat about saving, SIPs, mutual funds, stocks, emergency funds, debt |
| Forecast accuracy panel | Backtest card on `/forecast` (MAPE, MAE, 80% band hit rate) |
| Bonus | Financial Health Score, savings goals, notifications, dark/light theme, CSV export, one-click demo mode |

## Stack

- **Next.js 14 App Router + TypeScript** for the UI and API routes
- **Tailwind CSS**, shadcn-style primitives, **Framer Motion**, **Recharts** and **Lucide** icons
- **Prisma ORM** on the managed MySQL database (SQLite is a one-line provider change for a local run)
- **JWT in an httpOnly cookie** for email + phone sessions — no external auth provider
- **Sarvam AI** (server-side only) for chat, speech-to-text, text-to-speech and translation
- **Optional FastAPI service** in `services/forecast` for the Python/pandas/numpy/statsmodels variant of the forecast; the TypeScript Monte Carlo engine is the default and needs no Python

## Run it

```bash
pnpm install
cp .env.example .env          # then fill JWT_SECRET (and SARVAM_API_KEY if you have one)
pnpm prisma migrate deploy    # or: pnpm prisma db push
pnpm db:seed                  # three demo personas, six months of history each
pnpm dev                      # http://localhost:3000
```

One command for production:

```bash
pnpm build && pnpm start
```

The app reads `DATABASE_URL` from the environment. In the Manus Cloud project it is provided automatically; for a local run point it at your own MySQL (or switch the Prisma provider to `sqlite` and use `file:./dev.db`).

### Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | yes | Prisma connection string (managed by the platform in Cloud) |
| `JWT_SECRET` | yes in production | Signs the session cookie; a development fallback exists but is not for production |
| `SARVAM_API_KEY` | optional | Enables Sarvam chat, STT, TTS and translation. Without it the app uses the platform LLM for chat and the browser's speech engine for voice |
| `FORECAST_SERVICE_URL` | optional | Points `/api/forecast` at the FastAPI service instead of the TypeScript engine |
| `MANUS_API_URL`, `MANUS_API_KEY` | platform-provided | Built-in LLM fallback used when Sarvam is not configured |

`.env` is gitignored; `.env.example` documents the keys. No key is ever imported into a client component — every Sarvam call goes through a server route.

## Demo script for judges (3 minutes)

1. Open the landing page and pick **Salaried**, or press **Try demo mode** on the right. The dashboard loads with a live cash-crunch banner.
2. Point at the banner: *"Your balance may hit zero around 23 Nov. 95% of 1,000 simulations end below zero."* Open **Why this forecast?** to show the drivers and the backtest.
3. Go to **Passbook** and press **Swiggy payment** (visible only for demo users). The Spending Checkpoint shows food-delivery spend vs limit, the health score and two clear buttons. Press **Continue** and the payment is committed.
4. Press **₹48,000 unknown** on the dashboard (or open Alerts). The "Is this you?" modal explains the new payee, the 2:14 AM timestamp and the size vs your usual transfers.
5. Use the floating mic: *"Whose name should I record this expense under?"* → say a name → the label appears on the transaction. Then ask the coach *"How do I build an emergency fund?"* in Hindi or Tamil.
6. Switch the language in the top bar. The shell, pages and coach follow.
7. Switch to the **Freelancer** persona (`/demo/irregular`) → **Runway**: 8 days, red gauge, a 2-month plan, and **Hear this chart**.
8. Switch to **Small business** (`/demo/business`) → **Business hub**: sales, expenses, Udhaar, borrowed money, reminder generator and profit.
9. Open **What-if** and simulate a ₹25,000 purchase; the verdict, the reasons and the before/after cone update.
10. Open **Settings** to show language, voice, theme, obligations and the demo reset.

### Demo accounts

| Persona | Email | Phone |
| --- | --- | --- |
| Salaried | `demo.salaried@finsight.app` | `9000000001` |
| Freelancer / student | `demo.irregular@finsight.app` | `9000000002` |
| Small business | `demo.business@finsight.app` | `9000000003` |

Sign in with the email and phone above, or use `/demo/salaried`, `/demo/irregular`, `/demo/business`. Signup creates a fresh account and an onboarding wizard with a simulated passbook import.

## How the forecast works

1. **Recurring detection** groups transactions by normalized payee, keeps groups with a stable interval and less than 10% amount variance, and projects each one onto its due date.
2. **Variable spend** is modelled per weekday from the last 120 days (a Holt-style weekday profile), with anomalies excluded so one ₹48,000 transfer does not poison the baseline.
3. **Income** is modelled from the salary credit day for salaried users and from the historical lump-sum distribution for irregular users.
4. **1,000 Monte Carlo paths** draw a daily spend factor (σ ≈ 22%), a salary factor (σ ≈ 6%), Poisson large purchases and the recurring bills. The 10th/50th/90th percentiles form the cone; the share of paths below zero is the shortage probability, and the median first-negative day is the money-empty date.
5. **Backtest**: the same model is fitted on the first 136 days and scored on the last 30 against the real balance — MAPE, MAE and the share of actual points inside the 80% band.

The FastAPI variant in `services/forecast` mirrors steps 2–4 with numpy; run it with `pnpm forecast:service` and set `FORECAST_SERVICE_URL` to compare.

## Project structure

```
app/
  (app)/            authenticated shell: dashboard, transactions, forecast, budget,
                    simulator, runway, business, coach, alerts, settings
  api/              auth, bank (accounts/passbook/pay), transactions, forecast, budget,
                    simulator, alerts, coach, voice (stt/tts/label), business, goals,
                    runway, obligations, settings, onboarding, export, demo, health
  demo/[persona]/   shareable demo entry links
  onboarding/       persona wizard
  welcome/          public landing (also reachable at / when signed out)
components/
  charts/           SVG forecast cone, backtest, donut, health ring, runway gauge, budget bars
  shell/            sidebar, mobile tab bar, top bar, language switcher
  payments/         payment pipeline modals (impulse guard, anomaly review)
  ui/               shadcn-style primitives
  views/            one client view per page
lib/
  forecast.ts       Monte Carlo engine + backtest
  recurring.ts      recurring detection
  categorize.ts     rules + learned merchant corrections + LLM fallback
  anomaly.ts        z-scores and payment rules
  limits.ts         50/30/20 limits adjusted by obligations and persona
  health.ts         weighted 0–100 score
  simulator.ts      what-if scenarios
  finance.ts        snapshot assembly shared by pages and APIs
  sarvam.ts         server-side Sarvam client
  ai.ts             Sarvam → platform LLM → deterministic fallback
  i18n/             11 dictionaries + provider
prisma/             schema and the initial migration
scripts/            seed, seed-if-empty, i18n generator
services/forecast/  optional FastAPI service
```

## API surface

All routes are JSON and authenticate with the `finsight_session` cookie (or a `Bearer` token).

```
POST /api/auth/signup | /api/auth/login | /api/auth/demo | /api/auth/logout
GET  /api/bank/accounts        GET /api/bank/passbook?from=&to=
POST /api/bank/pay             body: { amount, payee, category, note, decision }
GET  /api/transactions         POST /api/transactions     PATCH /api/transactions
GET  /api/forecast?horizon=30|60|90
GET  /api/budget
POST /api/simulator            body: { kind, amount, interest?, months? }
GET  /api/alerts               PATCH /api/alerts
POST /api/coach                body: { message, history }
POST /api/voice/stt            multipart audio → transcript
POST /api/voice/tts            body: { text } → base64 audio or a browser-speech signal
POST /api/voice/label          body: { transactionId, label }
GET  /api/business             POST /api/business (sale, expense, credit, payment, borrow, repay)
GET  /api/goals  POST /api/goals  GET /api/runway  POST /api/runway
GET  /api/settings  PATCH /api/settings  PUT /api/obligations
POST /api/onboarding
GET  /api/export/csv
POST /api/demo/trigger         body: { kind: "swiggy" | "unknown" }
POST /api/demo/reset
GET  /api/health
```

## Voice and language notes

- Every Sarvam call is server-side: chat (`sarvam-m`), STT (`saarika:v2.5`), TTS (`bulbul:v2`), translate (`mayura:v1`).
- Without a Sarvam key the coach still answers through the built-in LLM, the UI still translates from the bundled dictionaries, and TTS falls back to `speechSynthesis` with the closest installed Indic voice.
- The mic uses `MediaRecorder`; the recorded blob is posted to `/api/voice/stt` and is not stored.
- The coach never guarantees returns, never gives a certain stock tip, and always adds a one-line disclaimer.

## Deployment

The included `Dockerfile` installs dependencies, generates the Prisma client, builds Next.js, applies migrations, seeds demo data only when the database is empty, and serves on `PORT` (3000). The platform health check is `GET /api/health` (always 200, no auth, no database dependency).

```bash
docker build -t finsight .
docker run -p 3000:3000 -e DATABASE_URL=... -e JWT_SECRET=... finsight
```

## Known limitations

- Banking is simulated: no account aggregator or real bank connection.
- The Sarvam key is not bundled. Add `SARVAM_API_KEY` to unlock native Sarvam voices; until then the fallbacks described above apply.
- The managed MySQL database is shared by preview and production, so the demo personas are shared too. **Reset demo data** in Settings restores the seeded six-month history.
- GST filing, invoicing and multi-user business roles are out of scope; the business hub is a single-owner ledger.
- The FastAPI service is optional and not started by the container; it is documented for teams that want the pandas/statsmodels variant.
