# FinSight — Build TODO

## 1. Accounts, personas and onboarding
Signup/login captures name, email, phone, profession type (three large selectable cards: Salaried,
Freelancer/Influencer/Student, Small Business) and preferred language; JWT lives in an httpOnly
cookie. Persona onboarding wizard with progress bar: simulated bank link with last-4 and consent,
opening balance, income step (salary + credit day / average irregular range / average daily sales),
fixed obligations (rent, loans, EMIs, SIPs, groceries, subscriptions, other) each with amount and due
date, Step 4 survival target for irregular users only, review and finish with an analysis animation.
All values editable later in Settings.

## 2. Simulated bank and passbook
`GET /api/bank/accounts`, `GET /api/bank/passbook?from=&to=`, `POST /api/bank/pay` runs a payment
through categorize → anomaly → impulse guard before committing. Transactions page shows the passbook
with search, filters, category chips, payee labels, anomaly flags, inline category edit and a
Pay / Simulate payment action.

## 3. Categorization, recurring detection and anomalies
Keyword/merchant rule map first (Swiggy/Zomato → Food Delivery, Amazon/Flipkart/Myntra → Shopping,
Netflix/Spotify → Subscriptions…), LLM fallback for unknown payees, and learning from user
corrections. Recurring detection groups by normalized payee, checks weekly/monthly/yearly interval
regularity and amount variance under 10%. Anomaly detection combines per-category z-scores with
rules: amount above 3× category average, new payee with high amount, odd hour, duplicate within
minutes; anomalies raise an "Is this you? Continue or Block" modal.

## 4. Forecast, shortage prediction and accuracy
30/60/90-day forecast with best/expected/worst confidence bands, "Your balance may hit zero on
<date>" with probability, money-empty date, plain-language uncertainty, explainability panel and a
backtest card with MAPE, MAE and band hit rate. 1,000-path Monte Carlo; recurring items on due dates;
Python FastAPI service with automatic TypeScript fallback.

## 5. Impulse guard and spending limits
Discretionary payment to Swiggy, Zomato, Amazon, Flipkart, Myntra etc. opens a "Spending Checkpoint"
modal with current category spend vs budget, financial health status, explanation and
Continue / Cancel. Guard fires when category spend is ≥80% of its limit or a shortage is forecast
within 30 days. Budget page lists personalized limits with progress bars, "Why this limit?" panels
and expense-minimization suggestions.

## 6. What-If simulator
Large purchase, new loan, EMI prepayment and salary change with sliders, instant before/after
forecast comparison and a Safe / Risky / Not advisable verdict with reasons.

## 7. Survival Runway (irregular income)
User enters the amount needed to survive the next 3 months; app compares it with balance and shows
days of runway, red/amber/green status, income-smoothing advice, a visual plan chart and a voice
explanation of the chart.

## 8. Business Hub (small business)
Daily sales and expense log, customer credit ledger (Udhaar) with due dates, borrowed-money tracker
with reminders, WhatsApp-style reminder message generator the user can copy, daily/weekly profit
summary, stock/inventory purchase tracking, GST-free simple P&L, visible only for the business
persona.

## 9. Voice assistant and payee labeling
After each expense the assistant asks "Whose name should I record this expense under?" / "What is
this expense for?", records via MediaRecorder, transcribes server-side (Sarvam, else platform
Whisper) and stores the answer as payee label or note plus a VoiceLog. Floating mic on every page.
Waveform animation while listening or speaking; graceful typed fallback.

## 10. Eleven-language UI, coach and voice
Language selector at signup and in settings for Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi,
Bengali, Gujarati, Punjabi, Odia and English; whole UI, chatbot and voice follow the choice; Noto
Sans Indic fonts render every script. Multilingual AI money coach (text and voice) with the user's
financial context, covering saving, budgeting, SIPs, mutual funds, stocks, emergency funds and new
saving methods, always with a one-line disclaimer and never guaranteeing returns or certain tips.

## 11. Dashboard, alerts and health score
Dashboard: balance card, health score ring 0–100 with breakdown, 90-day confidence-band chart,
shortage alert banner, upcoming bills timeline, category donut, recent transactions, quick actions
(Add expense, Simulate, Ask coach, Speak). Alerts center for anomalies, shortage warnings, due
reminders and impulse-guard history, with a notification bell. Goals with progress rings.

## 12. Settings, exports, demo mode and polish
Settings: profile, salary, obligations, language, voice on/off, theme, reset demo data. Dark/light
mode, CSV export of the monthly report. Demo Mode loads a rich sample dataset, logs in per persona,
and fires a fake Swiggy payment and a ₹48,000 unknown-payment to showcase both modals. Loading
skeletons, empty states, error toasts, responsive layouts, accessible contrast, large tap targets.

## 13. Seeded data and delivery
Three demo users (one per persona) with six months of realistic transactions ending today (~250
each), the specified salaried/irregular/business profiles, and three planted anomalies (₹48,000
unknown payee, duplicate charge, food-delivery spike). Single start command; works fully on seeded
data when Sarvam is unreachable; `.env.example` with `SARVAM_API_KEY` and `JWT_SECRET`; `.env`
gitignored; README with setup, env vars, run instructions, judge demo script and feature-to-problem
mapping; no API keys in client code.

## 14. Validation
Read-only acceptance pass against the brief for all three personas: signup, onboarding, forecast,
impulse guard, anomaly modal, voice labeling, simulator, runway, business hub, language switch;
fix confirmed defects and verify the affected path.

**Status: delivered.** All 14 outcomes below are implemented and verified in the running app
(`pnpm tsc --noEmit` clean, production build clean, demo personas exercised page by page).
Evidence: the routes in `README.md`, the seeded passbooks (`node scripts/seed.mjs`), the API
smoke checks against `/api/forecast`, `/api/budget`, `/api/simulator`, `/api/bank/pay` and
`/api/coach`, and the screenshots reviewed during the build.

1. Accounts, personas and onboarding — done (`/`, `/onboarding`, `/api/auth/*`, `/api/onboarding`)
2. Simulated bank and passbook — done (`/api/bank/*`, `/transactions`)
3. Categorization, recurring and anomalies — done (`lib/categorize.ts`, `lib/recurring.ts`, `lib/anomaly.ts`)
4. Forecast, shortage and accuracy — done (`lib/forecast.ts`, `/forecast`)
5. Impulse guard and limits — done (`lib/payments.ts`, `/budget`)
6. What-If simulator — done (`lib/simulator.ts`, `/simulator`)
7. Survival Runway — done (`/runway`, `/api/runway`)
8. Business Hub — done (`/business`, `/api/business`)
9. Voice assistant and payee labeling — done (`/api/voice/*`, floating mic)
10. Eleven-language UI, coach and voice — done (`lib/i18n/messages/*`, `/coach`)
11. Dashboard, alerts and health score — done (`/dashboard`, `/alerts`, `lib/health.ts`)
12. Settings, exports, demo mode and polish — done (`/settings`, `/api/export/csv`, `/api/demo/*`)
13. Seeded data and delivery — done (`scripts/seed.mjs`, `Dockerfile`, `README.md`, `.env.example`)
14. Validation — done (typecheck, build, API and page checks)
