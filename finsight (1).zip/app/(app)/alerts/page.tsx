import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { AlertsView } from "@/components/views/alerts-view";

export const dynamic = "force-dynamic";

export default async function AlertsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const alerts = await prisma.alert.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 60 });

  return (
    <AlertsView
      initial={alerts.map((alert) => ({
        id: alert.id,
        type: alert.type,
        severity: alert.severity,
        message: alert.message,
        explanation: alert.explanation,
        createdAt: alert.createdAt.toISOString(),
        resolved: alert.resolved,
      }))}
    />
  );
}
