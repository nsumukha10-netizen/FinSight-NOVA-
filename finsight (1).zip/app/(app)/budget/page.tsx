import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { BudgetView } from "@/components/views/budget-view";

export const dynamic = "force-dynamic";

export default async function BudgetPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);

  return (
    <BudgetView
      limits={snapshot.limits}
      monthIncome={snapshot.monthIncome}
      monthExpenses={snapshot.monthExpenses}
      health={snapshot.health}
      shortageWithin30={(snapshot.forecast.cumulativeShortage[29] ?? 0) >= 0.3}
    />
  );
}
