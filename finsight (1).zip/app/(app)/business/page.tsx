import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { addDays, startOfDay } from "@/lib/dates";
import { BusinessView } from "@/components/views/business-view";

export const dynamic = "force-dynamic";

export default async function BusinessPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  if (user.persona !== "BUSINESS") redirect("/dashboard");

  const since = addDays(new Date(), -30);
  const [entries, credits, borrowed] = await Promise.all([
    prisma.businessEntry.findMany({ where: { userId: user.id, date: { gte: since } }, orderBy: { date: "desc" } }),
    prisma.customerCredit.findMany({ where: { userId: user.id }, orderBy: { dueDate: "asc" } }),
    prisma.borrowedMoney.findMany({ where: { userId: user.id }, orderBy: { dueDate: "asc" } }),
  ]);

  const today = startOfDay(new Date());
  const weekStart = addDays(today, -6);
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
  const sum = (kind: "SALE" | "EXPENSE", from: Date) =>
    entries.filter((e) => e.kind === kind && e.date >= from).reduce((total, e) => total + e.amount, 0);

  const data = {
    entries: entries.map((e) => ({
      id: e.id,
      date: e.date.toISOString(),
      kind: e.kind,
      amount: e.amount,
      note: e.note,
      category: e.category,
    })),
    credits: credits.map((c) => ({
      id: c.id,
      customerName: c.customerName,
      phone: c.phone,
      amountOwed: c.amountOwed,
      dueDate: c.dueDate.toISOString(),
      status: c.status,
      lastReminderAt: c.lastReminderAt?.toISOString() ?? null,
      note: c.note,
    })),
    borrowed: borrowed.map((b) => ({
      id: b.id,
      lenderName: b.lenderName,
      amount: b.amount,
      dueDate: b.dueDate.toISOString(),
      status: b.status,
      note: b.note,
    })),
    summary: {
      todaySales: sum("SALE", today),
      weekSales: sum("SALE", weekStart),
      monthSales: sum("SALE", monthStart),
      todayExpenses: sum("EXPENSE", today),
      weekExpenses: sum("EXPENSE", weekStart),
      monthExpenses: sum("EXPENSE", monthStart),
      monthProfit: sum("SALE", monthStart) - sum("EXPENSE", monthStart),
      stockSpend: entries.filter((e) => e.kind === "EXPENSE" && (e.category ?? "").toLowerCase().includes("stock")).reduce((t, e) => t + e.amount, 0),
      outstanding: credits.filter((c) => c.status !== "PAID").reduce((t, c) => t + c.amountOwed, 0),
      borrowedTotal: borrowed.filter((b) => b.status !== "PAID").reduce((t, b) => t + b.amount, 0),
    },
  };

  return <BusinessView initial={data} shopName={user.name.split(" ")[0] + "'s store"} />;
}
