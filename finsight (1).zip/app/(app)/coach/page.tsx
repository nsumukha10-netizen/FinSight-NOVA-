import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { CoachView } from "@/components/views/coach-view";

export const dynamic = "force-dynamic";

export default async function CoachPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  return <CoachView name={user.name} voiceEnabled={user.voiceEnabled} />;
}
