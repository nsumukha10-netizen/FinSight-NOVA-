import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { DashboardView } from "@/components/views/dashboard-view";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);

  return (
    <DashboardView
      data={{
        name: user.name,
        persona: user.persona,
        isDemo: user.isDemo,
        balance: snapshot.balance,
        bankName: snapshot.bankName,
        last4: snapshot.last4,
        monthIncome: snapshot.monthIncome,
        monthExpenses: snapshot.monthExpenses,
        monthlyObligations: snapshot.monthlyObligations,
        runwayDays: snapshot.runwayDays,
        health: snapshot.health,
        forecast: {
          points: snapshot.forecast.points,
          shortageDate: snapshot.forecast.shortageDate,
          shortageProbability: snapshot.forecast.shortageProbability,
          endP50: snapshot.forecast.endP50,
          endP10: snapshot.forecast.endP10,
          endP90: snapshot.forecast.endP90,
          cumulativeShortage: snapshot.forecast.cumulativeShortage,
        },
        limits: snapshot.limits.map((l) => ({ category: l.category, monthlyLimit: l.monthlyLimit, spent: l.spent })),
        spendByCategory: snapshot.spendByCategory,
        upcomingBills: snapshot.upcomingBills.slice(0, 6).map((b) => ({
          name: b.name,
          amount: b.amount,
          dueDate: b.dueDate,
          daysAway: b.daysAway,
        })),
        recent: snapshot.transactions.slice(-8).reverse().map((t) => ({
          id: t.id,
          date: t.date,
          amount: t.amount,
          type: t.type,
          payee: t.payee,
          category: t.category,
          isAnomaly: t.isAnomaly,
          voiceLabel: t.voiceLabel,
        })),
        goals: snapshot.goals.map((g) => ({ id: g.id, name: g.name, targetAmount: g.targetAmount, savedAmount: g.savedAmount })),
      }}
    />
  );
}
