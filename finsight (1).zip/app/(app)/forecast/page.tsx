import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { ForecastView } from "@/components/views/forecast-view";

export const dynamic = "force-dynamic";

export default async function ForecastPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);
  const f = snapshot.forecast;

  return (
    <ForecastView
      data={{
        balance: snapshot.balance,
        points: f.points,
        cumulativeShortage: f.cumulativeShortage,
        shortageDate: f.shortageDate,
        shortageProbability: f.shortageProbability,
        moneyEmptyDate: f.moneyEmptyDate,
        endP50: f.endP50,
        endP10: f.endP10,
        endP90: f.endP90,
        drivers: f.drivers,
        engine: f.engine,
        incomeModel: f.incomeModel,
        dailySpendMean: f.dailySpendMean,
        monthlyFixed: f.monthlyFixed,
        backtest: snapshot.backtest,
      }}
    />
  );
}
