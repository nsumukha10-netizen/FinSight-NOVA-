import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { AppShell } from "@/components/shell/app-shell";
import type { PersonaKey } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  if (!user.onboarded) redirect("/onboarding");

  const alertCount = await prisma.alert.count({ where: { userId: user.id, resolved: false } });

  return (
    <AppShell
      user={{ id: user.id, name: user.name, persona: user.persona as PersonaKey, isDemo: user.isDemo }}
      alertCount={alertCount}
    >
      {children}
    </AppShell>
  );
}
