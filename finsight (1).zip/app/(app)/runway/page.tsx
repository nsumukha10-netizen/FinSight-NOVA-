import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { RunwayView } from "@/components/views/runway-view";

export const dynamic = "force-dynamic";

export default async function RunwayPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);

  const monthlyNeed = user.survivalTarget ? user.survivalTarget / 3 : Math.max(1, snapshot.monthExpenses);
  const runwayDays = Math.round((snapshot.balance / monthlyNeed) * 30);
  const status = runwayDays >= 90 ? "green" : runwayDays >= 30 ? "amber" : "red";

  const byMonth = new Map<string, number>();
  for (const tx of snapshot.transactions) {
    if (tx.type !== "CREDIT") continue;
    const key = tx.date.slice(0, 7);
    byMonth.set(key, (byMonth.get(key) ?? 0) + tx.amount);
  }
  const monthlyValues = [...byMonth.values()];
  const bestMonth = monthlyValues.length ? Math.max(...monthlyValues) : 0;
  const positiveMonths = monthlyValues.filter((value) => value >= monthlyNeed).length;

  return (
    <RunwayView
      data={{
        balance: snapshot.balance,
        monthlyNeed,
        runwayDays,
        status,
        survivalTarget: user.survivalTarget ?? 0,
        avgIncome: snapshot.monthlyIncome,
        bestMonth,
        positiveMonths,
        totalMonths: Math.max(1, monthlyValues.length),
        persona: user.persona,
      }}
    />
  );
}
