import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { SettingsView } from "@/components/views/settings-view";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const obligations = await prisma.obligation.findMany({ where: { userId: user.id }, orderBy: { dueDay: "asc" } });

  return (
    <SettingsView
      data={{
        name: user.name,
        email: user.email,
        phone: user.phone,
        persona: user.persona,
        monthlyIncome: user.monthlyIncome,
        incomeDay: user.incomeDay,
        survivalTarget: user.survivalTarget ?? 0,
        dailySales: user.dailySales ?? 0,
        voiceEnabled: user.voiceEnabled,
        isDemo: user.isDemo,
        obligations: obligations.map((o) => ({ name: o.name, type: o.type, amount: o.amount, dueDay: o.dueDay })),
      }}
    />
  );
}
