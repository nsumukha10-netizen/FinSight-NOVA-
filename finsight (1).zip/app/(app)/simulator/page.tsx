import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { SimulatorView } from "@/components/views/simulator-view";

export const dynamic = "force-dynamic";

export default async function SimulatorPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);
  return <SimulatorView balance={snapshot.balance} monthlyIncome={snapshot.monthlyIncome} />;
}
