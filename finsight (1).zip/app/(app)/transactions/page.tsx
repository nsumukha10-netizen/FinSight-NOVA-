import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getFinanceSnapshot } from "@/lib/finance";
import { TransactionsView } from "@/components/views/transactions-view";

export const dynamic = "force-dynamic";

export default async function TransactionsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const snapshot = await getFinanceSnapshot(user.id);
  const rows = snapshot.transactions
    .slice(-320)
    .reverse()
    .map((t) => ({
      id: t.id,
      date: t.date,
      amount: t.amount,
      type: t.type,
      payee: t.payee,
      rawDescription: t.rawDescription,
      category: t.category,
      isRecurring: t.isRecurring,
      isAnomaly: t.isAnomaly,
      anomalyReason: t.anomalyReason,
      voiceLabel: t.voiceLabel,
      note: t.note,
      balanceAfter: t.balanceAfter,
    }));

  return <TransactionsView transactions={rows} isDemo={user.isDemo} />;
}
