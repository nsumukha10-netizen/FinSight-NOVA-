import { prisma } from "@/lib/prisma";
import { fail, json, requireApiUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const alerts = await prisma.alert.findMany({ where: { userId: auth.user.id }, orderBy: { createdAt: "desc" }, take: 60 });
  return json({
    alerts: alerts.map((a) => ({
      id: a.id,
      type: a.type,
      severity: a.severity,
      message: a.message,
      explanation: a.explanation,
      createdAt: a.createdAt.toISOString(),
      resolved: a.resolved,
    })),
  });
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = String(body.id ?? "");
  if (!id) return fail("id_required");
  const alert = await prisma.alert.findFirst({ where: { id, userId: auth.user.id } });
  if (!alert) return fail("not_found", 404);
  await prisma.alert.update({ where: { id }, data: { resolved: body.resolved === false ? false : true } });
  return json({ ok: true });
}
