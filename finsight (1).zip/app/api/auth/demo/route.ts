import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import { SESSION_COOKIE, cookieOptions, signSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const persona = String(body.persona ?? "SALARIED");
  const user = await prisma.user.findFirst({
    where: { isDemo: true, persona: persona as "SALARIED" | "IRREGULAR" | "BUSINESS" },
  });
  if (!user) return NextResponse.json({ error: "demo_not_seeded" }, { status: 404 });

  const token = await signSession(user.id);
  const response = NextResponse.json({ ok: true, redirect: "/dashboard", persona: user.persona });
  response.cookies.set(SESSION_COOKIE, token, cookieOptions(headers().get("host")));
  response.cookies.set("finsight_lang", user.language, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  return response;
}
