import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import { SESSION_COOKIE, cookieOptions, signSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const email = String(body.email ?? "").trim().toLowerCase();
  const phone = String(body.phone ?? "").replace(/\D/g, "");
  if (!email || !phone) return NextResponse.json({ error: "invalid_input" }, { status: 400 });

  const user = await prisma.user.findFirst({ where: { email, phone } });
  if (!user) return NextResponse.json({ error: "invalid_credentials" }, { status: 401 });

  const token = await signSession(user.id);
  const response = NextResponse.json({ ok: true, redirect: user.onboarded ? "/dashboard" : "/onboarding" });
  response.cookies.set(SESSION_COOKIE, token, cookieOptions(headers().get("host")));
  response.cookies.set("finsight_lang", user.language, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  return response;
}
