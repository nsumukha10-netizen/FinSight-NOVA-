import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import { SESSION_COOKIE, cookieOptions, signSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim().toLowerCase();
  const phone = String(body.phone ?? "").replace(/\D/g, "");
  const persona = String(body.persona ?? "");
  const language = String(body.language ?? "en");

  if (!name || !email || !phone || !["SALARIED", "IRREGULAR", "BUSINESS"].includes(persona)) {
    return NextResponse.json({ error: "invalid_input" }, { status: 400 });
  }

  const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { phone }] } });
  if (existing) return NextResponse.json({ error: "already_exists" }, { status: 409 });

  const user = await prisma.user.create({
    data: { name, email, phone, persona: persona as "SALARIED" | "IRREGULAR" | "BUSINESS", language },
  });

  const token = await signSession(user.id);
  const response = NextResponse.json({ ok: true, redirect: "/onboarding" });
  const options = cookieOptions(headers().get("host"));
  response.cookies.set(SESSION_COOKIE, token, options);
  response.cookies.set("finsight_lang", language, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  return response;
}
