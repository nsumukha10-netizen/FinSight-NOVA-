import { prisma } from "@/lib/prisma";
import { json, requireApiUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const accounts = await prisma.bankAccount.findMany({ where: { userId: auth.user.id } });
  return json({
    accounts: accounts.map((a) => ({
      id: a.id,
      bankName: a.bankName,
      last4: a.last4,
      balance: a.balance,
      linkedAt: a.linkedAt.toISOString(),
    })),
  });
}
