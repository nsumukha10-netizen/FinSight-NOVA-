import { prisma } from "@/lib/prisma";
import { json, requireApiUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const url = new URL(request.url);
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");

  const transactions = await prisma.transaction.findMany({
    where: {
      userId: auth.user.id,
      ...(from || to
        ? {
            date: {
              ...(from ? { gte: new Date(from) } : {}),
              ...(to ? { lte: new Date(`${to}T23:59:59`) } : {}),
            },
          }
        : {}),
    },
    orderBy: { date: "desc" },
    take: 500,
  });

  return json({
    from: from ?? null,
    to: to ?? null,
    count: transactions.length,
    transactions: transactions.map((t) => ({
      id: t.id,
      date: t.date.toISOString(),
      amount: t.amount,
      type: t.type,
      payee: t.payee,
      rawDescription: t.rawDescription,
      category: t.category,
      isRecurring: t.isRecurring,
      isAnomaly: t.isAnomaly,
      anomalyScore: t.anomalyScore,
      anomalyReason: t.anomalyReason,
      voiceLabel: t.voiceLabel,
      note: t.note,
      balanceAfter: t.balanceAfter,
    })),
  });
}
