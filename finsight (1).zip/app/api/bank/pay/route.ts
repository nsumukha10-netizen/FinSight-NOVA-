import { fail, json, num, requireApiUser } from "@/lib/api";
import { commitPayment, previewPayment } from "@/lib/payments";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const payee = String(body.payee ?? "").trim();
  const amount = Math.abs(num(body.amount, 0));
  if (!payee || amount <= 0) return fail("payee_and_amount_required");

  const payload = {
    payee,
    amount,
    category: typeof body.category === "string" && body.category ? body.category : undefined,
    note: typeof body.note === "string" ? body.note : undefined,
    date: typeof body.date === "string" ? body.date : undefined,
  };

  if (body.confirm === true) {
    const result = await commitPayment(user, payload, {
      reviewed: true,
      reviewNote: typeof body.reviewNote === "string" ? body.reviewNote : undefined,
    });
    return json({
      ok: true,
      committed: true,
      transactionId: result.transaction.id,
      balance: result.balanceAfter,
      category: result.review.category,
      review: result.review,
    });
  }

  const review = await previewPayment(user, payload);
  return json({ ok: true, committed: false, review });
}
