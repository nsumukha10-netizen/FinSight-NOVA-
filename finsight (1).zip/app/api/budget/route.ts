import { json, requireApiUser } from "@/lib/api";
import { getFinanceSnapshot } from "@/lib/finance";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const snapshot = await getFinanceSnapshot(auth.user.id);
  return json({
    limits: snapshot.limits,
    spendByCategory: snapshot.spendByCategory,
    monthIncome: snapshot.monthIncome,
    monthExpenses: snapshot.monthExpenses,
    health: snapshot.health,
    shortageWithin30: (snapshot.forecast.cumulativeShortage[29] ?? 0) >= 0.3,
  });
}
