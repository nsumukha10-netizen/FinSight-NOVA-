import { prisma } from "@/lib/prisma";
import { fail, json, num, requireApiUser } from "@/lib/api";
import { invalidateFinance } from "@/lib/finance";
import { addDays, startOfDay } from "@/lib/dates";

export const dynamic = "force-dynamic";

async function hubData(userId: string) {
  const since = addDays(new Date(), -30);
  const [entries, credits, borrowed] = await Promise.all([
    prisma.businessEntry.findMany({ where: { userId, date: { gte: since } }, orderBy: { date: "desc" } }),
    prisma.customerCredit.findMany({ where: { userId }, orderBy: { dueDate: "asc" } }),
    prisma.borrowedMoney.findMany({ where: { userId }, orderBy: { dueDate: "asc" } }),
  ]);

  const today = startOfDay(new Date());
  const weekStart = addDays(today, -6);
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

  const sum = (list: typeof entries, kind: "SALE" | "EXPENSE", from: Date) =>
    list.filter((e) => e.kind === kind && e.date >= from).reduce((s, e) => s + e.amount, 0);

  const stock = entries.filter((e) => e.kind === "EXPENSE" && (e.category ?? "").toLowerCase().includes("stock"));

  return {
    entries: entries.map((e) => ({
      id: e.id,
      date: e.date.toISOString(),
      kind: e.kind,
      amount: e.amount,
      note: e.note,
      category: e.category,
    })),
    credits: credits.map((c) => ({
      id: c.id,
      customerName: c.customerName,
      phone: c.phone,
      amountOwed: c.amountOwed,
      dueDate: c.dueDate.toISOString(),
      status: c.status,
      lastReminderAt: c.lastReminderAt?.toISOString() ?? null,
      note: c.note,
    })),
    borrowed: borrowed.map((b) => ({
      id: b.id,
      lenderName: b.lenderName,
      amount: b.amount,
      dueDate: b.dueDate.toISOString(),
      status: b.status,
      note: b.note,
    })),
    summary: {
      todaySales: sum(entries, "SALE", today),
      weekSales: sum(entries, "SALE", weekStart),
      monthSales: sum(entries, "SALE", monthStart),
      todayExpenses: sum(entries, "EXPENSE", today),
      weekExpenses: sum(entries, "EXPENSE", weekStart),
      monthExpenses: sum(entries, "EXPENSE", monthStart),
      monthProfit: sum(entries, "SALE", monthStart) - sum(entries, "EXPENSE", monthStart),
      stockSpend: stock.reduce((s, e) => s + e.amount, 0),
      outstanding: credits.filter((c) => c.status !== "PAID").reduce((s, c) => s + c.amountOwed, 0),
      borrowedTotal: borrowed.filter((b) => b.status !== "PAID").reduce((s, b) => s + b.amount, 0),
    },
  };
}

export async function GET() {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  return json(await hubData(auth.user.id));
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const action = String(body.action ?? "");

  if (action === "sale" || action === "expense") {
    const amount = Math.abs(num(body.amount, 0));
    if (!amount) return fail("amount_required");
    await prisma.businessEntry.create({
      data: {
        userId: user.id,
        date: body.date ? new Date(String(body.date)) : new Date(),
        kind: action === "sale" ? "SALE" : "EXPENSE",
        amount,
        note: typeof body.note === "string" ? body.note : null,
        category: typeof body.category === "string" ? body.category : action === "sale" ? "Sales" : "Shop expense",
      },
    });
  } else if (action === "credit") {
    const amount = Math.abs(num(body.amountOwed, 0));
    const name = String(body.customerName ?? "").trim();
    if (!amount || !name) return fail("invalid_credit");
    await prisma.customerCredit.create({
      data: {
        userId: user.id,
        customerName: name,
        phone: typeof body.phone === "string" ? body.phone : null,
        amountOwed: amount,
        dueDate: body.dueDate ? new Date(String(body.dueDate)) : addDays(new Date(), 15),
        note: typeof body.note === "string" ? body.note : null,
      },
    });
  } else if (action === "borrowed") {
    const amount = Math.abs(num(body.amount, 0));
    const lender = String(body.lenderName ?? "").trim();
    if (!amount || !lender) return fail("invalid_borrowed");
    await prisma.borrowedMoney.create({
      data: {
        userId: user.id,
        lenderName: lender,
        amount,
        dueDate: body.dueDate ? new Date(String(body.dueDate)) : addDays(new Date(), 30),
        note: typeof body.note === "string" ? body.note : null,
      },
    });
  } else if (action === "remind") {
    const id = String(body.creditId ?? "");
    const credit = await prisma.customerCredit.findFirst({ where: { id, userId: user.id } });
    if (!credit) return fail("not_found", 404);
    await prisma.customerCredit.update({ where: { id }, data: { lastReminderAt: new Date() } });
    const message = `Namaste ${credit.customerName}, this is a gentle reminder that ₹${credit.amountOwed.toLocaleString("en-IN")} is pending for your purchase, due ${credit.dueDate.toLocaleDateString("en-IN", { day: "numeric", month: "short" })}. Please pay when convenient. Thank you — ${user.name}`;
    return json({ ok: true, message });
  } else if (action === "markPaid") {
    const id = String(body.creditId ?? "");
    const credit = await prisma.customerCredit.findFirst({ where: { id, userId: user.id } });
    if (!credit) return fail("not_found", 404);
    await prisma.customerCredit.update({ where: { id }, data: { status: "PAID", amountOwed: 0 } });
  } else {
    return fail("unknown_action");
  }

  invalidateFinance(user.id);
  return json({ ok: true, ...(await hubData(user.id)) });
}
