import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import { fail, requireApiUser } from "@/lib/api";
import { DEMOS, seedDemoUser } from "@/lib/demo-seed.mjs";
import { SESSION_COOKIE, cookieOptions, signSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST() {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  if (!auth.user.isDemo) return fail("demo_only", 403);

  const demo = DEMOS.find((d: { persona: string }) => d.persona === auth.user.persona);
  if (!demo) return fail("demo_not_found", 404);

  await prisma.user.delete({ where: { id: auth.user.id } });
  await seedDemoUser(prisma, demo);
  const restored = await prisma.user.findUnique({ where: { email: demo.email } });
  if (!restored) return fail("reset_failed", 500);

  const token = await signSession(restored.id);
  const response = NextResponse.json({ ok: true });
  response.cookies.set(SESSION_COOKIE, token, cookieOptions(headers().get("host")));
  return response;
}
