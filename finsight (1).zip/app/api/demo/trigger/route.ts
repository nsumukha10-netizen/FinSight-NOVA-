import { fail, json, requireApiUser } from "@/lib/api";
import { previewPayment } from "@/lib/payments";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const kind = String(body.kind ?? "swiggy");

  const payload =
    kind === "unknown"
      ? { payee: "UPI/UNKNOWN-8842", amount: 48000, note: "Transfer to an unknown payee", category: "Other" }
      : { payee: "Swiggy", amount: 640, note: "Late-night order", category: "Food Delivery" };

  if (!auth.user.isDemo) return fail("demo_only", 403);
  const review = await previewPayment(auth.user, payload);
  return json({ ok: true, kind, review });
}
