import { prisma } from "@/lib/prisma";
import { requireApiUser } from "@/lib/api";
import { endOfMonth, startOfMonth } from "@/lib/dates";

export const dynamic = "force-dynamic";

function escape(value: string | number | null) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const url = new URL(request.url);
  const month = url.searchParams.get("month");
  const base = month ? new Date(`${month}-01T00:00:00`) : new Date();
  const from = startOfMonth(base);
  const to = endOfMonth(base);

  const transactions = await prisma.transaction.findMany({
    where: { userId: auth.user.id, date: { gte: from, lte: to } },
    orderBy: { date: "asc" },
  });

  const header = ["Date", "Payee", "Description", "Category", "Type", "Amount", "Balance after", "Anomaly", "Voice label", "Note"];
  const rows = transactions.map((t) => [
    t.date.toISOString().slice(0, 10),
    t.payee,
    t.rawDescription,
    t.category,
    t.type,
    t.type === "DEBIT" ? -t.amount : t.amount,
    t.balanceAfter,
    t.isAnomaly ? "yes" : "no",
    t.voiceLabel ?? "",
    t.note ?? "",
  ]);

  const csv = "\uFEFF" + [header, ...rows].map((row) => row.map(escape).join(",")).join("\n");
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="finsight-${from.getFullYear()}-${String(from.getMonth() + 1).padStart(2, "0")}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
