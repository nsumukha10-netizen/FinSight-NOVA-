import { json, requireApiUser } from "@/lib/api";
import { getFinanceSnapshot } from "@/lib/finance";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const url = new URL(request.url);
  const horizon = Math.min(90, Math.max(7, Number(url.searchParams.get("horizon") ?? 90) || 90));
  const snapshot = await getFinanceSnapshot(auth.user.id);
  const points = snapshot.forecast.points.slice(0, horizon);
  return json({
    horizon,
    points,
    probByDay: snapshot.forecast.probByDay.slice(0, horizon),
    cumulativeShortage: snapshot.forecast.cumulativeShortage.slice(0, horizon),
    shortageDate: snapshot.forecast.shortageDate,
    shortageProbability: snapshot.forecast.cumulativeShortage[horizon - 1] ?? 0,
    moneyEmptyDate: snapshot.forecast.moneyEmptyDate,
    endP50: points.at(-1)?.p50 ?? snapshot.balance,
    endP10: points.at(-1)?.p10 ?? snapshot.balance,
    endP90: points.at(-1)?.p90 ?? snapshot.balance,
    drivers: snapshot.forecast.drivers,
    engine: snapshot.forecast.engine,
    backtest: snapshot.backtest,
    health: snapshot.health,
    balance: snapshot.balance,
  });
}
