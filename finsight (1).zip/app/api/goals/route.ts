import { prisma } from "@/lib/prisma";
import { fail, json, num, requireApiUser } from "@/lib/api";
import { addDays } from "@/lib/dates";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const name = String(body.name ?? "").trim();
  const targetAmount = Math.abs(num(body.targetAmount, 0));
  if (!name || !targetAmount) return fail("invalid_goal");
  const goal = await prisma.goal.create({
    data: {
      userId: auth.user.id,
      name,
      targetAmount,
      savedAmount: Math.abs(num(body.savedAmount, 0)),
      targetDate: body.targetDate ? new Date(String(body.targetDate)) : addDays(new Date(), 180),
    },
  });
  return json({ ok: true, goal: { id: goal.id } });
}

export async function PATCH(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = String(body.id ?? "");
  const goal = await prisma.goal.findFirst({ where: { id, userId: auth.user.id } });
  if (!goal) return fail("not_found", 404);
  await prisma.goal.update({
    where: { id },
    data: { savedAmount: Math.abs(num(body.savedAmount, goal.savedAmount)) },
  });
  return json({ ok: true });
}
