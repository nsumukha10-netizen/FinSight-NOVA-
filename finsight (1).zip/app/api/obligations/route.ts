import { prisma } from "@/lib/prisma";
import { fail, json, num, requireApiUser } from "@/lib/api";
import { invalidateFinance } from "@/lib/finance";

export const dynamic = "force-dynamic";

const TYPES = ["RENT", "LOAN", "EMI", "SIP", "SUBSCRIPTION", "GROCERY", "OTHER"] as const;

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const rows = Array.isArray(body.obligations) ? body.obligations : null;
  if (!rows) return fail("obligations_required");

  const data = rows
    .map((row) => row as Record<string, unknown>)
    .filter((row) => String(row.name ?? "").trim() && num(row.amount, 0) > 0)
    .slice(0, 20)
    .map((row) => ({
      userId: auth.user.id,
      name: String(row.name).slice(0, 80),
      type: (TYPES.includes(String(row.type) as (typeof TYPES)[number]) ? String(row.type) : "OTHER") as (typeof TYPES)[number],
      amount: Math.round(num(row.amount, 0)),
      dueDay: Math.min(28, Math.max(1, Math.round(num(row.dueDay, 5)))),
    }));

  await prisma.$transaction(async (tx) => {
    await tx.obligation.deleteMany({ where: { userId: auth.user.id } });
    if (data.length) await tx.obligation.createMany({ data });
  });
  invalidateFinance(auth.user.id);
  return json({ ok: true, count: data.length });
}
