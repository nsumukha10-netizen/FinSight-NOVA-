import { prisma } from "@/lib/prisma";
import { fail, json, num, requireApiUser } from "@/lib/api";
import { generateHistory } from "@/lib/simulate-history.mjs";
import { buildLimits } from "@/lib/limits";
import { invalidateFinance } from "@/lib/finance";
import { startOfMonth } from "@/lib/dates";
import type { GeneratedHistory } from "@/lib/types";

export const dynamic = "force-dynamic";

interface Body {
  bank?: { bankName?: string; last4?: string; balance?: number; consent?: boolean };
  income?: { monthlyIncome?: number; incomeDay?: number; incomeMin?: number; incomeMax?: number; dailySales?: number };
  obligations?: { name?: string; type?: string; amount?: number; dueDay?: number }[];
  survivalTarget?: number;
}

const OBLIGATION_TYPES = ["RENT", "LOAN", "EMI", "SIP", "SUBSCRIPTION", "GROCERY", "OTHER"];

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const body = (await request.json().catch(() => ({}))) as Body;

  if (!body.bank?.bankName || !body.bank?.consent) return fail("bank_consent_required");
  const balance = Math.max(0, num(body.bank.balance, 0));
  const monthlyIncome = Math.max(0, num(body.income?.monthlyIncome, 0));
  const incomeDay = Math.min(28, Math.max(1, Math.round(num(body.income?.incomeDay, 1))));
  const dailySales = Math.max(0, num(body.income?.dailySales, 0));

  const obligations = (body.obligations ?? [])
    .filter((o) => o.name && num(o.amount, 0) > 0)
    .slice(0, 12)
    .map((o) => ({
      userId: user.id,
      name: String(o.name).slice(0, 80),
      type: (OBLIGATION_TYPES.includes(String(o.type)) ? String(o.type) : "OTHER") as
        | "RENT"
        | "LOAN"
        | "EMI"
        | "SIP"
        | "SUBSCRIPTION"
        | "GROCERY"
        | "OTHER",
      amount: Math.round(num(o.amount, 0)),
      dueDay: Math.min(28, Math.max(1, Math.round(num(o.dueDay, 5)))),
    }));

  const history = generateHistory({
    persona: user.persona,
    months: 6,
    endDate: new Date(),
    seed: Math.floor(Math.random() * 100000),
    monthlyIncome: monthlyIncome || undefined,
    incomeDay,
    dailySales: dailySales || undefined,
    targetBalance: balance,
    plantAnomalies: true,
  }) as GeneratedHistory;

  await prisma.$transaction(async (tx) => {
    await tx.bankAccount.deleteMany({ where: { userId: user.id } });
    await tx.obligation.deleteMany({ where: { userId: user.id } });
    await tx.transaction.deleteMany({ where: { userId: user.id } });
    await tx.budget.deleteMany({ where: { userId: user.id } });

    await tx.bankAccount.create({
      data: {
        userId: user.id,
        bankName: String(body.bank?.bankName).slice(0, 60),
        last4: String(body.bank?.last4 ?? "0000").slice(-4),
        balance: history.closingBalance,
      },
    });

    await tx.transaction.createMany({
      data: history.transactions.map((t) => ({
        userId: user.id,
        date: t.date,
        amount: t.amount,
        type: t.type,
        payee: t.payee,
        rawDescription: t.rawDescription,
        category: t.category,
        subcategory: t.subcategory,
        isRecurring: t.isRecurring,
        recurringGroupId: t.recurringGroupId,
        isAnomaly: t.isAnomaly,
        anomalyScore: t.anomalyScore,
        anomalyReason: t.anomalyReason,
        balanceAfter: t.balanceAfter,
      })),
    });

    if (obligations.length) await tx.obligation.createMany({ data: obligations });

    await tx.user.update({
      where: { id: user.id },
      data: {
        monthlyIncome,
        incomeDay,
        incomeMin: body.income?.incomeMin ?? null,
        incomeMax: body.income?.incomeMax ?? null,
        dailySales: dailySales || null,
        survivalTarget: body.survivalTarget ? Math.round(num(body.survivalTarget, 0)) : null,
        onboarded: true,
      },
    });
  });

  // Persist a first-pass budget so Settings and exports have a record.
  const monthStart = startOfMonth(new Date());
  const spendByCategory: Record<string, number> = {};
  for (const t of history.transactions) {
    if (t.type !== "DEBIT" || t.date < monthStart) continue;
    spendByCategory[t.category] = (spendByCategory[t.category] ?? 0) + t.amount;
  }
  const limits = buildLimits({
    persona: user.persona,
    monthlyIncome: monthlyIncome || 1,
    obligations: obligations.map((o) => ({ name: o.name, type: o.type, amount: o.amount, dueDay: o.dueDay })),
    transactions: [],
    spendByCategory,
    shortageWithin30: false,
  });
  await prisma.budget.createMany({
    data: limits.map((l) => ({ userId: user.id, category: l.category, monthlyLimit: l.monthlyLimit, reason: l.reason, group: l.group })),
  });

  invalidateFinance(user.id);
  return json({ ok: true, redirect: "/dashboard", imported: history.transactions.length, balance: history.closingBalance });
}
