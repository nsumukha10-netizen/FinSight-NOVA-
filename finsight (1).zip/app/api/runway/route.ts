import { prisma } from "@/lib/prisma";
import { json, num, requireApiUser } from "@/lib/api";
import { getFinanceSnapshot, invalidateFinance } from "@/lib/finance";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const target = Math.max(0, Math.round(num(body.survivalTarget, auth.user.survivalTarget ?? 0)));

  await prisma.user.update({ where: { id: auth.user.id }, data: { survivalTarget: target } });
  invalidateFinance(auth.user.id);
  const snapshot = await getFinanceSnapshot(auth.user.id, true);

  const monthlyNeed = target > 0 ? target / 3 : Math.max(1, snapshot.monthExpenses);
  const days = Math.round((snapshot.balance / monthlyNeed) * 30);
  const status = days >= 90 ? "green" : days >= 30 ? "amber" : "red";

  return json({
    ok: true,
    survivalTarget: target,
    monthlyNeed: Math.round(monthlyNeed),
    runwayDays: Math.max(0, days),
    status,
    balance: snapshot.balance,
  });
}
