import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { fail, num, requireApiUser } from "@/lib/api";
import { invalidateFinance } from "@/lib/finance";
import { isLang } from "@/lib/i18n";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const data: Record<string, unknown> = {};
  if (typeof body.name === "string" && body.name.trim()) data.name = body.name.trim();
  if (typeof body.phone === "string" && body.phone.replace(/\D/g, "").length >= 10) data.phone = body.phone.replace(/\D/g, "");
  if (body.monthlyIncome !== undefined) data.monthlyIncome = Math.max(0, num(body.monthlyIncome, user.monthlyIncome));
  if (body.incomeDay !== undefined) data.incomeDay = Math.min(28, Math.max(1, Math.round(num(body.incomeDay, user.incomeDay))));
  if (body.survivalTarget !== undefined) data.survivalTarget = Math.max(0, num(body.survivalTarget, user.survivalTarget ?? 0));
  if (body.dailySales !== undefined) data.dailySales = Math.max(0, num(body.dailySales, user.dailySales ?? 0));
  if (typeof body.voiceEnabled === "boolean") data.voiceEnabled = body.voiceEnabled;
  if (typeof body.language === "string" && isLang(body.language)) data.language = body.language;
  if (body.theme === "dark" || body.theme === "light") data.theme = body.theme;

  if (!Object.keys(data).length) return fail("nothing_to_update");

  const updated = await prisma.user.update({ where: { id: user.id }, data });
  invalidateFinance(user.id);

  const response = NextResponse.json({
    ok: true,
    user: {
      name: updated.name,
      phone: updated.phone,
      monthlyIncome: updated.monthlyIncome,
      incomeDay: updated.incomeDay,
      survivalTarget: updated.survivalTarget,
      language: updated.language,
      theme: updated.theme,
      voiceEnabled: updated.voiceEnabled,
    },
  });
  if (data.language) {
    response.cookies.set("finsight_lang", String(data.language), { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  }
  if (data.theme) {
    response.cookies.set("finsight_theme", String(data.theme), { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  }
  return response;
}
