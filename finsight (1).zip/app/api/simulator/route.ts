import { fail, json, num, requireApiUser } from "@/lib/api";
import { forecastInputFromSnapshot, getFinanceSnapshot } from "@/lib/finance";
import { runScenario } from "@/lib/simulator";
import { aiChat, LANGUAGE_NAME } from "@/lib/ai";
import type { ScenarioInput } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const kind = String(body.kind ?? "purchase") as ScenarioInput["kind"];
  if (!["purchase", "loan", "prepay", "salary"].includes(kind)) return fail("invalid_scenario");

  const scenario: ScenarioInput = {
    kind,
    amount: Math.abs(num(body.amount, 0)),
    months: Math.max(3, Math.round(num(body.months, 12))),
    interestRate: Math.max(0, num(body.interestRate, 12)),
    newSalary: Math.abs(num(body.newSalary, 0)),
    effectiveDay: Math.max(1, Math.round(num(body.effectiveDay, 1))),
  };
  if ((kind === "purchase" || kind === "loan" || kind === "prepay") && !scenario.amount) return fail("amount_required");
  if (kind === "salary" && !scenario.newSalary) return fail("salary_required");

  const snapshot = await getFinanceSnapshot(auth.user.id);
  const input = forecastInputFromSnapshot(snapshot, 90);
  const result = runScenario(input, scenario);

  let reasons = result.reasons;
  if (auth.user.language !== "en" && reasons.length) {
    const translated = await aiChat(
      [
        {
          role: "system",
          content: `Translate each line into ${LANGUAGE_NAME[auth.user.language] ?? "English"}. Keep every number, ₹ amount and date exactly. Return only the translated lines, one per line, no bullets or numbering.`,
        },
        { role: "user", content: reasons.join("\n") },
      ],
      { maxTokens: 300, offline: "" },
    );
    const lines = translated.text
      .split("\n")
      .map((line) => line.replace(/^[-*\d.\s]+/, "").trim())
      .filter(Boolean);
    if (lines.length === reasons.length) reasons = lines;
  }

  return json({
    verdict: result.verdict,
    reasons,
    deltas: result.deltas,
    before: {
      points: result.before.points,
      endP50: result.before.endP50,
      minP50: result.before.minP50,
      shortageDate: result.before.shortageDate,
      shortageProbability: result.before.shortageProbability,
    },
    after: {
      points: result.after.points,
      endP50: result.after.endP50,
      minP50: result.after.minP50,
      shortageDate: result.after.shortageDate,
      shortageProbability: result.after.shortageProbability,
    },
    balance: snapshot.balance,
    currency: "INR",
  });
}
