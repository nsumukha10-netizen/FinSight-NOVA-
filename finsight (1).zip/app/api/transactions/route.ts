import { prisma } from "@/lib/prisma";
import { fail, json, num, requireApiUser } from "@/lib/api";
import { invalidateFinance } from "@/lib/finance";
import { categoryMeta, normalizePayee } from "@/lib/categories";
import { addTransaction } from "@/lib/payments";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const url = new URL(request.url);
  const q = url.searchParams.get("q")?.trim();
  const type = url.searchParams.get("type");
  const category = url.searchParams.get("category");
  const anomalies = url.searchParams.get("anomalies") === "1";
  const limit = Math.min(1000, Math.max(10, num(url.searchParams.get("limit"), 200)));

  const transactions = await prisma.transaction.findMany({
    where: {
      userId: auth.user.id,
      ...(type === "DEBIT" || type === "CREDIT" ? { type } : {}),
      ...(category ? { category } : {}),
      ...(anomalies ? { isAnomaly: true } : {}),
      ...(q
        ? {
            OR: [
              { payee: { contains: q } },
              { note: { contains: q } },
              { voiceLabel: { contains: q } },
              { rawDescription: { contains: q } },
            ],
          }
        : {}),
    },
    orderBy: { date: "desc" },
    take: limit,
  });

  return json({
    count: transactions.length,
    transactions: transactions.map((t) => ({
      id: t.id,
      date: t.date.toISOString(),
      amount: t.amount,
      type: t.type,
      payee: t.payee,
      rawDescription: t.rawDescription,
      category: t.category,
      isRecurring: t.isRecurring,
      isAnomaly: t.isAnomaly,
      anomalyScore: t.anomalyScore,
      anomalyReason: t.anomalyReason,
      voiceLabel: t.voiceLabel,
      note: t.note,
      balanceAfter: t.balanceAfter,
    })),
  });
}

export async function PATCH(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = String(body.id ?? "");
  const category = String(body.category ?? "");
  if (!id || !categoryMeta(category)) return fail("invalid_category");

  const transaction = await prisma.transaction.findFirst({ where: { id, userId: auth.user.id } });
  if (!transaction) return fail("not_found", 404);

  const updated = await prisma.transaction.update({ where: { id }, data: { category } });
  const key = normalizePayee(transaction.payee);
  if (key) {
    await prisma.merchantRule.upsert({
      where: { userId_payeeKey: { userId: auth.user.id, payeeKey: key } },
      create: { userId: auth.user.id, payeeKey: key, category, source: "USER", confidence: 0.95 },
      update: { category, source: "USER", confidence: 0.95 },
    });
  }
  invalidateFinance(auth.user.id);
  return json({ ok: true, transaction: { id: updated.id, category: updated.category } });
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const amount = Math.abs(num(body.amount, 0));
  const payee = String(body.payee ?? "").trim();
  const category = String(body.category ?? "Other");
  const type = body.type === "CREDIT" ? "CREDIT" : "DEBIT";
  if (!amount || !payee || !categoryMeta(category)) return fail("invalid_input");

  const transaction = await addTransaction(auth.user, {
    amount,
    payee,
    category,
    type,
    note: typeof body.note === "string" ? body.note : undefined,
    date: typeof body.date === "string" ? body.date : undefined,
  });
  return json({ ok: true, transactionId: transaction.id, balanceAfter: transaction.balanceAfter });
}
