import { prisma } from "@/lib/prisma";
import { fail, json, requireApiUser } from "@/lib/api";
import { invalidateFinance } from "@/lib/finance";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const transcript = String(body.transcript ?? "").trim().slice(0, 500);
  const transactionId = typeof body.transactionId === "string" ? body.transactionId : null;
  const language = String(body.language ?? auth.user.language ?? "en");
  if (!transcript) return fail("transcript_required");

  if (transactionId) {
    const transaction = await prisma.transaction.findFirst({ where: { id: transactionId, userId: auth.user.id } });
    if (!transaction) return fail("not_found", 404);
    await prisma.transaction.update({
      where: { id: transactionId },
      data: { voiceLabel: transcript, note: transaction.note ?? transcript },
    });
  }

  await prisma.voiceLog.create({
    data: { userId: auth.user.id, transactionId, transcript, language, kind: "LABEL" },
  });
  invalidateFinance(auth.user.id);

  return json({ ok: true, transcript });
}
