import { fail, json, requireApiUser } from "@/lib/api";
import { sarvamEnabled, sarvamStt, SARVAM_LANG } from "@/lib/sarvam";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;

  const form = await request.formData().catch(() => null);
  const file = form?.get("audio");
  const language = String(form?.get("language") ?? auth.user.language ?? "en");
  if (!(file instanceof Blob) || file.size < 500) return fail("audio_required");
  if (file.size > 20 * 1024 * 1024) return fail("audio_too_large", 413);

  if (sarvamEnabled()) {
    try {
      const result = await sarvamStt(file, language);
      return json({ transcript: result.transcript, engine: "sarvam" });
    } catch {
      /* fall through to the platform model */
    }
  }

  const base = process.env.MANUS_API_URL;
  const key = process.env.MANUS_API_KEY;
  if (!base || !key) return fail("stt_unavailable", 503);

  const upstream = new FormData();
  upstream.append("file", file, "speech.webm");
  upstream.append("model", "whisper-1");
  upstream.append("response_format", "json");
  upstream.append("prompt", `Transcribe this short Indian-language voice note about a payment. Working language: ${SARVAM_LANG[language] ?? "en-IN"}.`);

  const res = await fetch(`${base}/v1/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}` },
    body: upstream,
  });
  if (!res.ok) return fail("stt_failed", 502);
  const data = (await res.json()) as { text?: string };
  if (!data.text) return fail("stt_empty", 502);
  return json({ transcript: data.text.trim(), engine: "platform" });
}
