import { json, requireApiUser } from "@/lib/api";
import { sarvamEnabled, sarvamTts } from "@/lib/sarvam";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const text = String(body.text ?? "").slice(0, 1200);
  const language = String(body.language ?? auth.user.language ?? "en");
  if (!text) return json({ audio: null, engine: "browser" });

  if (!sarvamEnabled()) return json({ audio: null, engine: "browser" });

  try {
    const audio = await sarvamTts(text, language);
    return json({ audio, mime: "audio/wav", engine: "sarvam" });
  } catch {
    return json({ audio: null, engine: "browser" });
  }
}
