import { cookies, headers } from "next/headers";
import { prisma } from "@/lib/prisma";
import { SESSION_COOKIE, cookieOptions, signSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const PERSONAS = new Set(["salaried", "irregular", "business"]);

export async function GET(request: Request, { params }: { params: { persona: string } }) {
  const persona = params.persona.toLowerCase();
  if (!PERSONAS.has(persona)) return new Response("Unknown demo persona", { status: 404 });

  const user = await prisma.user.findFirst({
    where: { isDemo: true, persona: persona.toUpperCase() as "SALARIED" | "IRREGULAR" | "BUSINESS" },
  });
  if (!user) return new Response("Demo data is not seeded yet", { status: 404 });

  const token = await signSession(user.id);
  const store = cookies();
  const options = cookieOptions(headers().get("host"));
  store.set(SESSION_COOKIE, token, options);
  store.set("finsight_lang", user.language, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });

  const url = new URL(request.url);
  const next = url.searchParams.get("next");
  const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";
  return new Response(null, { status: 307, headers: { Location: target } });
}
