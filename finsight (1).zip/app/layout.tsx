import type { Metadata, Viewport } from "next";
import { cookies } from "next/headers";
import { AppProviders } from "@/components/providers";
import type { LangCode } from "@/lib/i18n";
import "./globals.css";

export const metadata: Metadata = {
  title: "FinSight — AI financial operating system",
  description:
    "FinSight predicts your cash flow, warns you before money runs out, and talks to you in your own Indian language.",
  applicationName: "FinSight",
  icons: {
    icon: [{ url: "/favicon.svg", type: "image/svg+xml" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#0B1020",
  width: "device-width",
  initialScale: 1,
};

const FONT_HREF =
  "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600&family=Noto+Sans+Kannada:wght@400;500;600&family=Noto+Sans+Tamil:wght@400;500;600&family=Noto+Sans+Telugu:wght@400;500;600&family=Noto+Sans+Malayalam:wght@400;500;600&family=Noto+Sans+Bengali:wght@400;500;600&family=Noto+Sans+Gujarati:wght@400;500;600&family=Noto+Sans+Gurmukhi:wght@400;500;600&family=Noto+Sans+Oriya:wght@400;500;600&display=swap";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = cookies();
  const lang = (cookieStore.get("finsight_lang")?.value ?? "en") as LangCode;
  const theme = cookieStore.get("finsight_theme")?.value === "light" ? "light" : "dark";

  return (
    <html lang={lang} className={theme === "dark" ? "dark" : undefined} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={FONT_HREF} />
      </head>
      <body>
        <AppProviders initialLang={lang} initialTheme={theme}>
          {children}
        </AppProviders>
      </body>
    </html>
  );
}
