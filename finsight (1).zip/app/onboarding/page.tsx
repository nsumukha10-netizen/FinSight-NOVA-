import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { OnboardingView } from "@/components/views/onboarding-view";
import type { PersonaKey } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  if (user.onboarded) redirect("/dashboard");
  return <OnboardingView persona={user.persona as PersonaKey} name={user.name} />;
}
