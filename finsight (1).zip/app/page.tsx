import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { LandingView } from "@/components/views/landing-view";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const user = await getCurrentUser();
  if (user) redirect(user.onboarded ? "/dashboard" : "/onboarding");
  return <LandingView />;
}
