import { LandingView } from "@/components/views/landing-view";

export const dynamic = "force-dynamic";

export default function WelcomePage() {
  return <LandingView />;
}
