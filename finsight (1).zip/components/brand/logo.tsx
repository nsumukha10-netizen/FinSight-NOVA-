import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "relative inline-flex h-9 w-9 items-center justify-center rounded-[12px] bg-gradient-to-br from-brand-500 via-brand-600 to-indigo-800 shadow-[0_10px_24px_-12px_rgba(79,70,229,0.9)]",
        className,
      )}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none">
        <path d="M4.5 16.5 9 11.4l3.2 2.9L19 6.8" stroke="white" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="19" cy="6.8" r="2.1" fill="#34D399" />
      </svg>
    </span>
  );
}

export function Logo({ className, showWordmark = true }: { className?: string; showWordmark?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      {showWordmark && (
        <span className="font-display text-[19px] font-semibold tracking-tight text-ink">
          Fin<span className="text-brand-300">Sight</span>
        </span>
      )}
    </span>
  );
}
