"use client";

import { motion } from "framer-motion";

const EXPECTED = [42, 46, 44, 52, 49, 58, 55, 62, 58, 51, 46, 38, 30, 22, 14, 8, 3, -4, -10, -18];
const WIDTH = 560;
const HEIGHT = 220;
const PAD = 12;

function toPath(values: number[], min: number, max: number) {
  const step = (WIDTH - PAD * 2) / (values.length - 1);
  return values
    .map((value, index) => {
      const x = PAD + index * step;
      const y = HEIGHT - PAD - ((value - min) / (max - min)) * (HEIGHT - PAD * 2);
      return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

export function HeroSpark() {
  const min = -30;
  const max = 76;
  const upper = EXPECTED.map((v) => v + 16 - Math.abs(v) * 0.05);
  const lower = EXPECTED.map((v) => v - 16 + Math.abs(v) * 0.02);
  const band = `${toPath(upper, min, max)} L${WIDTH - PAD},${HEIGHT - PAD} L${PAD},${HEIGHT - PAD} Z`;
  const zeroY = HEIGHT - PAD - ((0 - min) / (max - min)) * (HEIGHT - PAD * 2);

  return (
    <div className="relative w-full">
      <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} className="w-full" role="img" aria-label="Forecast chart">
        <defs>
          <linearGradient id="bandFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4F46E5" stopOpacity="0.32" />
            <stop offset="100%" stopColor="#4F46E5" stopOpacity="0.02" />
          </linearGradient>
          <linearGradient id="lineStroke" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#818CF8" />
            <stop offset="70%" stopColor="#34D399" />
            <stop offset="100%" stopColor="#F59E0B" />
          </linearGradient>
        </defs>
        <line x1={PAD} y1={zeroY} x2={WIDTH - PAD} y2={zeroY} stroke="rgba(239,68,68,0.35)" strokeDasharray="4 6" />
        <motion.path
          d={band}
          fill="url(#bandFill)"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.4 }}
        />
        <motion.path
          d={toPath(EXPECTED, min, max)}
          fill="none"
          stroke="url(#lineStroke)"
          strokeWidth={2.6}
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.6, ease: "easeInOut" }}
        />
        <motion.circle
          cx={WIDTH - PAD}
          cy={HEIGHT - PAD - ((-18 - min) / (max - min)) * (HEIGHT - PAD * 2)}
          r={5}
          fill="#F59E0B"
          initial={{ scale: 0 }}
          animate={{ scale: [0, 1.25, 1] }}
          transition={{ duration: 0.8, delay: 1.5 }}
        />
        <motion.circle
          cx={WIDTH - PAD}
          cy={HEIGHT - PAD - ((-18 - min) / (max - min)) * (HEIGHT - PAD * 2)}
          r={12}
          fill="none"
          stroke="rgba(245,158,11,0.5)"
          animate={{ r: [8, 18], opacity: [0.8, 0] }}
          transition={{ duration: 2.2, repeat: Infinity, delay: 1.6 }}
        />
      </svg>
    </div>
  );
}
