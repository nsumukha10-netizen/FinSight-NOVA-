"use client";

import * as React from "react";
import { motion } from "framer-motion";
import type { ForecastPoint } from "@/lib/types";
import { inr, inrCompact } from "@/lib/money";

function niceStep(span: number) {
  const raw = span / 4;
  const power = 10 ** Math.floor(Math.log10(Math.max(1, raw)));
  const normalized = raw / power;
  const factor = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 2.5 ? 2.5 : normalized <= 5 ? 5 : 10;
  return factor * power;
}

function chartGeometry(points: ForecastPoint[], compare: ForecastPoint[] | undefined, width: number, height: number) {
  const padL = 56;
  const padR = 14;
  const padT = 14;
  const padB = 26;
  const values = [...points.flatMap((point) => [point.p10, point.p90]), ...(compare ?? []).map((point) => point.p50), 0];
  const min = Math.min(...values);
  const max = Math.max(...values);
  const step = niceStep(Math.max(1, max - min));
  const yMin = Math.floor(min / step) * step;
  const yMax = Math.ceil(max / step) * step;
  const x = (index: number) => padL + (index / Math.max(1, points.length - 1)) * (width - padL - padR);
  const y = (value: number) => padT + (1 - (value - yMin) / Math.max(1, yMax - yMin)) * (height - padT - padB);
  const ticks: number[] = [];
  for (let value = yMin; value <= yMax + 0.001; value += step) ticks.push(value);
  return { padL, padR, padT, padB, yMin, yMax, x, y, ticks };
}

function linePath(points: ForecastPoint[], key: "p10" | "p50" | "p90", x: (i: number) => number, y: (v: number) => number) {
  return points
    .map((point, index) => `${index === 0 ? "M" : "L"}${x(index).toFixed(1)},${y(point[key]).toFixed(1)}`)
    .join(" ");
}

function bandPath(points: ForecastPoint[], x: (i: number) => number, y: (v: number) => number) {
  const upper = points.map((point, index) => `${index === 0 ? "M" : "L"}${x(index).toFixed(1)},${y(point.p90).toFixed(1)}`).join(" ");
  const lower = [...points]
    .reverse()
    .map((point, index) => `L${x(points.length - 1 - index).toFixed(1)},${y(point.p10).toFixed(1)}`)
    .join(" ");
  return `${upper} ${lower} Z`;
}

function dateLabel(date: string) {
  return new Date(date).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

export function ForecastChart({
  points,
  height = 260,
  compare,
}: {
  points: ForecastPoint[];
  height?: number;
  compare?: ForecastPoint[];
}) {
  const width = 760;
  const id = React.useId().replace(/[:]/g, "");
  const geo = chartGeometry(points, compare, width, height);
  const xTicks = Math.min(6, points.length);

  if (!points.length) return <div className="flex h-40 items-center justify-center text-[12px] text-faint">No forecast yet</div>;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }} role="img" aria-label="Cash-flow forecast">
      <defs>
        <linearGradient id={`band-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6366F1" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#6366F1" stopOpacity="0.04" />
        </linearGradient>
        <linearGradient id={`stroke-${id}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#818CF8" />
          <stop offset="55%" stopColor="#34D399" />
          <stop offset="100%" stopColor="#FBBF24" />
        </linearGradient>
      </defs>
      {geo.ticks.map((value) => (
        <g key={value}>
          <line
            x1={geo.padL}
            x2={width - geo.padR}
            y1={geo.y(value)}
            y2={geo.y(value)}
            stroke="hsl(var(--line))"
            strokeDasharray="3 6"
            strokeWidth={1}
          />
          <text x={geo.padL - 8} y={geo.y(value) + 3} textAnchor="end" fontSize={10} fill="hsl(var(--faint))">
            {inrCompact(value)}
          </text>
        </g>
      ))}
      <line x1={geo.padL} x2={width - geo.padR} y1={geo.y(0)} y2={geo.y(0)} stroke="rgba(239,68,68,0.5)" strokeDasharray="4 5" />
      <path d={bandPath(points, geo.x, geo.y)} fill={`url(#band-${id})`} />
      {compare && compare.length > 0 && (
        <path d={linePath(compare, "p50", geo.x, geo.y)} fill="none" stroke="rgba(148,163,184,0.7)" strokeWidth={1.6} strokeDasharray="5 5" />
      )}
      <path d={linePath(points, "p50", geo.x, geo.y)} fill="none" stroke={`url(#stroke-${id})`} strokeWidth={7} strokeOpacity={0.14} strokeLinecap="round" />
      <path d={linePath(points, "p50", geo.x, geo.y)} fill="none" stroke={`url(#stroke-${id})`} strokeWidth={2.6} strokeLinecap="round" />
      {Array.from({ length: xTicks }, (_, index) => {
        const pointIndex = Math.round((index / Math.max(1, xTicks - 1)) * (points.length - 1));
        return (
          <text
            key={points[pointIndex].date}
            x={geo.x(pointIndex)}
            y={height - 8}
            textAnchor={index === 0 ? "start" : index === xTicks - 1 ? "end" : "middle"}
            fontSize={10}
            fill="hsl(var(--faint))"
          >
            {dateLabel(points[pointIndex].date)}
          </text>
        );
      })}
    </svg>
  );
}

export function BacktestChart({
  points,
  height = 220,
}: {
  points: { date: string; actual: number; p10: number; p50: number; p90: number }[];
  height?: number;
}) {
  const width = 620;
  const id = React.useId().replace(/[:]/g, "");
  const forecast: ForecastPoint[] = points.map((point) => ({
    date: point.date,
    p10: point.p10,
    p50: point.p50,
    p90: point.p90,
    expectedNet: 0,
  }));
  const geo = chartGeometry(forecast, undefined, width, height);
  const actualPath = points
    .map((point, index) => `${index === 0 ? "M" : "L"}${geo.x(index).toFixed(1)},${geo.y(point.actual).toFixed(1)}`)
    .join(" ");

  if (!points.length) return <div className="flex h-40 items-center justify-center text-[12px] text-faint">Not enough history</div>;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }} role="img" aria-label="Backtest accuracy">
      <defs>
        <linearGradient id={`back-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#10B981" stopOpacity="0.26" />
          <stop offset="100%" stopColor="#10B981" stopOpacity="0.03" />
        </linearGradient>
      </defs>
      {geo.ticks.map((value) => (
        <g key={value}>
          <line x1={geo.padL} x2={width - geo.padR} y1={geo.y(value)} y2={geo.y(value)} stroke="hsl(var(--line))" strokeDasharray="3 6" strokeWidth={1} />
          <text x={geo.padL - 8} y={geo.y(value) + 3} textAnchor="end" fontSize={10} fill="hsl(var(--faint))">
            {inrCompact(value)}
          </text>
        </g>
      ))}
      <line x1={geo.padL} x2={width - geo.padR} y1={geo.y(0)} y2={geo.y(0)} stroke="rgba(239,68,68,0.4)" strokeDasharray="4 5" />
      <path d={bandPath(forecast, geo.x, geo.y)} fill={`url(#back-${id})`} />
      <path d={linePath(forecast, "p50", geo.x, geo.y)} fill="none" stroke="#818CF8" strokeWidth={1.5} strokeDasharray="4 4" />
      <path d={actualPath} fill="none" stroke="#F8FAFC" strokeWidth={2.2} strokeLinecap="round" />
      {Array.from({ length: 4 }, (_, index) => {
        const pointIndex = Math.round((index / 3) * (points.length - 1));
        return (
          <text
            key={points[pointIndex].date}
            x={geo.x(pointIndex)}
            y={height - 8}
            textAnchor={index === 0 ? "start" : index === 3 ? "end" : "middle"}
            fontSize={10}
            fill="hsl(var(--faint))"
          >
            {dateLabel(points[pointIndex].date)}
          </text>
        );
      })}
    </svg>
  );
}

export function CategoryDonut({
  data,
  height = 220,
}: {
  data: { name: string; value: number; color: string }[];
  height?: number;
}) {
  const total = data.reduce((sum, entry) => sum + entry.value, 0);
  let cursor = 0;
  const stops = data
    .map((entry) => {
      const start = total ? (cursor / total) * 100 : 0;
      cursor += entry.value;
      const end = total ? (cursor / total) * 100 : 0;
      return `${entry.color} ${start.toFixed(2)}% ${end.toFixed(2)}%`;
    })
    .join(", ");

  return (
    <div className="flex items-center gap-4">
      <div className="relative shrink-0" style={{ width: height, height }}>
        <div className="absolute inset-0 rounded-full" style={{ background: total ? `conic-gradient(${stops})` : "hsl(var(--elevated))" }} />
        <div className="absolute inset-[17%] rounded-full bg-surface shadow-[inset_0_0_20px_rgba(0,0,0,0.25)]" />
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-[10px] uppercase tracking-wider text-faint">Total</span>
          <span className="num text-sm font-semibold">{inrCompact(total)}</span>
        </div>
      </div>
      <ul className="min-w-0 flex-1 space-y-1.5">
        {data.slice(0, 5).map((entry) => (
          <li key={entry.name} className="flex items-center gap-2 text-[11.5px]">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: entry.color }} />
            <span className="min-w-0 flex-1 truncate text-muted">{entry.name}</span>
            <span className="num shrink-0 font-medium">{total ? Math.round((entry.value / total) * 100) : 0}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function HealthRing({ score, size = 132 }: { score: number; size?: number }) {
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.min(100, Math.max(0, score)) / 100);
  const color = score >= 80 ? "#10B981" : score >= 65 ? "#34D399" : score >= 45 ? "#F59E0B" : "#EF4444";

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="hsl(var(--elevated))" strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="num font-display text-3xl font-semibold">{Math.round(score)}</span>
        <span className="text-[10px] uppercase tracking-[0.14em] text-faint">/ 100</span>
      </div>
    </div>
  );
}

export function RunwayGauge({ days, target = 90 }: { days: number; target?: number }) {
  const ratio = Math.min(1.2, days / target);
  const angle = Math.min(180, ratio * 180);
  const color = days >= target ? "#10B981" : days >= 30 ? "#F59E0B" : "#EF4444";
  const radius = 78;
  const circumference = Math.PI * radius;
  const offset = circumference * (1 - angle / 180);

  return (
    <div className="relative mx-auto w-[220px]">
      <svg viewBox="0 0 200 112" className="w-full">
        <path d={`M22,100 A${radius},${radius} 0 0 1 178,100`} stroke="hsl(var(--elevated))" strokeWidth={14} fill="none" strokeLinecap="round" />
        <motion.path
          d={`M22,100 A${radius},${radius} 0 0 1 178,100`}
          stroke={color}
          strokeWidth={14}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-x-0 bottom-1 text-center">
        <p className="num font-display text-3xl font-semibold">{days}</p>
        <p className="text-[10px] uppercase tracking-[0.16em] text-faint">days</p>
      </div>
    </div>
  );
}

export function BudgetBars({
  rows,
}: {
  rows: { category: string; spent: number; limit: number; color: string }[];
}) {
  return (
    <div className="space-y-3">
      {rows.slice(0, 8).map((row) => {
        const pct = row.limit > 0 ? Math.min(100, (row.spent / row.limit) * 100) : 0;
        const over = row.spent > row.limit;
        return (
          <div key={row.category}>
            <div className="flex items-center justify-between gap-2 text-[11px]">
              <span className="flex min-w-0 items-center gap-1.5 text-muted">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: row.color }} />
                <span className="truncate">{row.category}</span>
              </span>
              <span className={`num shrink-0 ${over ? "text-rose-300" : "text-faint"}`}>
                {inr(row.spent)} / {inr(row.limit)}
              </span>
            </div>
            <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-elevated">
              <motion.div
                className="h-full rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.7 }}
                style={{ background: over ? "#EF4444" : row.color }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
