"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { AlertTriangle, Ban, CheckCircle2, CreditCard, ShieldAlert, Sparkles, Wallet } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n, useToast } from "@/components/providers";
import { useVoice } from "@/components/voice/voice-assistant";
import { CATEGORIES, categoryI18nKey } from "@/lib/categories";
import { inr } from "@/lib/money";
import { cn } from "@/lib/utils";

export interface PaymentReview {
  decision: "commit" | "anomaly" | "impulse";
  payee: string;
  amount: number;
  category: string;
  confidence: number;
  source: string;
  balanceAfter: number;
  anomaly: { score: number; isAnomaly: boolean; reason: string | null; signals: string[] };
  impulse: {
    spent: number;
    limit: number;
    pct: number;
    healthScore: number;
    grade: string;
    shortage30: number;
    explanation: string;
  } | null;
  explanation: string;
}

interface PaymentContextValue {
  open: (preset?: { payee?: string; amount?: number; category?: string }) => void;
  demo: (kind: "swiggy" | "unknown") => Promise<void>;
}

const PaymentContext = React.createContext<PaymentContextValue | null>(null);

export function usePayment() {
  const ctx = React.useContext(PaymentContext);
  if (!ctx) throw new Error("usePayment outside provider");
  return ctx;
}

const QUICK_PAYEES = ["Swiggy", "Zomato", "Amazon", "Myntra", "Uber", "BigBasket"];

export function PaymentProvider({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();
  const { toast } = useToast();
  const { open: openVoice } = useVoice();
  const router = useRouter();

  const [sheetOpen, setSheetOpen] = React.useState(false);
  const [form, setForm] = React.useState({ payee: "", amount: "", category: "" });
  const [review, setReview] = React.useState<PaymentReview | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [done, setDone] = React.useState<{ amount: number; payee: string; transactionId: string } | null>(null);

  const reset = React.useCallback(() => {
    setForm({ payee: "", amount: "", category: "" });
    setReview(null);
    setDone(null);
    setBusy(false);
  }, []);

  const open = React.useCallback((preset?: { payee?: string; amount?: number; category?: string }) => {
    reset();
    setForm({
      payee: preset?.payee ?? "",
      amount: preset?.amount ? String(preset.amount) : "",
      category: preset?.category ?? "",
    });
    setSheetOpen(true);
  }, [reset]);

  const commit = React.useCallback(
    async (payload: { payee: string; amount: number; category?: string }, reviewNote?: string) => {
      setBusy(true);
      try {
        const res = await fetch("/api/bank/pay", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...payload, confirm: true, reviewNote }),
        });
        const data = (await res.json()) as { ok?: boolean; transactionId?: string; error?: string };
        if (!res.ok || !data.ok) throw new Error(data.error ?? "payment_failed");
        setReview(null);
        setDone({ amount: payload.amount, payee: payload.payee, transactionId: data.transactionId ?? "" });
        toast({
          kind: "success",
          title: t("pay.success"),
          description: t("pay.successBody", { amount: inr(payload.amount), payee: payload.payee }),
        });
        window.dispatchEvent(new CustomEvent("finsight:refresh"));
        router.refresh();
        setTimeout(() => {
          setSheetOpen(false);
          if (data.transactionId) {
            openVoice({ mode: "expense", transactionId: data.transactionId, prompt: t("voice.expensePrompt") });
          }
        }, 900);
      } catch {
        toast({ kind: "error", title: t("common.error") });
      } finally {
        setBusy(false);
      }
    },
    [openVoice, router, t, toast],
  );

  const submit = React.useCallback(
    async (event: React.FormEvent) => {
      event.preventDefault();
      const amount = Number(form.amount);
      if (!form.payee.trim() || !amount) return;
      setBusy(true);
      try {
        const payload = { payee: form.payee.trim(), amount, category: form.category || undefined };
        const res = await fetch("/api/bank/pay", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = (await res.json()) as { review?: PaymentReview; error?: string };
        if (!res.ok || !data.review) throw new Error(data.error ?? "payment_failed");
        if (data.review.decision === "commit") {
          await commit(payload);
        } else {
          setReview(data.review);
        }
      } catch {
        toast({ kind: "error", title: t("common.error") });
      } finally {
        setBusy(false);
      }
    },
    [commit, form, t, toast],
  );

  const demo = React.useCallback(
    async (kind: "swiggy" | "unknown") => {
      setBusy(true);
      try {
        const res = await fetch("/api/demo/trigger", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind }),
        });
        const data = (await res.json()) as { review?: PaymentReview; error?: string };
        if (!res.ok || !data.review) throw new Error(data.error);
        setSheetOpen(true);
        setReview(data.review);
      } catch {
        toast({ kind: "error", title: t("common.error") });
      } finally {
        setBusy(false);
      }
    },
    [t, toast],
  );

  const reviewPayload = review ? { payee: review.payee, amount: review.amount, category: review.category } : null;

  return (
    <PaymentContext.Provider value={{ open, demo }}>
      {children}

      <Dialog
        open={sheetOpen}
        onOpenChange={(next) => {
          if (!next) {
            setSheetOpen(false);
            reset();
          }
        }}
      >
        <DialogContent className="max-w-md">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Wallet className="h-5 w-5 text-brand-300" />
            {done ? t("pay.success") : t("pay.title")}
          </DialogTitle>

          {done ? (
            <div className="space-y-4 py-2">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15"
              >
                <CheckCircle2 className="h-8 w-8 text-emerald-400" />
              </motion.div>
              <p className="text-center text-sm text-muted">{t("pay.successBody", { amount: inr(done.amount), payee: done.payee })}</p>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="payee">{t("pay.payee")}</Label>
                <Input
                  id="payee"
                  value={form.payee}
                  onChange={(e) => setForm((prev) => ({ ...prev, payee: e.target.value }))}
                  placeholder="Swiggy"
                  autoFocus
                />
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {QUICK_PAYEES.map((payee) => (
                    <button
                      key={payee}
                      type="button"
                      onClick={() => setForm((prev) => ({ ...prev, payee }))}
                      className={cn(
                        "rounded-full border px-2.5 py-1 text-[11px] transition-colors",
                        form.payee === payee ? "border-brand/50 bg-brand/15 text-brand-200" : "border-line/70 text-faint hover:text-ink",
                      )}
                    >
                      {payee}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="amount">{t("pay.amount")}</Label>
                  <Input
                    id="amount"
                    inputMode="numeric"
                    value={form.amount}
                    onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value.replace(/[^\d.]/g, "") }))}
                    placeholder="640"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("pay.category")}</Label>
                  <Select value={form.category} onValueChange={(v) => setForm((prev) => ({ ...prev, category: v }))}>
                    <SelectTrigger>
                      <SelectValue placeholder={t("pay.auto")} />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.filter((c) => c.key !== "Income").map((c) => (
                        <SelectItem key={c.key} value={c.key}>
                          {t(categoryI18nKey(c.key))}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setSheetOpen(false)}>
                  {t("common.cancel")}
                </Button>
                <Button type="submit" loading={busy}>
                  <CreditCard className="h-4 w-4" />
                  {t("pay.submit")}
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Impulse checkpoint */}
      <Dialog open={review?.decision === "impulse"} onOpenChange={(next) => !next && setReview(null)}>
        <DialogContent className="max-w-lg overflow-hidden border-amber-500/30">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-amber-500/15 to-transparent" />
          <div className="relative flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-300">
            <ShieldAlert className="h-4 w-4" />
            {t("impulse.eyebrow")}
          </div>
          <DialogTitle className="relative text-[22px] leading-tight">
            {t("impulse.title", { category: t(categoryI18nKey(review?.category ?? "Other")) })}
          </DialogTitle>
          <DialogDescription className="relative">{review?.impulse?.explanation}</DialogDescription>

          <div className="relative space-y-3 rounded-2xl border border-line/70 bg-elevated/40 p-4">
            <div className="flex items-end justify-between">
              <div>
                <p className="label">{t("budget.spent")}</p>
                <p className="num mt-1 text-2xl font-semibold">{inr(review?.impulse?.spent ?? 0)}</p>
              </div>
              <p className="text-[12px] text-muted">
                {t("budget.limit")} <span className="num font-medium text-ink">{inr(review?.impulse?.limit ?? 0)}</span>
              </p>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-elevated">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-amber-400 to-rose-500"
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (review?.impulse?.pct ?? 0) * 100)}%` }}
                transition={{ duration: 0.6 }}
              />
            </div>
            <div className="flex items-center justify-between text-[11.5px]">
              <span className="text-amber-300">
                {review?.impulse && review.impulse.pct >= 1
                  ? t("impulse.over", { amount: inr(review.impulse.spent - review.impulse.limit) })
                  : t("impulse.left", { amount: inr(Math.max(0, (review?.impulse?.limit ?? 0) - (review?.impulse?.spent ?? 0))) })}
              </span>
              <span className="text-muted">
                {t("impulse.health", { score: review?.impulse?.healthScore ?? 0, grade: review?.impulse?.grade ?? "" })}
              </span>
            </div>
            {review?.impulse && review.impulse.shortage30 >= 0.4 && (
              <p className="flex items-center gap-1.5 text-[11.5px] text-rose-300">
                <AlertTriangle className="h-3.5 w-3.5" />
                {t("impulse.shortage")}
              </p>
            )}
          </div>

          <div className="relative grid gap-2 sm:grid-cols-2">
            <Button
              variant="success"
              onClick={() => {
                setReview(null);
                setSheetOpen(false);
                toast({ kind: "info", title: t("impulse.cancel") });
              }}
            >
              <Ban className="h-4 w-4" />
              {t("impulse.cancel")}
            </Button>
            <Button
              variant="outline"
              loading={busy}
              onClick={() => reviewPayload && commit(reviewPayload, review?.explanation)}
              className="border-rose-500/40 text-rose-200 hover:bg-rose-500/10"
            >
              {t("impulse.continue")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Anomaly review */}
      <Dialog open={review?.decision === "anomaly"} onOpenChange={(next) => !next && setReview(null)}>
        <DialogContent className="max-w-lg overflow-hidden border-rose-500/40 glow-critical">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-rose-500/20 to-transparent" />
          <div className="relative flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-rose-300">
            <ShieldAlert className="h-4 w-4" />
            {t("anomaly.eyebrow")}
          </div>
          <DialogTitle className="relative text-[22px]">{t("anomaly.title")}</DialogTitle>
          <p className="num relative font-display text-4xl font-semibold tracking-tight">{inr(review?.amount ?? 0)}</p>
          <p className="relative text-sm text-muted">{review?.payee}</p>

          <div className="relative rounded-2xl border border-rose-500/25 bg-rose-500/8 p-4 text-[12.5px] leading-relaxed text-rose-100">
            {review?.anomaly.reason === "duplicate"
              ? t("anomaly.reasonDuplicate")
              : review?.anomaly.reason === "unknown_payee"
                ? t("anomaly.reasonUnknown")
                : review?.anomaly.reason === "spike"
                  ? t("anomaly.reasonSpike", { category: t(categoryI18nKey(review?.category ?? "Other")) })
                  : t("anomaly.reasonUnusual")}
            <p className="mt-2 text-rose-200/80">{review?.explanation}</p>
          </div>

          <div className="relative flex flex-wrap items-center gap-1.5">
            {(review?.anomaly.signals ?? []).slice(0, 3).map((signal) => (
              <span key={signal} className="rounded-full border border-rose-500/25 px-2 py-0.5 text-[10px] text-rose-200">
                {signal.replaceAll("_", " ")}
              </span>
            ))}
            <span className="ml-auto text-[11px] text-faint">score {Math.round((review?.anomaly.score ?? 0) * 100)}/100</span>
          </div>

          <div className="relative grid gap-2 sm:grid-cols-2">
            <Button
              variant="success"
              onClick={() => {
                setReview(null);
                setSheetOpen(false);
                toast({ kind: "info", title: t("anomaly.block") });
              }}
            >
              <Ban className="h-4 w-4" />
              {t("anomaly.block")}
            </Button>
            <Button
              variant="outline"
              loading={busy}
              onClick={() => reviewPayload && commit(reviewPayload, review?.explanation)}
              className="border-rose-500/40 text-rose-200 hover:bg-rose-500/10"
            >
              <CheckCircle2 className="h-4 w-4" />
              {t("anomaly.continue")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="hidden">
        <Sparkles className="h-4 w-4" />
      </div>
    </PaymentContext.Provider>
  );
}
