"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  Bell,
  ChartNoAxesCombined,
  Gauge,
  LayoutDashboard,
  LineChart,
  Mic,
  Moon,
  MoreHorizontal,
  Settings,
  Sparkles,
  Store,
  Sun,
  Timer,
  Wallet,
} from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { LanguageSwitcher } from "@/components/shell/language-switcher";
import { VoiceProvider, useVoice } from "@/components/voice/voice-assistant";
import { PaymentProvider } from "@/components/payments/payment-flow";
import { useI18n, useTheme } from "@/components/providers";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { cn, initials } from "@/lib/utils";

interface ShellUser {
  id: string;
  name: string;
  persona: "SALARIED" | "IRREGULAR" | "BUSINESS";
  isDemo: boolean;
}

const NAV = [
  { href: "/dashboard", key: "nav.dashboard", icon: LayoutDashboard },
  { href: "/transactions", key: "nav.transactions", icon: Wallet },
  { href: "/forecast", key: "nav.forecast", icon: LineChart },
  { href: "/budget", key: "nav.budget", icon: Gauge },
  { href: "/coach", key: "nav.coach", icon: Sparkles },
  { href: "/simulator", key: "nav.simulator", icon: ChartNoAxesCombined },
  { href: "/runway", key: "nav.runway", icon: Timer },
  { href: "/business", key: "nav.business", icon: Store },
  { href: "/alerts", key: "nav.alerts", icon: Bell },
  { href: "/settings", key: "nav.settings", icon: Settings },
];

function isActive(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function AppShell({
  user,
  alertCount,
  children,
}: {
  user: ShellUser;
  alertCount: number;
  children: React.ReactNode;
}) {
  const { t } = useI18n();
  const { theme, toggle } = useTheme();
  const pathname = usePathname();
  const [moreOpen, setMoreOpen] = React.useState(false);

  const nav = NAV.filter((item) => item.href !== "/business" || user.persona === "BUSINESS");
  const primary = nav.slice(0, 5);
  const secondary = nav.slice(5);
  const current = nav.find((item) => isActive(pathname, item.href));

  return (
    <VoiceProvider>
      <PaymentProvider>
      <div className="min-h-dvh">
        <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] flex-col border-r border-line/60 bg-surface/35 backdrop-blur-2xl lg:flex">
          <div className="px-6 pb-6 pt-6">
            <Link href="/dashboard" className="focus-ring rounded-xl">
              <Logo />
            </Link>
            <p className="mt-2 text-[11px] leading-relaxed text-faint">{t("app.tagline")}</p>
          </div>
          <nav className="flex-1 space-y-1 overflow-y-auto px-3 scrollbar-thin" aria-label="Main">
            {nav.map((item) => {
              const active = isActive(pathname, item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-medium transition-colors",
                    active ? "bg-brand/15 text-ink" : "text-muted hover:bg-elevated/60 hover:text-ink",
                  )}
                >
                  {active && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-r-full bg-gradient-to-b from-brand-400 to-emerald-400"
                    />
                  )}
                  <item.icon className={cn("h-[18px] w-[18px]", active ? "text-brand-300" : "text-faint group-hover:text-muted")} />
                  {t(item.key)}
                  {item.href === "/alerts" && alertCount > 0 && (
                    <span className="ml-auto rounded-full bg-rose-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-rose-300">
                      {alertCount}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>
          <div className="p-4">
            <div className="rounded-2xl border border-line/70 bg-elevated/40 p-3.5">
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-emerald-500 text-[11px] font-semibold text-white">
                  {initials(user.name)}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[12.5px] font-medium">{user.name}</p>
                  <p className="truncate text-[10.5px] uppercase tracking-wider text-faint">{user.persona.toLowerCase()}</p>
                </div>
              </div>
              {user.isDemo && (
                <p className="mt-2.5 rounded-lg bg-brand/12 px-2 py-1 text-center text-[10px] font-medium uppercase tracking-widest text-brand-200">
                  Demo persona
                </p>
              )}
            </div>
          </div>
        </aside>

        <div className="lg:pl-[264px]">
          <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-line/50 bg-canvas/70 px-4 backdrop-blur-xl sm:px-6 lg:px-8">
            <Link href="/dashboard" className="lg:hidden">
              <Logo showWordmark={false} />
            </Link>
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-[15px] font-semibold tracking-tight">{current ? t(current.key) : t("app.name")}</p>
              <p className="hidden truncate text-[11px] text-faint sm:block">{t("app.tagline")}</p>
            </div>
            <div className="hidden sm:block">
              <LanguageSwitcher compact />
            </div>
            <button
              onClick={toggle}
              className="focus-ring flex h-9 w-9 items-center justify-center rounded-full border border-line/80 bg-elevated/40 text-muted transition-colors hover:text-ink"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <Link
              href="/alerts"
              className="focus-ring relative flex h-9 w-9 items-center justify-center rounded-full border border-line/80 bg-elevated/40 text-muted transition-colors hover:text-ink"
              aria-label={t("nav.alerts")}
            >
              <Bell className="h-4 w-4" />
              {alertCount > 0 && <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-rose-400" />}
            </Link>
            <Link
              href="/settings"
              className="focus-ring flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-emerald-500 text-[11px] font-semibold text-white"
              aria-label={t("nav.settings")}
            >
              {initials(user.name)}
            </Link>
          </header>

          <main className="mx-auto w-full max-w-[1280px] px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pb-16">{children}</main>
        </div>

        <button
          onClick={() => {
            const event = new CustomEvent("finsight:open-voice");
            window.dispatchEvent(event);
          }}
          className="fixed bottom-[86px] right-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-[0_18px_40px_-14px_rgba(79,70,229,0.9)] transition-transform hover:scale-105 active:scale-95 lg:bottom-8 lg:right-8"
          aria-label={t("voice.title")}
        >
          <span className="absolute inset-0 animate-ping rounded-full bg-brand-500/30" />
          <Mic className="relative h-6 w-6" />
        </button>

        <nav
          className="fixed inset-x-0 bottom-0 z-40 flex h-[72px] items-stretch justify-around border-t border-line/70 bg-surface/85 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl lg:hidden"
          aria-label="Bottom"
        >
          {primary.map((item) => {
            const active = isActive(pathname, item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors",
                  active ? "text-brand-300" : "text-faint",
                )}
              >
                <item.icon className="h-[19px] w-[19px]" />
                <span className="max-w-[64px] truncate">{t(item.key)}</span>
              </Link>
            );
          })}
          <button
            onClick={() => setMoreOpen(true)}
            className="flex flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium text-faint"
          >
            <MoreHorizontal className="h-[19px] w-[19px]" />
            <span>{t("nav.settings")}</span>
          </button>
        </nav>

        <Dialog open={moreOpen} onOpenChange={setMoreOpen}>
          <DialogContent className="max-w-sm">
            <DialogTitle className="text-base">{t("app.name")}</DialogTitle>
            <div className="grid grid-cols-2 gap-2">
              {secondary.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMoreOpen(false)}
                  className="flex items-center gap-2 rounded-xl border border-line/70 bg-elevated/40 px-3 py-3 text-[13px] text-muted"
                >
                  <item.icon className="h-4 w-4 text-brand-300" />
                  {t(item.key)}
                </Link>
              ))}
            </div>
            <LanguageSwitcher />
          </DialogContent>
        </Dialog>
      </div>
      <GlobalVoiceBridge />
      </PaymentProvider>
    </VoiceProvider>
  );
}

function GlobalVoiceBridge() {
  const { open } = useVoice();
  React.useEffect(() => {
    const handler = () => open({ mode: "coach" });
    window.addEventListener("finsight:open-voice", handler);
    return () => window.removeEventListener("finsight:open-voice", handler);
  }, [open]);
  return null;
}
