"use client";

import { Globe2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/components/providers";
import { LANGUAGES, type LangCode } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { lang, setLang } = useI18n();
  return (
    <div className={cn("flex items-center gap-2", compact && "w-[132px]")}>
      <Select value={lang} onValueChange={(v) => setLang(v as LangCode)}>
        <SelectTrigger
          className={cn(
            "h-9 gap-2 rounded-full border-line/80 bg-elevated/40 pl-3 pr-2 text-[12px]",
            compact ? "w-[132px]" : "w-auto min-w-[150px]",
          )}
          aria-label="Language"
        >
          <Globe2 className="h-3.5 w-3.5 shrink-0 text-brand-300" />
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="max-h-80">
          {LANGUAGES.map((l) => (
            <SelectItem key={l.code} value={l.code}>
              <span className="flex items-center gap-2">
                <span className="font-medium">{l.native}</span>
                <span className="text-[11px] text-faint">{l.label}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
