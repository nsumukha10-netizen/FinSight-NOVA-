import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium leading-5",
  {
    variants: {
      variant: {
        default: "border-line bg-elevated/70 text-muted",
        brand: "border-brand/30 bg-brand/12 text-brand-200",
        safe: "border-emerald-500/30 bg-emerald-500/12 text-emerald-300",
        caution: "border-amber-500/30 bg-amber-500/12 text-amber-300",
        critical: "border-rose-500/30 bg-rose-500/12 text-rose-300",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement>, VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
