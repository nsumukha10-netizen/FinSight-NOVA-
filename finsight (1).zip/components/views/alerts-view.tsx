"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { BellRing, CalendarClock, Check, ShieldAlert, TrendingDown, Wallet } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useI18n, useToast } from "@/components/providers";
import { cn } from "@/lib/utils";

export interface AlertRow {
  id: string;
  type: string;
  severity: string;
  message: string;
  explanation: string;
  createdAt: string;
  resolved: boolean;
}

const ICONS: Record<string, typeof ShieldAlert> = {
  anomaly: ShieldAlert,
  shortage: TrendingDown,
  impulse: Wallet,
  due: CalendarClock,
  info: BellRing,
};

export function AlertsView({ initial }: { initial: AlertRow[] }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const [alerts, setAlerts] = React.useState(initial);
  const [filter, setFilter] = React.useState("all");

  const filtered = alerts.filter((alert) => (filter === "all" ? true : filter === "resolved" ? alert.resolved : alert.type === filter));

  async function resolve(id: string) {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, resolved: true } : a)));
    try {
      const res = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, resolved: true }),
      });
      if (!res.ok) throw new Error("failed");
    } catch {
      toast({ kind: "error", title: t("common.error") });
    }
  }

  const filters = [
    ["all", t("tx.all")],
    ["shortage", t("alerts.shortage")],
    ["anomaly", t("alerts.anomaly")],
    ["impulse", t("alerts.impulse")],
    ["due", t("alerts.due")],
    ["resolved", t("alerts.resolved")],
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="h1">{t("alerts.title")}</h1>
        <p className="mt-1 text-sm text-muted">{t("alerts.subtitle")}</p>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {filters.map(([value, label]) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition-colors",
              filter === value ? "border-brand/50 bg-brand/15 text-brand-200" : "border-line/70 text-faint hover:text-ink",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="space-y-2.5">
        {filtered.map((alert, index) => {
          const Icon = ICONS[alert.type] ?? BellRing;
          return (
            <motion.div key={alert.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.03 }}>
              <Card
                className={cn(
                  alert.resolved && "opacity-60",
                  alert.severity === "critical" && !alert.resolved && "border-rose-500/30",
                  alert.severity === "caution" && !alert.resolved && "border-amber-500/30",
                )}
              >
                <CardContent className="flex items-start gap-3 p-4">
                  <span
                    className={cn(
                      "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
                      alert.severity === "critical" && "bg-rose-500/12 text-rose-300",
                      alert.severity === "caution" && "bg-amber-500/12 text-amber-300",
                      alert.severity === "info" && "bg-brand/12 text-brand-200",
                    )}
                  >
                    <Icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[13px] font-medium">{alert.message}</p>
                      <Badge variant={alert.severity === "critical" ? "critical" : alert.severity === "caution" ? "caution" : "default"}>
                        {t(`alerts.${alert.type}`)}
                      </Badge>
                      {alert.resolved && <Badge variant="safe">{t("alerts.resolve")}</Badge>}
                    </div>
                    <p className="mt-1 text-[12px] leading-relaxed text-muted">{alert.explanation}</p>
                    <p className="mt-1.5 text-[10.5px] text-faint">
                      {new Date(alert.createdAt).toLocaleString(lang === "en" ? "en-IN" : `${lang}-IN`, {
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  {!alert.resolved && (
                    <Button size="sm" variant="secondary" onClick={() => resolve(alert.id)}>
                      <Check className="h-3.5 w-3.5" />
                      {t("alerts.resolve")}
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {!filtered.length && (
          <Card>
            <CardContent className="flex flex-col items-center gap-2 py-14 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-300">
                <Check className="h-6 w-6" />
              </span>
              <p className="text-[13px] font-medium">{t("alerts.empty")}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
