"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ChevronDown, Gauge, Lightbulb, PiggyBank, ShieldCheck, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BudgetBars, HealthRing } from "@/components/charts";
import { useI18n } from "@/components/providers";
import { categoryColor, categoryI18nKey } from "@/lib/categories";
import { inr, inrCompact } from "@/lib/money";
import type { BudgetRow, HealthResult } from "@/lib/types";
import { cn } from "@/lib/utils";

export function BudgetView({
  limits,
  monthIncome,
  monthExpenses,
  health,
  shortageWithin30,
}: {
  limits: BudgetRow[];
  monthIncome: number;
  monthExpenses: number;
  health: HealthResult;
  shortageWithin30: boolean;
}) {
  const { t, lang } = useI18n();
  const [expanded, setExpanded] = React.useState<string | null>(null);

  const groupTotals = React.useMemo(() => {
    const base = { Needs: 0, Wants: 0, Savings: 0 } as Record<string, number>;
    for (const row of limits) base[row.group] += row.monthlyLimit;
    return base;
  }, [limits]);

  const groupSpend = React.useMemo(() => {
    const base = { Needs: 0, Wants: 0, Savings: 0 } as Record<string, number>;
    for (const row of limits) base[row.group] += row.spent;
    return base;
  }, [limits]);

  const totalLimit = Object.values(groupTotals).reduce((a, b) => a + b, 0);
  const suggestions = React.useMemo(() => {
    const food = limits.find((l) => l.category === "Food Delivery");
    const subs = limits.find((l) => l.category === "Subscriptions");
    const shopping = limits.find((l) => l.category === "Shopping");
    return [
      {
        text: t("budget.suggestion1", { amount: inr(Math.round(((food?.spent ?? 0) / 2) * 0.45) || 900, lang) }),
        icon: Lightbulb,
      },
      {
        text: t("budget.suggestion2", { amount: inr(Math.round((subs?.spent ?? 0) * 0.35) || 250, lang) }),
        icon: PiggyBank,
      },
      {
        text: t("budget.suggestion3", { amount: inr(Math.round((shopping?.spent ?? 0) * 0.25) || 750, lang) }),
        icon: ShieldCheck,
      },
    ];
  }, [limits, lang, t]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="h1">{t("budget.title")}</h1>
          <p className="mt-1 text-sm text-muted">{t("budget.subtitle")}</p>
        </div>
        {shortageWithin30 && (
          <Badge variant="caution">
            <Sparkles className="h-3 w-3" />
            Limits tightened for a forecast shortage
          </Badge>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-8">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-brand-300" />
              {t("budget.allocation")}
            </CardTitle>
            <span className="text-[11.5px] text-muted">
              {t("budget.spent")} <span className="num font-medium text-ink">{inrCompact(monthExpenses, lang)}</span> {t("common.of")}{" "}
              <span className="num">{inrCompact(monthIncome, lang)}</span>
            </span>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="mb-4 grid grid-cols-3 gap-2">
              {(["Needs", "Wants", "Savings"] as const).map((group) => {
                const pct = totalLimit ? Math.round((groupTotals[group] / totalLimit) * 100) : 0;
                const spentPct = groupTotals[group] ? Math.min(100, Math.round((groupSpend[group] / groupTotals[group]) * 100)) : 0;
                return (
                  <div key={group} className="rounded-xl border border-line/60 bg-elevated/25 p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-medium text-muted">{t(`budget.${group.toLowerCase()}`)}</p>
                      <span className="num text-[11px] text-faint">{pct}%</span>
                    </div>
                    <p className="num mt-1 text-[14px] font-semibold">{inr(groupTotals[group], lang)}</p>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-elevated">
                      <div
                        className={cn("h-full rounded-full", spentPct >= 100 ? "bg-rose-400" : spentPct >= 80 ? "bg-amber-400" : "bg-emerald-400")}
                        style={{ width: `${spentPct}%` }}
                      />
                    </div>
                    <p className="mt-1 text-[10px] text-faint">
                      {t("budget.spent")} {inrCompact(groupSpend[group], lang)}
                    </p>
                  </div>
                );
              })}
            </div>
            <BudgetBars
              rows={limits
                .filter((l) => l.monthlyLimit > 0)
                .map((l) => ({ category: t(categoryI18nKey(l.category)), spent: l.spent, limit: l.monthlyLimit, color: categoryColor(l.category) }))}
            />
          </CardContent>
        </Card>

        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>{t("dash.health")}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-3 pt-1">
            <HealthRing score={health.score} size={128} />
            <Badge variant={health.score >= 65 ? "safe" : health.score >= 45 ? "caution" : "critical"}>{health.grade}</Badge>
            <div className="w-full space-y-2">
              {health.parts.map((part) => (
                <div key={part.key} className="flex items-center gap-2 text-[11px]">
                  <span className="w-24 shrink-0 truncate text-muted">{part.label}</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-elevated">
                    <div
                      className={cn("h-full rounded-full", part.score >= 65 ? "bg-emerald-400" : part.score >= 45 ? "bg-amber-400" : "bg-rose-400")}
                      style={{ width: `${part.score}%` }}
                    />
                  </div>
                  <span className="num w-6 text-right text-faint">{part.score}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {limits.map((limit) => {
          const pct = limit.monthlyLimit ? (limit.spent / limit.monthlyLimit) * 100 : 0;
          const over = limit.spent - limit.monthlyLimit;
          const open = expanded === limit.category;
          return (
            <Card key={limit.category} className={cn(pct >= 100 && "border-rose-500/30", pct >= 80 && pct < 100 && "border-amber-500/30")}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: categoryColor(limit.category) }} />
                    <p className="text-[13px] font-medium">{t(categoryI18nKey(limit.category))}</p>
                  </div>
                  <Badge variant={pct >= 100 ? "critical" : pct >= 80 ? "caution" : "safe"}>
                    {Math.round(pct)}%
                  </Badge>
                </div>
                <div className="mt-3 flex items-end justify-between">
                  <p className="num text-lg font-semibold">{inr(limit.spent, lang)}</p>
                  <p className="num text-[11.5px] text-faint">
                    {t("budget.limit")} {inr(limit.monthlyLimit, lang)}
                  </p>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-elevated">
                  <motion.div
                    className={cn("h-full rounded-full", pct >= 100 ? "bg-rose-400" : pct >= 80 ? "bg-amber-400" : "bg-emerald-400")}
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, pct)}%` }}
                    transition={{ duration: 0.7 }}
                  />
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[11px]">
                  <span className={cn(pct >= 100 ? "text-rose-300" : "text-faint")}>
                    {over > 0 ? t("budget.over", { amount: inr(over, lang) }) : `${t("budget.remaining")} ${inr(Math.max(0, limit.monthlyLimit - limit.spent), lang)}`}
                  </span>
                  <button onClick={() => setExpanded(open ? null : limit.category)} className="flex items-center gap-1 text-brand-300 hover:underline">
                    {t("budget.why")}
                    <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
                  </button>
                </div>
                {open && (
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-2 rounded-lg border border-line/60 bg-elevated/40 px-2.5 py-2 text-[11.5px] leading-relaxed text-muted"
                  >
                    {limit.reason}
                  </motion.p>
                )}
              </CardContent>
            </Card>
          );
        })}
        {!limits.length && <p className="py-10 text-center text-[12.5px] text-faint">{t("budget.empty")}</p>}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4 text-amber-300" />
            {t("budget.minimize")}
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-2 pt-2 sm:grid-cols-3">
          {suggestions.map((item) => (
            <div key={item.text} className="flex items-start gap-2.5 rounded-xl border border-line/60 bg-elevated/25 p-3">
              <item.icon className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
              <p className="text-[12px] leading-relaxed text-muted">{item.text}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
