"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight, BadgeIndianRupee, Boxes, Check, Copy, MessageCircle, Plus, Store, Users, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Label } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/controls";
import { Dialog, DialogContent, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { useI18n, useToast } from "@/components/providers";
import { inr } from "@/lib/money";
import { shortDate } from "@/lib/dates";
import { cn } from "@/lib/utils";

export interface BusinessData {
  entries: { id: string; date: string; kind: string; amount: number; note: string | null; category: string | null }[];
  credits: { id: string; customerName: string; phone: string | null; amountOwed: number; dueDate: string; status: string; lastReminderAt: string | null; note: string | null }[];
  borrowed: { id: string; lenderName: string; amount: number; dueDate: string; status: string; note: string | null }[];
  summary: {
    todaySales: number;
    weekSales: number;
    monthSales: number;
    todayExpenses: number;
    weekExpenses: number;
    monthExpenses: number;
    monthProfit: number;
    stockSpend: number;
    outstanding: number;
    borrowedTotal: number;
  };
}

export function BusinessView({ initial, shopName }: { initial: BusinessData; shopName: string }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const locale = lang === "en" ? "en-IN" : `${lang}-IN`;
  const [data, setData] = React.useState(initial);
  const [dialog, setDialog] = React.useState<"sale" | "expense" | "credit" | "borrowed" | null>(null);
  const [form, setForm] = React.useState({ amount: "", note: "", customerName: "", phone: "", dueDate: "", lenderName: "" });
  const [busy, setBusy] = React.useState(false);
  const [reminder, setReminder] = React.useState<string | null>(null);

  async function post(body: Record<string, unknown>) {
    setBusy(true);
    try {
      const res = await fetch("/api/business", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await res.json()) as BusinessData & { message?: string; error?: string };
      if (!res.ok) throw new Error(payload.error ?? "failed");
      if (payload.entries) setData(payload);
      return payload;
    } catch {
      toast({ kind: "error", title: t("common.error") });
      return null;
    } finally {
      setBusy(false);
    }
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!dialog) return;
    if (dialog === "sale" || dialog === "expense") {
      const ok = await post({ action: dialog, amount: Number(form.amount), note: form.note, category: dialog === "expense" ? form.note || "Shop expense" : "Sales" });
      if (ok) toast({ kind: "success", title: t("biz.added") });
    } else if (dialog === "credit") {
      const ok = await post({
        action: "credit",
        customerName: form.customerName,
        phone: form.phone,
        amountOwed: Number(form.amount),
        dueDate: form.dueDate || undefined,
        note: form.note,
      });
      if (ok) toast({ kind: "success", title: t("biz.added") });
    } else if (dialog === "borrowed") {
      const ok = await post({ action: "borrowed", lenderName: form.lenderName, amount: Number(form.amount), dueDate: form.dueDate || undefined, note: form.note });
      if (ok) toast({ kind: "success", title: t("biz.added") });
    }
    setDialog(null);
    setForm({ amount: "", note: "", customerName: "", phone: "", dueDate: "", lenderName: "" });
  }

  async function remind(creditId: string) {
    const payload = await post({ action: "remind", creditId });
    if (payload?.message) {
      setReminder(payload.message);
      try {
        await navigator.clipboard.writeText(payload.message);
        toast({ kind: "success", title: t("common.copied") });
      } catch {
        /* clipboard can be blocked */
      }
    }
  }

  async function markPaid(creditId: string) {
    const ok = await post({ action: "markPaid", creditId });
    if (ok) toast({ kind: "success", title: t("biz.markPaid") });
  }

  const summary = data.summary;
  const salesEntries = data.entries.filter((e) => e.kind === "SALE");
  const expenseEntries = data.entries.filter((e) => e.kind === "EXPENSE");

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Store className="h-5 w-5 text-brand-300" />
            <h1 className="h1">{t("biz.title")}</h1>
          </div>
          <p className="mt-1 text-sm text-muted">{shopName} · {t("biz.subtitle")}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={() => setDialog("sale")}>
            <Plus className="h-4 w-4" />
            {t("biz.addSale")}
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setDialog("expense")}>
            <ArrowUpRight className="h-4 w-4" />
            {t("biz.addExpense")}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: `${t("biz.sales")} · ${t("biz.today")}`, value: summary.todaySales, icon: ArrowDownLeft, tone: "text-emerald-300" },
          { label: `${t("biz.sales")} · ${t("biz.week")}`, value: summary.weekSales, icon: BadgeIndianRupee, tone: "text-brand-300" },
          { label: t("biz.profit"), value: summary.monthProfit, icon: Wallet, tone: summary.monthProfit >= 0 ? "text-emerald-300" : "text-rose-300" },
          { label: t("biz.owed"), value: summary.outstanding, icon: Users, tone: "text-amber-300" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-3.5">
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-faint">
                <stat.icon className={cn("h-3.5 w-3.5", stat.tone)} />
                <span className="truncate">{stat.label}</span>
              </div>
              <p className={cn("num mt-1.5 text-[17px] font-semibold", stat.tone)}>{inr(stat.value, lang)}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="ledger">
        <TabsList className="w-full justify-start overflow-x-auto sm:w-auto">
          <TabsTrigger value="ledger">{t("biz.sales")}</TabsTrigger>
          <TabsTrigger value="udhaar">{t("biz.udhaar")}</TabsTrigger>
          <TabsTrigger value="borrowed">{t("biz.borrowed")}</TabsTrigger>
          <TabsTrigger value="pnl">{t("biz.pnl")}</TabsTrigger>
        </TabsList>

        <TabsContent value="ledger">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle>{t("biz.sales")}</CardTitle>
                <Badge variant="safe">{inr(summary.monthSales, lang)} {t("biz.month")}</Badge>
              </CardHeader>
              <CardContent className="max-h-[420px] space-y-1.5 overflow-y-auto pt-2 scrollbar-thin">
                {salesEntries.slice(0, 30).map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between rounded-lg border border-line/50 px-3 py-2">
                    <div>
                      <p className="text-[12px] font-medium">{entry.note || entry.category}</p>
                      <p className="text-[10px] text-faint">{shortDate(entry.date, locale)}</p>
                    </div>
                    <p className="num text-[12.5px] font-semibold text-emerald-300">+{inr(entry.amount, lang)}</p>
                  </div>
                ))}
                {!salesEntries.length && <p className="py-8 text-center text-[12px] text-faint">{t("dash.empty")}</p>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle>{t("biz.expenses")}</CardTitle>
                <Badge variant="caution">{inr(summary.monthExpenses, lang)} {t("biz.month")}</Badge>
              </CardHeader>
              <CardContent className="max-h-[420px] space-y-1.5 overflow-y-auto pt-2 scrollbar-thin">
                {expenseEntries.slice(0, 30).map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between rounded-lg border border-line/50 px-3 py-2">
                    <div>
                      <p className="text-[12px] font-medium">{entry.note || entry.category}</p>
                      <p className="text-[10px] text-faint">
                        {shortDate(entry.date, locale)} · {entry.category}
                      </p>
                    </div>
                    <p className="num text-[12.5px] font-semibold text-rose-300">−{inr(entry.amount, lang)}</p>
                  </div>
                ))}
                {!expenseEntries.length && <p className="py-8 text-center text-[12px] text-faint">{t("dash.empty")}</p>}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="udhaar">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <div>
                <CardTitle>{t("biz.udhaar")}</CardTitle>
                <p className="text-[11.5px] text-muted">{inr(summary.outstanding, lang)} {t("biz.owed")}</p>
              </div>
              <Button size="sm" variant="secondary" onClick={() => setDialog("credit")}>
                <Plus className="h-4 w-4" />
                {t("common.add")}
              </Button>
            </CardHeader>
            <CardContent className="space-y-2 pt-3">
              {data.credits.map((credit) => {
                const overdue = credit.status !== "PAID" && new Date(credit.dueDate) < new Date();
                return (
                  <div key={credit.id} className={cn("rounded-xl border p-3", overdue ? "border-rose-500/30 bg-rose-500/5" : "border-line/60 bg-elevated/25")}>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand/12 text-[11px] font-semibold text-brand-200">
                        {credit.customerName.slice(0, 2).toUpperCase()}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-medium">{credit.customerName}</p>
                        <p className="text-[10.5px] text-faint">
                          {credit.phone ?? "—"} · {t("biz.due")} {shortDate(credit.dueDate, locale)}
                        </p>
                      </div>
                      <p className="num text-[14px] font-semibold">{inr(credit.amountOwed, lang)}</p>
                      {credit.status === "PAID" ? (
                        <Badge variant="safe">{t("biz.markPaid")}</Badge>
                      ) : (
                        <div className="flex gap-1.5">
                          <Button size="sm" variant="secondary" onClick={() => remind(credit.id)} loading={busy}>
                            <MessageCircle className="h-3.5 w-3.5" />
                            {t("biz.remind")}
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => markPaid(credit.id)}>
                            <Check className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      )}
                    </div>
                    {overdue && <p className="mt-1.5 text-[10.5px] text-rose-300">Overdue · reminder recommended</p>}
                  </div>
                );
              })}
              {!data.credits.length && <p className="py-8 text-center text-[12px] text-faint">{t("biz.noCredits")}</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="borrowed">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <div>
                <CardTitle>{t("biz.borrowed")}</CardTitle>
                <p className="text-[11.5px] text-muted">{inr(summary.borrowedTotal, lang)}</p>
              </div>
              <Button size="sm" variant="secondary" onClick={() => setDialog("borrowed")}>
                <Plus className="h-4 w-4" />
                {t("common.add")}
              </Button>
            </CardHeader>
            <CardContent className="space-y-2 pt-3">
              {data.borrowed.map((item) => (
                <div key={item.id} className="flex items-center justify-between rounded-xl border border-line/60 bg-elevated/25 p-3">
                  <div>
                    <p className="text-[13px] font-medium">{item.lenderName}</p>
                    <p className="text-[10.5px] text-faint">
                      {t("biz.due")} {shortDate(item.dueDate, locale)} · {item.note ?? ""}
                    </p>
                  </div>
                  <p className="num text-[14px] font-semibold text-amber-300">{inr(item.amount, lang)}</p>
                </div>
              ))}
              {!data.borrowed.length && <p className="py-8 text-center text-[12px] text-faint">{t("biz.noCredits")}</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pnl">
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { label: t("biz.sales"), value: summary.monthSales, tone: "text-emerald-300" },
              { label: t("biz.expenses"), value: summary.monthExpenses, tone: "text-rose-300" },
              { label: t("biz.profit"), value: summary.monthProfit, tone: summary.monthProfit >= 0 ? "text-emerald-300" : "text-rose-300" },
            ].map((row) => (
              <Card key={row.label}>
                <CardContent className="p-5">
                  <p className="text-[10.5px] uppercase tracking-wider text-faint">{row.label} · {t("biz.month")}</p>
                  <p className={cn("num mt-2 font-display text-2xl font-semibold", row.tone)}>{inr(row.value, lang)}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Boxes className="h-4 w-4 text-brand-300" />
                {t("biz.inventory")}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-1">
              <p className="text-[12.5px] text-muted">
                {inr(summary.stockSpend, lang)} spent on stock in the last 30 days. That is{" "}
                {summary.monthSales ? Math.round((summary.stockSpend / summary.monthSales) * 100) : 0}% of sales.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={!!dialog} onOpenChange={(open) => !open && setDialog(null)}>
        <DialogContent className="max-w-sm">
          <DialogTitle>
            {dialog === "sale" ? t("biz.addSale") : dialog === "expense" ? t("biz.addExpense") : dialog === "credit" ? t("biz.udhaar") : t("biz.borrowed")}
          </DialogTitle>
          <form onSubmit={submit} className="space-y-3">
            {dialog === "credit" && (
              <div className="space-y-1.5">
                <Label>{t("biz.customer")}</Label>
                <Input value={form.customerName} onChange={(e) => setForm((p) => ({ ...p, customerName: e.target.value }))} required />
              </div>
            )}
            {dialog === "credit" && (
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input inputMode="tel" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
              </div>
            )}
            {dialog === "borrowed" && (
              <div className="space-y-1.5">
                <Label>{t("biz.lender")}</Label>
                <Input value={form.lenderName} onChange={(e) => setForm((p) => ({ ...p, lenderName: e.target.value }))} required />
              </div>
            )}
            <div className="space-y-1.5">
              <Label>{t("pay.amount")}</Label>
              <Input
                inputMode="numeric"
                value={form.amount}
                onChange={(e) => setForm((p) => ({ ...p, amount: e.target.value.replace(/[^\d]/g, "") }))}
                required
              />
            </div>
            {(dialog === "credit" || dialog === "borrowed") && (
              <div className="space-y-1.5">
                <Label>{t("biz.due")}</Label>
                <Input type="date" value={form.dueDate} onChange={(e) => setForm((p) => ({ ...p, dueDate: e.target.value }))} />
              </div>
            )}
            {dialog !== "credit" && dialog !== "borrowed" && (
              <div className="space-y-1.5">
                <Label>{t("tx.payee")}</Label>
                <Input value={form.note} onChange={(e) => setForm((p) => ({ ...p, note: e.target.value }))} placeholder="Stock purchase, evening sales…" />
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setDialog(null)}>
                {t("common.cancel")}
              </Button>
              <Button type="submit" loading={busy}>
                {t("common.save")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!reminder} onOpenChange={(open) => !open && setReminder(null)}>
        <DialogContent className="max-w-md">
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5 text-emerald-300" />
            {t("biz.reminder")}
          </DialogTitle>
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3 text-[12.5px] leading-relaxed text-emerald-100">
            {reminder}
          </div>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={async () => {
                if (reminder) {
                  await navigator.clipboard.writeText(reminder);
                  toast({ kind: "success", title: t("common.copied") });
                }
              }}
            >
              <Copy className="h-4 w-4" />
              {t("biz.copy")}
            </Button>
            <Button className="flex-1" asChild>
              <a href={`https://wa.me/?text=${encodeURIComponent(reminder ?? "")}`} target="_blank" rel="noreferrer">
                WhatsApp
              </a>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="hidden">
        <motion.div />
      </div>
    </div>
  );
}
