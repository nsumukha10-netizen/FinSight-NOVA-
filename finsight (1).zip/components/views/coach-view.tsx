"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Loader2, Mic, Send, Sparkles, Square, Volume2, VolumeX } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/controls";
import { useI18n, useToast } from "@/components/providers";
import { speak, stopSpeaking } from "@/lib/speech";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export function CoachView({ name, voiceEnabled }: { name: string; voiceEnabled: boolean }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [speakReplies, setSpeakReplies] = React.useState(voiceEnabled);
  const [recording, setRecording] = React.useState(false);
  const [transcribing, setTranscribing] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const recorderRef = React.useRef<MediaRecorder | null>(null);
  const chunksRef = React.useRef<Blob[]>([]);
  const streamRef = React.useRef<MediaStream | null>(null);

  const suggestions = [t("coach.s1"), t("coach.s2"), t("coach.s3"), t("coach.s4")];

  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  React.useEffect(() => () => stopSpeaking(), []);

  async function send(text: string) {
    const clean = text.trim();
    if (!clean || loading) return;
    const userMessage: Message = { id: crypto.randomUUID(), role: "user", content: clean };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);
    try {
      const history = messages.slice(-8).map((m) => ({ role: m.role, content: m.content }));
      const res = await fetch("/api/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: clean, history }),
      });
      const data = (await res.json()) as { reply?: string; error?: string };
      if (!res.ok || !data.reply) throw new Error(data.error ?? "failed");
      setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: "assistant", content: data.reply as string }]);
      if (speakReplies) await speak(data.reply, lang);
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setLoading(false);
    }
  }

  async function startRecording() {
    try {
      stopSpeaking();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "" });
      chunksRef.current = [];
      recorder.ondataavailable = (event) => event.data.size && chunksRef.current.push(event.data);
      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        if (blob.size < 800) return;
        setTranscribing(true);
        try {
          const form = new FormData();
          form.append("audio", blob, "speech.webm");
          form.append("language", lang);
          const res = await fetch("/api/voice/stt", { method: "POST", body: form });
          const data = (await res.json()) as { transcript?: string };
          if (data.transcript) await send(data.transcript);
        } catch {
          toast({ kind: "error", title: t("voice.error") });
        } finally {
          setTranscribing(false);
        }
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
    } catch {
      toast({ kind: "error", title: t("voice.error"), description: t("voice.type") });
    }
  }

  function stopRecording() {
    recorderRef.current?.stop();
    setRecording(false);
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="h1">{t("coach.title")}</h1>
        <p className="mt-1 text-sm text-muted">{t("coach.subtitle")}</p>
      </div>

      <Card className="overflow-hidden">
        <div className="flex items-center gap-3 border-b border-line/60 bg-elevated/25 px-4 py-3">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-emerald-500 text-white">
            <Sparkles className="h-5 w-5" />
            <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-surface bg-emerald-400" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-semibold">FinSight {t("coach.title")}</p>
            <p className="text-[11px] text-muted">{t("coach.disclaimer")}</p>
          </div>
          <div className="flex items-center gap-2">
            {speakReplies ? <Volume2 className="h-4 w-4 text-brand-300" /> : <VolumeX className="h-4 w-4 text-faint" />}
            <Switch checked={speakReplies} onCheckedChange={setSpeakReplies} aria-label={t("coach.voice")} />
          </div>
        </div>

        <div ref={scrollRef} className="max-h-[52vh] min-h-[320px] space-y-3 overflow-y-auto p-4 scrollbar-thin">
          {!messages.length && (
            <div className="flex h-full min-h-[280px] flex-col items-center justify-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-3xl bg-brand/12 text-brand-200">
                <Sparkles className="h-7 w-7" />
              </span>
              <p className="mt-3 font-display text-[15px] font-semibold">{t("dash.greeting", { name: name.split(" ")[0] })}</p>
              <p className="mt-1 max-w-sm text-[12.5px] text-muted">{t("coach.subtitle")}</p>
              <div className="mt-4 grid w-full max-w-md gap-2 sm:grid-cols-2">
                {suggestions.map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => send(suggestion)}
                    className="rounded-xl border border-line/70 bg-elevated/30 px-3 py-2.5 text-left text-[11.5px] text-muted transition-colors hover:border-brand/40 hover:text-ink"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn("flex", message.role === "user" ? "justify-end" : "justify-start")}
              >
                <div
                  className={cn(
                    "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[12.5px] leading-relaxed",
                    message.role === "user"
                      ? "rounded-br-md bg-brand text-white"
                      : "rounded-bl-md border border-line/70 bg-elevated/50 text-ink",
                  )}
                >
                  {message.content}
                  {message.role === "assistant" && (
                    <button
                      onClick={() => speak(message.content, lang)}
                      className="mt-1.5 flex items-center gap-1 text-[10.5px] text-brand-300 hover:underline"
                    >
                      <Volume2 className="h-3 w-3" />
                      {t("voice.speak")}
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {(loading || transcribing) && (
            <div className="flex items-center gap-2 text-[11.5px] text-muted">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-brand-300" />
              {transcribing ? t("voice.processing") : t("coach.thinking")}
            </div>
          )}
        </div>

        <form
          onSubmit={(event) => {
            event.preventDefault();
            void send(input);
          }}
          className="flex items-center gap-2 border-t border-line/60 bg-elevated/20 p-3"
        >
          <Input
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder={t("coach.placeholder")}
            className="h-11 flex-1"
            aria-label={t("coach.placeholder")}
          />
          <Button
            type="button"
            variant={recording ? "danger" : "secondary"}
            size="icon"
            onClick={recording ? stopRecording : startRecording}
            aria-label={t("voice.listen")}
          >
            {recording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Button type="submit" size="icon" disabled={!input.trim() || loading} aria-label={t("coach.send")}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </Card>

      <p className="text-center text-[11px] text-faint">{t("coach.disclaimer")}</p>
    </div>
  );
}
