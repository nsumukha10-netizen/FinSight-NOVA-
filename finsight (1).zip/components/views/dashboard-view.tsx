"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  CalendarClock,
  ChartNoAxesCombined,
  CircleAlert,
  Mic,
  Plus,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CountUp } from "@/components/ui/count-up";
import { CategoryDonut, ForecastChart, HealthRing } from "@/components/charts";
import { usePayment } from "@/components/payments/payment-flow";
import { useI18n } from "@/components/providers";
import { categoryI18nKey, categoryColor } from "@/lib/categories";
import { inr, inrCompact } from "@/lib/money";
import { shortDate } from "@/lib/dates";
import type { ForecastPoint, HealthResult } from "@/lib/types";
import { cn } from "@/lib/utils";

export interface DashboardData {
  name: string;
  persona: string;
  isDemo: boolean;
  balance: number;
  bankName: string | null;
  last4: string | null;
  monthIncome: number;
  monthExpenses: number;
  monthlyObligations: number;
  runwayDays: number;
  health: HealthResult;
  forecast: {
    points: ForecastPoint[];
    shortageDate: string | null;
    shortageProbability: number;
    endP50: number;
    endP10: number;
    endP90: number;
    cumulativeShortage: number[];
  };
  limits: { category: string; monthlyLimit: number; spent: number }[];
  spendByCategory: Record<string, number>;
  upcomingBills: { name: string; amount: number; dueDate: string; daysAway: number }[];
  recent: { id: string; date: string; amount: number; type: string; payee: string; category: string; isAnomaly: boolean; voiceLabel: string | null }[];
  goals: { id: string; name: string; targetAmount: number; savedAmount: number }[];
}

export function DashboardView({ data }: { data: DashboardData }) {
  const { t, lang } = useI18n();
  const { open, demo } = usePayment();
  const [horizon, setHorizon] = React.useState(30);

  const points = data.forecast.points.slice(0, horizon);
  const shortage30 = data.forecast.cumulativeShortage[29] ?? 0;
  const shortageNow = data.forecast.cumulativeShortage[horizon - 1] ?? 0;
  const hasShortage = shortageNow >= 0.25 || (data.forecast.shortageDate !== null && shortage30 >= 0.2);

  const donut = React.useMemo(() => {
    return Object.entries(data.spendByCategory)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([name, value]) => ({ name: t(categoryI18nKey(name)), value, color: categoryColor(name) }));
  }, [data.spendByCategory, t]);

  const today = new Date().toLocaleDateString(lang === "en" ? "en-IN" : `${lang}-IN`, {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-faint">{today}</p>
          <h1 className="h1 mt-1">{t("dash.greeting", { name: data.name.split(" ")[0] })}</h1>
        </div>
        {data.isDemo && (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" onClick={() => demo("swiggy")}>
              <span className="mr-1">🍔</span> Swiggy payment
            </Button>
            <Button size="sm" variant="secondary" onClick={() => demo("unknown")}>
              <span className="mr-1">⚠️</span> ₹48,000 unknown
            </Button>
          </div>
        )}
      </div>

      {hasShortage && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl border border-rose-500/35 bg-gradient-to-r from-rose-500/15 via-rose-500/8 to-transparent p-4 glow-critical"
        >
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-500/20 text-rose-300 animate-pulse-glow">
              <CircleAlert className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-[15px] font-semibold text-rose-100">{t("dash.shortageTitle")}</p>
              <p className="text-[12.5px] text-rose-200/80">
                {t("dash.shortageBody", {
                  date: data.forecast.shortageDate ? shortDate(data.forecast.shortageDate, lang === "en" ? "en-IN" : `${lang}-IN`) : "—",
                  prob: Math.round(shortage30 * 100),
                })}
              </p>
            </div>
            <Button size="sm" variant="outline" asChild className="border-rose-500/40 text-rose-100">
              <Link href="/forecast">
                {t("fc.why")}
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </div>
        </motion.div>
      )}

      <div className="grid gap-5 lg:grid-cols-12">
        <Card className="lg:col-span-7">
          <CardContent className="relative overflow-hidden">
            <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-brand-500/15 blur-3xl" />
            <div className="flex items-start justify-between">
              <div>
                <p className="label">{t("dash.balance")}</p>
                <p className="num mt-2 font-display text-[40px] font-semibold leading-none tracking-tight sm:text-[46px]">
                  <CountUp value={data.balance} format={(n) => inr(n, lang)} />
                </p>
                <p className="mt-2 text-[12px] text-muted">
                  {data.bankName ? `${data.bankName} •••• ${data.last4}` : t("onboarding.bank.title")}
                </p>
              </div>
              <Badge variant={data.runwayDays >= 90 ? "safe" : data.runwayDays >= 30 ? "caution" : "critical"}>
                <Wallet className="h-3 w-3" />
                {data.runwayDays} {t("common.days")}
              </Badge>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-2">
              {[
                { label: t("dash.income"), value: data.monthIncome, icon: ArrowDownLeft, color: "text-emerald-300" },
                { label: t("dash.spend"), value: data.monthExpenses, icon: ArrowUpRight, color: "text-rose-300" },
                { label: t("dash.obligations"), value: data.monthlyObligations, icon: CalendarClock, color: "text-amber-300" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-xl border border-line/60 bg-elevated/30 p-3">
                  <div className="flex items-center gap-1.5">
                    <stat.icon className={cn("h-3.5 w-3.5", stat.color)} />
                    <p className="truncate text-[10.5px] uppercase tracking-wider text-faint">{stat.label}</p>
                  </div>
                  <p className="num mt-1.5 text-[15px] font-semibold">{inrCompact(stat.value, lang)}</p>
                </div>
              ))}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <Button size="sm" onClick={() => open()}>
                <Plus className="h-4 w-4" />
                {t("dash.addExpense")}
              </Button>
              <Button size="sm" variant="secondary" asChild>
                <Link href="/simulator">
                  <ChartNoAxesCombined className="h-4 w-4" />
                  {t("dash.simulate")}
                </Link>
              </Button>
              <Button size="sm" variant="secondary" asChild>
                <Link href="/coach">
                  <Sparkles className="h-4 w-4" />
                  {t("dash.askCoach")}
                </Link>
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => window.dispatchEvent(new CustomEvent("finsight:open-voice"))}
              >
                <Mic className="h-4 w-4" />
                {t("dash.speak")}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-5">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>{t("dash.health")}</CardTitle>
              <p className="text-[11.5px] text-muted">{data.health.grade}</p>
            </div>
            <Badge variant={data.health.score >= 65 ? "safe" : data.health.score >= 45 ? "caution" : "critical"}>
              {data.health.grade}
            </Badge>
          </CardHeader>
          <CardContent className="flex items-center gap-5 pt-3">
            <HealthRing score={data.health.score} size={118} />
            <div className="min-w-0 flex-1 space-y-2">
              {data.health.parts.slice(0, 3).map((part) => (
                <div key={part.key}>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted">{part.label}</span>
                    <span className="num font-medium">{part.score}</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-elevated">
                    <motion.div
                      className={cn("h-full rounded-full", part.score >= 65 ? "bg-emerald-400" : part.score >= 45 ? "bg-amber-400" : "bg-rose-400")}
                      initial={{ width: 0 }}
                      animate={{ width: `${part.score}%` }}
                      transition={{ duration: 0.8 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-8">
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle>{t("dash.forecast")}</CardTitle>
              <p className="text-[11.5px] text-muted">{t("fc.subtitle")}</p>
            </div>
            <div className="flex items-center gap-1 rounded-full border border-line/70 bg-elevated/40 p-1">
              {[30, 60, 90].map((option) => (
                <button
                  key={option}
                  onClick={() => setHorizon(option)}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors",
                    horizon === option ? "bg-brand text-white" : "text-faint hover:text-ink",
                  )}
                >
                  {t(`fc.h${option}`)}
                </button>
              ))}
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="mb-2 flex flex-wrap items-center gap-4 text-[11px] text-muted">
              <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-gradient-to-r from-brand-400 to-emerald-400" />{t("fc.expected")}</span>
              <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-brand/25" />{t("fc.best")} / {t("fc.worst")}</span>
              <span className="ml-auto num">
                {t("dash.expected")}: <span className="font-medium text-ink">{inr(data.forecast.endP50, lang)}</span>
              </span>
            </div>
            <ForecastChart points={points} height={230} />
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11.5px]">
              <p className={cn("flex items-center gap-1.5", shortageNow >= 0.4 ? "text-rose-300" : shortageNow >= 0.2 ? "text-amber-300" : "text-emerald-300")}>
                {shortageNow >= 0.4 ? <TrendingDown className="h-3.5 w-3.5" /> : <TrendingUp className="h-3.5 w-3.5" />}
                {t("fc.shortageProbNote", { p: Math.round(shortageNow * 100), h: horizon })}
              </p>
              <Link href="/forecast" className="flex items-center gap-1 text-brand-300 hover:underline">
                {t("common.viewAll")} <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-4">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>{t("dash.upcoming")}</CardTitle>
            <Badge>{data.upcomingBills.length}</Badge>
          </CardHeader>
          <CardContent className="space-y-2 pt-3">
            {data.upcomingBills.slice(0, 5).map((bill) => (
              <div key={`${bill.name}-${bill.dueDate}`} className="flex items-center gap-3 rounded-xl border border-line/60 bg-elevated/25 px-3 py-2.5">
                <div className="flex h-8 w-8 shrink-0 flex-col items-center justify-center rounded-lg bg-brand/12 text-brand-200">
                  <span className="text-[10px] font-semibold leading-none">{new Date(bill.dueDate).getDate()}</span>
                  <span className="text-[8px] uppercase leading-none">
                    {new Date(bill.dueDate).toLocaleDateString("en-IN", { month: "short" })}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-medium">{bill.name}</p>
                  <p className="text-[10.5px] text-faint">
                    {bill.daysAway === 0 ? t("dash.today") : t("dash.billsDue", { n: bill.daysAway })}
                  </p>
                </div>
                <p className="num text-[12.5px] font-semibold">{inr(bill.amount, lang)}</p>
              </div>
            ))}
            {!data.upcomingBills.length && <p className="py-6 text-center text-[12px] text-faint">{t("dash.noShortage")}</p>}
          </CardContent>
        </Card>

        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>{t("dash.categories")}</CardTitle>
          </CardHeader>
          <CardContent className="pt-3">
            {donut.length ? <CategoryDonut data={donut} /> : <p className="py-8 text-center text-[12px] text-faint">{t("dash.empty")}</p>}
          </CardContent>
        </Card>

        <Card className="lg:col-span-8">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>{t("dash.recent")}</CardTitle>
            <Link href="/transactions" className="flex items-center gap-1 text-[11.5px] text-brand-300 hover:underline">
              {t("common.viewAll")} <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="divide-y divide-line/60">
              {data.recent.map((tx) => (
                <div key={tx.id} className="flex items-center gap-3 py-2.5">
                  <span
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                      tx.type === "CREDIT" ? "bg-emerald-500/12 text-emerald-300" : "bg-elevated text-muted",
                    )}
                  >
                    {tx.type === "CREDIT" ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-medium">
                      {tx.voiceLabel ? `${tx.voiceLabel} · ${tx.payee}` : tx.payee}
                    </p>
                    <p className="text-[10.5px] text-faint">
                      {t(categoryI18nKey(tx.category))} · {shortDate(tx.date, lang === "en" ? "en-IN" : `${lang}-IN`)}
                    </p>
                  </div>
                  {tx.isAnomaly && <Badge variant="critical">{t("tx.anomaly")}</Badge>}
                  <p className={cn("num text-[12.5px] font-semibold", tx.type === "CREDIT" ? "text-emerald-300" : "text-ink")}>
                    {tx.type === "CREDIT" ? "+" : "−"}
                    {inr(tx.amount, lang)}
                  </p>
                </div>
              ))}
              {!data.recent.length && <p className="py-8 text-center text-[12px] text-faint">{t("dash.empty")}</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
