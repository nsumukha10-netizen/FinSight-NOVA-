"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Activity, CalendarX2, CircleHelp, Gauge, LineChart, Sparkles, Target, TriangleAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BacktestChart, ForecastChart } from "@/components/charts";
import { useI18n } from "@/components/providers";
import { inr, inrCompact } from "@/lib/money";
import { longDate } from "@/lib/dates";
import type { BacktestResult, ForecastPoint } from "@/lib/types";
import { cn } from "@/lib/utils";

export interface ForecastViewData {
  balance: number;
  points: ForecastPoint[];
  cumulativeShortage: number[];
  shortageDate: string | null;
  shortageProbability: number;
  moneyEmptyDate: string | null;
  endP50: number;
  endP10: number;
  endP90: number;
  drivers: { label: string; value: string }[];
  engine: string;
  incomeModel: string;
  dailySpendMean: number;
  monthlyFixed: number;
  backtest: BacktestResult;
}

export function ForecastView({ data }: { data: ForecastViewData }) {
  const { t, lang } = useI18n();
  const locale = lang === "en" ? "en-IN" : `${lang}-IN`;
  const [horizon, setHorizon] = React.useState(90);
  const [showWhy, setShowWhy] = React.useState(false);

  const points = data.points.slice(0, horizon);
  const shortage = data.cumulativeShortage[horizon - 1] ?? 0;
  const last = points.at(-1);
  const minPoint = points.reduce((min, p) => (p.p50 < min.p50 ? p : min), points[0]);
  const tone = shortage >= 0.5 ? "critical" : shortage >= 0.25 ? "caution" : "safe";

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="h1">{t("fc.title")}</h1>
          <p className="mt-1 text-sm text-muted">{t("fc.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="brand">
            <Activity className="h-3 w-3" />
            {t("fc.engine")}: {data.engine}
          </Badge>
          <div className="flex items-center gap-1 rounded-full border border-line/70 bg-elevated/40 p-1">
            {[30, 60, 90].map((option) => (
              <button
                key={option}
                onClick={() => setHorizon(option)}
                className={cn(
                  "rounded-full px-3 py-1 text-[11.5px] font-medium transition-colors",
                  horizon === option ? "bg-brand text-white" : "text-faint hover:text-ink",
                )}
              >
                {t(`fc.h${option}`)}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className={cn(tone === "critical" && "glow-critical border-rose-500/30")}>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-faint">
              <TriangleAlert className={cn("h-3.5 w-3.5", tone === "critical" ? "text-rose-400" : tone === "caution" ? "text-amber-400" : "text-emerald-400")} />
              {t("fc.shortage")}
            </div>
            <p className={cn("num mt-2 font-display text-3xl font-semibold", tone === "critical" ? "text-rose-300" : tone === "caution" ? "text-amber-300" : "text-emerald-300")}>
              {Math.round(shortage * 100)}%
            </p>
            <p className="mt-1 text-[11px] text-faint">{t("fc.shortageProbNote", { p: Math.round(shortage * 100), h: horizon })}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-faint">
              <CalendarX2 className="h-3.5 w-3.5 text-rose-400" />
              {t("fc.emptyDate")}
            </div>
            <p className="mt-2 font-display text-lg font-semibold">
              {data.shortageDate ? longDate(data.shortageDate, locale) : t("fc.none")}
            </p>
            <p className="mt-1 text-[11px] text-faint">
              {t("dash.worst")}: {inrCompact(minPoint?.p10 ?? 0, lang)} · {t("dash.expected")}: {inrCompact(minPoint?.p50 ?? 0, lang)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-faint">
              <Target className="h-3.5 w-3.5 text-brand-300" />
              {t("sim.end")}
            </div>
            <p className="num mt-2 font-display text-2xl font-semibold">{inr(last?.p50 ?? 0, lang)}</p>
            <p className="mt-1 text-[11px] text-faint">
              {inrCompact(last?.p10 ?? 0, lang)} – {inrCompact(last?.p90 ?? 0, lang)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-faint">
              <Gauge className="h-3.5 w-3.5 text-amber-300" />
              {t("dash.balance")}
            </div>
            <p className="num mt-2 font-display text-2xl font-semibold">{inr(data.balance, lang)}</p>
            <p className="mt-1 text-[11px] text-faint">
              {t("budget.spent")}: {inr(data.dailySpendMean, lang)}/{t("common.day")} · {inr(data.monthlyFixed, lang)} fixed
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-2">
          <div>
            <CardTitle>{t("fc.title")}</CardTitle>
            <p className="text-[11.5px] text-muted">
              {t("fc.uncertaintyBody", {
                low: inr(last?.p10 ?? 0, lang),
                high: inr(last?.p90 ?? 0, lang),
                day: horizon,
              })}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-[11px] text-muted">
            <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-gradient-to-r from-brand-400 to-emerald-400" />{t("fc.expected")}</span>
            <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-brand/25" />{t("fc.best")} / {t("fc.worst")}</span>
          </div>
        </CardHeader>
        <CardContent className="pt-3">
          <ForecastChart points={points} height={320} />
        </CardContent>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CircleHelp className="h-4 w-4 text-brand-300" />
              {t("fc.why")}
            </CardTitle>
            <button onClick={() => setShowWhy((v) => !v)} className="text-[11.5px] text-brand-300 hover:underline">
              {showWhy ? t("common.close") : t("common.why")}
            </button>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="space-y-2">
              {data.drivers.map((driver, index) => (
                <motion.div
                  key={driver.label}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.04 }}
                  className="flex items-start justify-between gap-3 rounded-xl border border-line/60 bg-elevated/25 px-3 py-2.5"
                >
                  <span className="text-[12px] text-muted">{driver.label}</span>
                  <span className="num shrink-0 text-right text-[12px] font-medium">{driver.value}</span>
                </motion.div>
              ))}
            </div>
            <p className="mt-3 rounded-xl border border-brand/20 bg-brand/8 px-3 py-2 text-[11.5px] leading-relaxed text-brand-100">
              {t("fc.engine")}: {data.engine} · {data.incomeModel}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-4 w-4 text-emerald-300" />
                {t("fc.accuracy")}
              </CardTitle>
              <p className="text-[11.5px] text-muted">{t("fc.backtestNote", { train: data.backtest.trainDays, test: data.backtest.testDays })}</p>
            </div>
            <Badge variant={data.backtest.hitRate >= 70 ? "safe" : data.backtest.hitRate >= 50 ? "caution" : "critical"}>
              {data.backtest.hitRate}% {t("fc.hit")}
            </Badge>
          </CardHeader>
          <CardContent className="pt-2">
            <BacktestChart points={data.backtest.points} height={190} />
            <div className="mt-3 grid grid-cols-3 gap-2">
              {[
                [t("fc.mape"), `${data.backtest.mape.toFixed(1)}%`],
                [t("fc.mae"), inrCompact(data.backtest.mae, lang)],
                [t("fc.hit"), `${data.backtest.hitRate}%`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl border border-line/60 bg-elevated/25 p-2.5 text-center">
                  <p className="text-[10px] uppercase tracking-wider text-faint">{label}</p>
                  <p className="num mt-1 text-[13px] font-semibold">{value}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-brand/20 bg-brand/5">
        <CardContent className="flex flex-wrap items-center gap-3 p-4">
          <Sparkles className="h-4 w-4 text-brand-300" />
          <p className="min-w-0 flex-1 text-[12.5px] text-muted">
            {shortage >= 0.3
              ? `Keeping ${inr(Math.max(2000, Math.round((data.monthlyFixed - data.balance) / 4)), lang)} aside before your next bill would cut the shortage probability the most.`
              : `Your buffer looks healthy. Moving ${inr(Math.round(data.balance * 0.15), lang)} into a goal would keep the same safety margin.`}
          </p>
          <Badge variant="brand">{t("fc.why")}</Badge>
        </CardContent>
      </Card>
    </div>
  );
}
