"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight, Briefcase, Building2, Check, Mail, Phone, ShieldCheck, Sparkles, User, Wallet } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { LanguageSwitcher } from "@/components/shell/language-switcher";
import { HeroSpark } from "@/components/charts/hero-spark";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { useI18n } from "@/components/providers";
import { LANGUAGES } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const PERSONAS = [
  { key: "SALARIED", label: "landing.salaried", desc: "landing.salariedDesc", icon: Briefcase },
  { key: "IRREGULAR", label: "landing.irregular", desc: "landing.irregularDesc", icon: Wallet },
  { key: "BUSINESS", label: "landing.business", desc: "landing.businessDesc", icon: Building2 },
] as const;

export function LandingView() {
  const { t, lang, setLang } = useI18n();
  const router = useRouter();
  const [mode, setMode] = React.useState<"signup" | "login">("signup");
  const [persona, setPersona] = React.useState<string>("SALARIED");
  const [form, setForm] = React.useState({ name: "", email: "", phone: "" });
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [demoLoading, setDemoLoading] = React.useState<string | null>(null);

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: event.target.value }));

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (!form.email || !form.phone || (mode === "signup" && !form.name)) {
      setError(t("auth.errorRequired"));
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(mode === "signup" ? "/api/auth/signup" : "/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, persona, language: lang }),
      });
      const data = (await res.json()) as { redirect?: string; error?: string };
      if (!res.ok) {
        setError(data.error === "already_exists" ? t("auth.errorExists") : data.error === "invalid_credentials" ? t("auth.errorInvalid") : t("common.error"));
        setLoading(false);
        return;
      }
      router.push(data.redirect ?? "/dashboard");
      router.refresh();
    } catch {
      setError(t("common.error"));
      setLoading(false);
    }
  }

  async function demo(nextPersona: string) {
    setDemoLoading(nextPersona);
    try {
      const res = await fetch("/api/auth/demo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ persona: nextPersona }),
      });
      const data = (await res.json()) as { redirect?: string; error?: string };
      if (!res.ok) throw new Error(data.error);
      router.push(data.redirect ?? "/dashboard");
      router.refresh();
    } catch {
      setError(t("common.error"));
      setDemoLoading(null);
    }
  }

  return (
    <div className="relative min-h-dvh overflow-hidden">
      <div className="pointer-events-none absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-brand-500/20 blur-[140px]" />
      <div className="pointer-events-none absolute -right-32 top-24 h-[420px] w-[420px] rounded-full bg-emerald-500/12 blur-[120px]" />

      <header className="relative mx-auto flex max-w-6xl items-center justify-between px-5 py-6 sm:px-8">
        <Logo />
        <div className="flex items-center gap-3">
          <div className="hidden sm:block">
            <LanguageSwitcher />
          </div>
          <span className="pill hidden md:inline-flex">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
            {t("landing.trust")}
          </span>
        </div>
      </header>

      <main className="relative mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-4 sm:px-8 lg:grid-cols-[1.02fr_0.98fr] lg:items-center lg:gap-14">
        <motion.section
          initial={{ y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-xl"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-brand-200">
            <Sparkles className="h-3.5 w-3.5" />
            {t("landing.badge")}
          </span>
          <h1 className="mt-5 font-display text-[38px] font-semibold leading-[1.08] tracking-tight sm:text-[54px]">
            {t("landing.title")}
          </h1>
          <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-muted sm:text-base">{t("landing.subtitle")}</p>

          <ul className="mt-7 space-y-3">
            {["landing.feature1", "landing.feature2", "landing.feature3"].map((key) => (
              <li key={key} className="flex items-start gap-3 text-[13.5px] text-muted">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15">
                  <Check className="h-3 w-3 text-emerald-400" />
                </span>
                {t(key)}
              </li>
            ))}
          </ul>

          <div className="mt-9 rounded-2xl border border-line/60 bg-surface/40 p-4 backdrop-blur-xl">
            <div className="mb-1 flex items-center justify-between text-[11px] uppercase tracking-[0.14em] text-faint">
              <span>90-day cash flow</span>
              <span className="text-amber-300">Shortage risk 62%</span>
            </div>
            <HeroSpark />
            <div className="mt-1 flex items-center justify-between text-[10.5px] text-faint">
              <span>Today</span>
              <span>Day 45</span>
              <span>Day 90</span>
            </div>
          </div>
        </motion.section>

        <motion.section
          initial={{ y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.12, ease: "easeOut" }}
          className="w-full"
        >
          <div className="card overflow-hidden">
            <div className="border-b border-line/60 bg-elevated/30 px-6 py-5">
              <h2 className="font-display text-xl font-semibold tracking-tight">
                {mode === "signup" ? t("landing.cta") : t("auth.welcomeBack")}
              </h2>
              <p className="mt-1 text-[12.5px] text-muted">{t("landing.personaTitle")}</p>
            </div>

            <form onSubmit={submit} className="space-y-4 px-6 py-5">
              <div className="grid gap-2">
                {PERSONAS.map((item) => {
                  const active = persona === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setPersona(item.key)}
                      className={cn(
                        "flex items-center gap-3 rounded-xl border px-3.5 py-3 text-left transition-all",
                        active
                          ? "border-brand/60 bg-brand/12 shadow-[0_0_0_1px_rgba(79,70,229,0.35)]"
                          : "border-line/70 bg-elevated/30 hover:border-line hover:bg-elevated/50",
                      )}
                      aria-pressed={active}
                    >
                      <span className={cn("flex h-9 w-9 items-center justify-center rounded-lg", active ? "bg-brand/20 text-brand-200" : "bg-elevated text-faint")}>
                        <item.icon className="h-4 w-4" />
                      </span>
                      <span className="min-w-0">
                        <span className="block text-[13.5px] font-medium">{t(item.label)}</span>
                        <span className="block truncate text-[11.5px] text-faint">{t(item.desc)}</span>
                      </span>
                      <span className={cn("ml-auto h-4 w-4 rounded-full border", active ? "border-brand bg-brand" : "border-line")}>
                        {active && <Check className="h-3 w-3 p-[1px] text-white" />}
                      </span>
                    </button>
                  );
                })}
              </div>

              {mode === "signup" && (
                <div className="space-y-1.5">
                  <Label htmlFor="name">{t("landing.name")}</Label>
                  <div className="relative">
                    <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
                    <Input id="name" value={form.name} onChange={update("name")} className="pl-9" placeholder="Aarav Mehta" autoComplete="name" />
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="email">{t("landing.email")}</Label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
                  <Input id="email" type="email" value={form.email} onChange={update("email")} className="pl-9" placeholder="you@example.com" autoComplete="email" />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="phone">{t("landing.phone")}</Label>
                <div className="relative">
                  <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
                  <Input id="phone" inputMode="tel" value={form.phone} onChange={update("phone")} className="pl-9" placeholder="98765 43210" autoComplete="tel" />
                </div>
              </div>

              <div className="space-y-1.5 sm:hidden">
                <Label>{t("landing.language")}</Label>
                <select
                  value={lang}
                  onChange={(event) => setLang(event.target.value as typeof lang)}
                  className="h-11 w-full rounded-xl border border-line/90 bg-elevated/40 px-3 text-sm"
                >
                  {LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code} className="bg-surface">
                      {l.native}
                    </option>
                  ))}
                </select>
              </div>

              {error && <p className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-200">{error}</p>}

              <Button type="submit" className="w-full" size="lg" loading={loading}>
                {mode === "signup" ? t("landing.cta") : t("auth.signin")}
                {!loading && <ArrowRight className="h-4 w-4" />}
              </Button>

              <button
                type="button"
                onClick={() => {
                  setMode(mode === "signup" ? "login" : "signup");
                  setError(null);
                }}
                className="w-full text-center text-[12px] text-muted underline-offset-4 hover:text-ink hover:underline"
              >
                {mode === "signup" ? t("landing.login") : t("landing.signup")}
              </button>
            </form>

            <div className="border-t border-line/60 bg-elevated/20 px-6 py-4">
              <p className="mb-2 text-center text-[11px] uppercase tracking-[0.16em] text-faint">{t("landing.demoHint")}</p>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                {PERSONAS.map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => demo(item.key)}
                    disabled={!!demoLoading}
                    className="flex flex-col items-center gap-1 rounded-xl border border-line/70 bg-surface/60 px-2 py-2.5 text-[11px] text-muted transition-colors hover:border-brand/40 hover:text-ink disabled:opacity-60"
                  >
                    <item.icon className="h-4 w-4 text-brand-300" />
                    <span className="truncate">{t(item.label).split("/")[0].trim()}</span>
                    {demoLoading === item.key && <span className="text-[9px] text-faint">…</span>}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}
