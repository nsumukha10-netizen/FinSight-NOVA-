"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Building2, Check, Landmark, Loader2, Plus, ShieldCheck, Sparkles, Trash2 } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { LanguageSwitcher } from "@/components/shell/language-switcher";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n, useToast } from "@/components/providers";
import { inr } from "@/lib/money";
import { cn } from "@/lib/utils";

type Persona = "SALARIED" | "IRREGULAR" | "BUSINESS";

interface ObligationDraft {
  name: string;
  type: string;
  amount: string;
  dueDay: string;
}

const BANKS = ["HDFC Bank", "ICICI Bank", "State Bank of India", "Axis Bank", "Kotak Mahindra", "Punjab National Bank"];

const DEFAULT_OBLIGATIONS: Record<Persona, ObligationDraft[]> = {
  SALARIED: [
    { name: "Rent", type: "RENT", amount: "18000", dueDay: "5" },
    { name: "Home loan EMI", type: "EMI", amount: "12500", dueDay: "7" },
    { name: "Mutual fund SIP", type: "SIP", amount: "5000", dueDay: "10" },
    { name: "Netflix", type: "SUBSCRIPTION", amount: "649", dueDay: "3" },
  ],
  IRREGULAR: [
    { name: "Rent", type: "RENT", amount: "12000", dueDay: "5" },
    { name: "Netflix", type: "SUBSCRIPTION", amount: "649", dueDay: "3" },
    { name: "Gym membership", type: "SUBSCRIPTION", amount: "2999", dueDay: "12" },
  ],
  BUSINESS: [
    { name: "Shop rent", type: "RENT", amount: "15000", dueDay: "5" },
    { name: "Supplier payment", type: "OTHER", amount: "22000", dueDay: "12" },
    { name: "Electricity (commercial)", type: "OTHER", amount: "2800", dueDay: "18" },
  ],
};

const TYPES = [
  ["RENT", "Rent"],
  ["EMI", "EMI"],
  ["LOAN", "Loan"],
  ["SIP", "SIP / investment"],
  ["SUBSCRIPTION", "Subscription"],
  ["GROCERY", "Groceries"],
  ["OTHER", "Other"],
];

export function OnboardingView({ persona, name }: { persona: Persona; name: string }) {
  const { t } = useI18n();
  const { toast } = useToast();
  const router = useRouter();

  const [step, setStep] = React.useState(0);
  const [bank, setBank] = React.useState({ bankName: "HDFC Bank", last4: "", balance: "", consent: false });
  const [income, setIncome] = React.useState({
    monthlyIncome: persona === "BUSINESS" ? "" : "",
    incomeDay: "1",
    incomeMin: "",
    incomeMax: "",
    dailySales: "",
  });
  const [obligations, setObligations] = React.useState<ObligationDraft[]>(DEFAULT_OBLIGATIONS[persona]);
  const [survival, setSurvival] = React.useState("60000");
  const [saving, setSaving] = React.useState(false);
  const [analyzing, setAnalyzing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const steps = React.useMemo(() => {
    const list = ["bank", "income", "obligations"];
    if (persona === "IRREGULAR") list.push("survival");
    list.push("review");
    return list;
  }, [persona]);

  const current = steps[step];
  const progress = ((step + 1) / steps.length) * 100;

  function next() {
    setError(null);
    if (current === "bank") {
      if (bank.last4.replace(/\D/g, "").length < 4) return setError(t("onboarding.bank.last4"));
      if (!bank.balance) return setError(t("onboarding.bank.balance"));
      if (!bank.consent) return setError(t("onboarding.bank.consent"));
    }
    if (current === "income") {
      const amount = persona === "BUSINESS" ? income.dailySales : income.monthlyIncome;
      if (!amount || Number(amount) <= 0) return setError(t("common.error"));
    }
    setStep((s) => Math.min(steps.length - 1, s + 1));
  }

  function back() {
    setError(null);
    setStep((s) => Math.max(0, s - 1));
  }

  async function finish() {
    setSaving(true);
    setAnalyzing(true);
    try {
      const res = await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bank: { bankName: bank.bankName, last4: bank.last4, balance: Number(bank.balance), consent: bank.consent },
          income: {
            monthlyIncome: Number(income.monthlyIncome || income.dailySales) * (persona === "BUSINESS" ? 30 : 1),
            incomeDay: Number(income.incomeDay),
            incomeMin: Number(income.incomeMin) || undefined,
            incomeMax: Number(income.incomeMax) || undefined,
            dailySales: Number(income.dailySales) || undefined,
          },
          obligations: obligations
            .filter((o) => o.name && Number(o.amount) > 0)
            .map((o) => ({ name: o.name, type: o.type, amount: Number(o.amount), dueDay: Number(o.dueDay) })),
          survivalTarget: persona === "IRREGULAR" ? Number(survival) : undefined,
        }),
      });
      const data = (await res.json()) as { redirect?: string; error?: string };
      if (!res.ok) throw new Error(data.error ?? "failed");
      await new Promise((resolve) => setTimeout(resolve, 2200));
      router.push(data.redirect ?? "/dashboard");
      router.refresh();
    } catch {
      setAnalyzing(false);
      setSaving(false);
      toast({ kind: "error", title: t("common.error") });
    }
  }

  const updateObligation = (index: number, patch: Partial<ObligationDraft>) =>
    setObligations((prev) => prev.map((row, i) => (i === index ? { ...row, ...patch } : row)));

  const monthlyBills = obligations.reduce((sum, o) => sum + (Number(o.amount) || 0), 0);

  return (
    <div className="relative min-h-dvh">
      <header className="mx-auto flex max-w-4xl items-center justify-between px-5 py-6">
        <Logo />
        <LanguageSwitcher compact />
      </header>

      <main className="mx-auto max-w-3xl px-5 pb-24">
        <div className="mb-6">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-brand-300">
            {t("onboarding.step", { n: step + 1, total: steps.length })}
          </p>
          <h1 className="mt-2 h1">{t("onboarding.title")}</h1>
          <p className="mt-1.5 text-sm text-muted">{name}</p>
          <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-elevated">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-brand-500 to-emerald-400"
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.35, ease: "easeOut" }}
            />
          </div>
        </div>

        <div className="card">
          <div className="card-body min-h-[360px]">
            <AnimatePresence mode="wait">
              {current === "bank" && (
                <motion.div key="bank" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.22 }}>
                  <div className="mb-5 flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand/15 text-brand-200">
                      <Landmark className="h-5 w-5" />
                    </span>
                    <div>
                      <h2 className="h2">{t("onboarding.bank.title")}</h2>
                      <p className="text-[12.5px] text-muted">{t("onboarding.bank.subtitle")}</p>
                    </div>
                  </div>

                  <Label>{t("onboarding.bank.choose")}</Label>
                  <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {BANKS.map((item) => (
                      <button
                        key={item}
                        type="button"
                        onClick={() => setBank((prev) => ({ ...prev, bankName: item }))}
                        className={cn(
                          "rounded-xl border px-3 py-2.5 text-left text-[12.5px] transition-colors",
                          bank.bankName === item ? "border-brand/60 bg-brand/12 text-ink" : "border-line/70 bg-elevated/30 text-muted hover:text-ink",
                        )}
                      >
                        <Building2 className="mb-1 h-4 w-4 text-brand-300" />
                        {item}
                      </button>
                    ))}
                  </div>

                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="last4">{t("onboarding.bank.last4")}</Label>
                      <Input
                        id="last4"
                        inputMode="numeric"
                        maxLength={4}
                        value={bank.last4}
                        onChange={(e) => setBank((prev) => ({ ...prev, last4: e.target.value.replace(/\D/g, "") }))}
                        placeholder="4821"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="balance">{t("onboarding.bank.balance")}</Label>
                      <Input
                        id="balance"
                        inputMode="numeric"
                        value={bank.balance}
                        onChange={(e) => setBank((prev) => ({ ...prev, balance: e.target.value.replace(/[^\d]/g, "") }))}
                        placeholder="24000"
                      />
                    </div>
                  </div>

                  <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-line/70 bg-elevated/30 p-3">
                    <input
                      type="checkbox"
                      checked={bank.consent}
                      onChange={(e) => setBank((prev) => ({ ...prev, consent: e.target.checked }))}
                      className="mt-0.5 h-4 w-4 accent-[#4F46E5]"
                    />
                    <span className="text-[12.5px] leading-relaxed text-muted">{t("onboarding.bank.consent")}</span>
                  </label>
                </motion.div>
              )}

              {current === "income" && (
                <motion.div key="income" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.22 }}>
                  <div className="mb-5 flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-300">
                      <Sparkles className="h-5 w-5" />
                    </span>
                    <div>
                      <h2 className="h2">{t("onboarding.income.title")}</h2>
                      <p className="text-[12.5px] text-muted">
                        {persona === "SALARIED" ? t("landing.salariedDesc") : persona === "IRREGULAR" ? t("landing.irregularDesc") : t("landing.businessDesc")}
                      </p>
                    </div>
                  </div>

                  {persona === "BUSINESS" ? (
                    <div className="space-y-1.5">
                      <Label htmlFor="daily">{t("onboarding.income.sales")}</Label>
                      <Input
                        id="daily"
                        inputMode="numeric"
                        value={income.dailySales}
                        onChange={(e) => setIncome((prev) => ({ ...prev, dailySales: e.target.value.replace(/[^\d]/g, "") }))}
                        placeholder="7200"
                      />
                    </div>
                  ) : (
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="salary">
                          {persona === "SALARIED" ? t("onboarding.income.salary") : t("onboarding.income.avg")}
                        </Label>
                        <Input
                          id="salary"
                          inputMode="numeric"
                          value={income.monthlyIncome}
                          onChange={(e) => setIncome((prev) => ({ ...prev, monthlyIncome: e.target.value.replace(/[^\d]/g, "") }))}
                          placeholder={persona === "SALARIED" ? "65000" : "42000"}
                        />
                      </div>
                      {persona === "SALARIED" ? (
                        <div className="space-y-1.5">
                          <Label htmlFor="day">{t("onboarding.income.day")}</Label>
                          <Select value={income.incomeDay} onValueChange={(v) => setIncome((prev) => ({ ...prev, incomeDay: v }))}>
                            <SelectTrigger id="day">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: 28 }).map((_, i) => (
                                <SelectItem key={i + 1} value={String(i + 1)}>
                                  {i + 1}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1.5">
                            <Label htmlFor="min">{t("onboarding.income.min")}</Label>
                            <Input
                              id="min"
                              inputMode="numeric"
                              value={income.incomeMin}
                              onChange={(e) => setIncome((prev) => ({ ...prev, incomeMin: e.target.value.replace(/[^\d]/g, "") }))}
                              placeholder="18000"
                            />
                          </div>
                          <div className="space-y-1.5">
                            <Label htmlFor="max">{t("onboarding.income.max")}</Label>
                            <Input
                              id="max"
                              inputMode="numeric"
                              value={income.incomeMax}
                              onChange={(e) => setIncome((prev) => ({ ...prev, incomeMax: e.target.value.replace(/[^\d]/g, "") }))}
                              placeholder="72000"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="mt-5 rounded-xl border border-line/60 bg-elevated/30 p-3.5 text-[12px] leading-relaxed text-muted">
                    {persona === "IRREGULAR"
                      ? "We will model income as uneven lump sums using your last six months of brand deals and gigs."
                      : persona === "BUSINESS"
                        ? "We will use your weekday sales pattern, so weekends and slow days are modelled separately."
                        : "We will place your salary on the credit day and model variable spending around it."}
                  </div>
                </motion.div>
              )}

              {current === "obligations" && (
                <motion.div key="obligations" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.22 }}>
                  <div className="mb-4">
                    <h2 className="h2">{t("onboarding.obligations.title")}</h2>
                    <p className="text-[12.5px] text-muted">{t("onboarding.obligations.subtitle")}</p>
                  </div>

                  <div className="space-y-2.5">
                    {obligations.map((row, index) => (
                      <div key={index} className="grid grid-cols-12 gap-2 rounded-xl border border-line/70 bg-elevated/25 p-2.5">
                        <div className="col-span-12 sm:col-span-4">
                          <Input
                            value={row.name}
                            onChange={(e) => updateObligation(index, { name: e.target.value })}
                            placeholder={t("onboarding.obligations.name")}
                            aria-label={t("onboarding.obligations.name")}
                          />
                        </div>
                        <div className="col-span-5 sm:col-span-3">
                          <Select value={row.type} onValueChange={(v) => updateObligation(index, { type: v })}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {TYPES.map(([value, label]) => (
                                <SelectItem key={value} value={value}>
                                  {label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-4 sm:col-span-2">
                          <Input
                            inputMode="numeric"
                            value={row.amount}
                            onChange={(e) => updateObligation(index, { amount: e.target.value.replace(/[^\d]/g, "") })}
                            placeholder={t("onboarding.obligations.amount")}
                            aria-label={t("onboarding.obligations.amount")}
                          />
                        </div>
                        <div className="col-span-2 sm:col-span-2">
                          <Input
                            inputMode="numeric"
                            value={row.dueDay}
                            onChange={(e) => updateObligation(index, { dueDay: e.target.value.replace(/[^\d]/g, "").slice(0, 2) })}
                            placeholder="5"
                            aria-label={t("onboarding.obligations.dueDay")}
                          />
                        </div>
                        <div className="col-span-1 flex items-center justify-end">
                          <button
                            type="button"
                            onClick={() => setObligations((prev) => prev.filter((_, i) => i !== index))}
                            className="rounded-lg p-1.5 text-faint transition-colors hover:bg-rose-500/10 hover:text-rose-300"
                            aria-label={t("common.delete")}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() => setObligations((prev) => [...prev, { name: "", type: "OTHER", amount: "", dueDay: "5" }])}
                    >
                      <Plus className="h-4 w-4" />
                      {t("onboarding.obligations.add")}
                    </Button>
                    <p className="text-[12px] text-muted">
                      {t("onboarding.review.perMonth")}: <span className="num font-medium text-ink">{inr(monthlyBills)}</span>
                    </p>
                  </div>
                </motion.div>
              )}

              {current === "survival" && (
                <motion.div key="survival" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.22 }}>
                  <div className="mb-5">
                    <h2 className="h2">{t("onboarding.survival.title")}</h2>
                    <p className="text-[12.5px] text-muted">{t("onboarding.survival.subtitle")}</p>
                  </div>
                  <div className="rounded-2xl border border-line/70 bg-elevated/30 p-5">
                    <Label htmlFor="survival">{t("runway.target")}</Label>
                    <Input
                      id="survival"
                      inputMode="numeric"
                      className="mt-2 h-14 text-2xl font-semibold"
                      value={survival}
                      onChange={(e) => setSurvival(e.target.value.replace(/[^\d]/g, ""))}
                      placeholder="60000"
                    />
                    <p className="mt-3 text-[12px] leading-relaxed text-muted">{t("onboarding.survival.help")}</p>
                  </div>
                </motion.div>
              )}

              {current === "review" && (
                <motion.div key="review" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.22 }}>
                  <h2 className="h2">{t("onboarding.review.title")}</h2>
                  <div className="mt-4 space-y-3">
                    {[
                      [t("onboarding.review.bank"), `${bank.bankName} •••• ${bank.last4}`, inr(Number(bank.balance))],
                      [
                        t("onboarding.review.income"),
                        persona === "SALARIED" ? `${t("onboarding.income.day")} ${income.incomeDay}` : persona === "IRREGULAR" ? `${t("onboarding.income.avg")}` : `${t("onboarding.income.sales")}`,
                        inr(persona === "BUSINESS" ? Number(income.dailySales) * 30 : Number(income.monthlyIncome)),
                      ],
                      [t("onboarding.review.bills"), `${obligations.filter((o) => o.name).length} ${t("onboarding.review.bills")}`, inr(monthlyBills)],
                      ...(persona === "IRREGULAR"
                        ? [[t("runway.target"), t("onboarding.survival.title"), inr(Number(survival))] as string[]]
                        : []),
                    ].map(([label, detail, value]) => (
                      <div key={label} className="flex items-center justify-between gap-3 rounded-xl border border-line/70 bg-elevated/25 px-4 py-3">
                        <div>
                          <p className="text-[12px] font-medium">{label}</p>
                          <p className="text-[11px] text-faint">{detail}</p>
                        </div>
                        <p className="num text-sm font-semibold">{value}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/8 p-3 text-[12px] text-emerald-200">
                    <ShieldCheck className="mt-0.5 h-4 w-4" />
                    Six months of simulated passbook history will be imported and categorised.
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {error && <p className="mt-4 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-200">{error}</p>}
          </div>

          <div className="flex items-center justify-between border-t border-line/60 px-5 py-4 sm:px-6">
            <Button variant="ghost" onClick={back} disabled={step === 0 || saving}>
              <ArrowLeft className="h-4 w-4" />
              {t("common.back")}
            </Button>
            {current === "review" ? (
              <Button onClick={finish} loading={saving}>
                {t("onboarding.finish")}
                <Check className="h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={next}>
                {t("common.next")}
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </main>

      <AnimatePresence>
        {analyzing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-canvas/95 backdrop-blur-xl"
          >
            <div className="relative flex h-20 w-20 items-center justify-center">
              <span className="absolute inset-0 animate-ping rounded-full bg-brand/20" />
              <span className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-emerald-500 text-white">
                <Loader2 className="h-7 w-7 animate-spin" />
              </span>
            </div>
            <p className="mt-6 font-display text-lg font-semibold">{t("onboarding.analyzing")}</p>
            <div className="mt-5 space-y-2 text-[12.5px] text-muted">
              {["Importing passbook", "Detecting recurring bills", "Running 1,000 simulations"].map((line, index) => (
                <motion.p
                  key={line}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.5 }}
                  className="flex items-center gap-2"
                >
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  {line}
                </motion.p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
