"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, AudioLines, CalendarClock, Loader2, PiggyBank, Save, Sparkles, Timer, Wallet } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Label } from "@/components/ui/input";
import { RunwayGauge } from "@/components/charts";
import { useI18n, useToast } from "@/components/providers";
import { speak } from "@/lib/speech";
import { inr, inrCompact } from "@/lib/money";
import { cn } from "@/lib/utils";

export interface RunwayData {
  balance: number;
  monthlyNeed: number;
  runwayDays: number;
  status: "green" | "amber" | "red";
  survivalTarget: number;
  avgIncome: number;
  bestMonth: number;
  positiveMonths: number;
  totalMonths: number;
  persona: string;
}

export function RunwayView({ data }: { data: RunwayData }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const [target, setTarget] = React.useState(data.survivalTarget || Math.max(30000, Math.round(data.monthlyNeed * 3)));
  const [days, setDays] = React.useState(data.runwayDays);
  const [status, setStatus] = React.useState(data.status);
  const [saving, setSaving] = React.useState(false);
  const [explaining, setExplaining] = React.useState(false);

  const monthlySave = Math.max(1500, Math.round(data.bestMonth * 0.18));
  const monthsToTarget = Math.max(1, Math.ceil(Math.max(0, target - data.balance) / monthlySave));
  const plan = Array.from({ length: Math.min(12, monthsToTarget) }).map((_, index) => {
    const value = Math.min(target, data.balance + monthlySave * (index + 1));
    return { month: `M${index + 1}`, value, done: value >= target };
  });

  async function update() {
    setSaving(true);
    try {
      const res = await fetch("/api/runway", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ survivalTarget: target }),
      });
      const payload = (await res.json()) as { runwayDays?: number; status?: "green" | "amber" | "red" };
      if (!res.ok) throw new Error("failed");
      setDays(payload.runwayDays ?? days);
      setStatus(payload.status ?? status);
      toast({ kind: "success", title: t("settings.saved") });
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setSaving(false);
    }
  }

  async function explain() {
    setExplaining(true);
    try {
      const res = await fetch("/api/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Explain my survival runway in two short sentences: I have ${inr(data.balance)} now, I need ${inr(target)} for the next three months, my runway is ${days} days and my status is ${status}. Tell me the single most useful next step.`,
        }),
      });
      const payload = (await res.json()) as { reply?: string };
      if (payload.reply) await speak(payload.reply, lang);
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setExplaining(false);
    }
  }

  const statusCopy = status === "green" ? t("runway.statusGreen") : status === "amber" ? t("runway.statusAmber") : t("runway.statusRed");
  const tone = status === "green" ? "safe" : status === "amber" ? "caution" : "critical";

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="h1">{t("runway.title")}</h1>
          <p className="mt-1 text-sm text-muted">{t("runway.subtitle")}</p>
        </div>
        <Badge variant={tone}>{statusCopy}</Badge>
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className={cn("lg:col-span-5", status === "red" && "glow-critical border-rose-500/30")}>
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-faint">
              <Timer className="h-3.5 w-3.5 text-brand-300" />
              {t("dash.runway")}
            </div>
            <RunwayGauge days={days} target={90} />
            <p className="mt-2 text-center font-display text-[15px] font-semibold">{statusCopy}</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-xl border border-line/60 bg-elevated/25 p-3">
                <p className="text-[10px] uppercase tracking-wider text-faint">{t("runway.monthlyNeed")}</p>
                <p className="num mt-1 text-[13px] font-semibold">{inr(Math.round(target / 3), lang)}</p>
              </div>
              <div className="rounded-xl border border-line/60 bg-elevated/25 p-3">
                <p className="text-[10px] uppercase tracking-wider text-faint">{t("dash.balance")}</p>
                <p className="num mt-1 text-[13px] font-semibold">{inr(data.balance, lang)}</p>
              </div>
            </div>
            <Button variant="secondary" className="mt-3 w-full" onClick={explain} loading={explaining}>
              {explaining ? <Loader2 className="h-4 w-4 animate-spin" /> : <AudioLines className="h-4 w-4" />}
              {t("runway.voice")}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-4 lg:col-span-7">
          <Card>
            <CardHeader>
              <CardTitle>{t("runway.target")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-2">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div className="flex-1 space-y-1.5">
                  <Label htmlFor="target">{t("runway.target")}</Label>
                  <Input
                    id="target"
                    inputMode="numeric"
                    className="h-12 text-lg font-semibold"
                    value={target}
                    onChange={(e) => setTarget(Number(e.target.value.replace(/[^\d]/g, "")) || 0)}
                  />
                </div>
                <Button onClick={update} loading={saving}>
                  <Save className="h-4 w-4" />
                  {t("runway.update")}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {[
                  { label: t("dash.income"), value: inr(data.avgIncome, lang) },
                  { label: t("dash.best"), value: inr(data.bestMonth, lang) },
                  { label: t("runway.goodMonths"), value: `${data.positiveMonths}/${data.totalMonths}` },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-xl border border-line/60 bg-elevated/25 p-2.5">
                    <p className="truncate text-[10px] uppercase tracking-wider text-faint">{stat.label}</p>
                    <p className="num mt-1 text-[12px] font-semibold">{stat.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle>{t("runway.plan")}</CardTitle>
              <span className="text-[11px] text-muted">
                {t("budget.savings")} <span className="num font-medium text-ink">{inr(monthlySave, lang)}</span>/{t("common.month")}
              </span>
            </CardHeader>
            <CardContent className="pt-2">
              <ResponsiveContainer width="100%" height={190}>
                <BarChart data={plan} margin={{ top: 6, right: 6, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="hsl(var(--line))" strokeDasharray="3 6" />
                  <XAxis dataKey="month" tick={{ fontSize: 10, fill: "hsl(var(--faint))" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "hsl(var(--faint))" }} axisLine={false} tickLine={false} width={50} tickFormatter={(v: number) => inrCompact(v, lang)} />
                  <Tooltip
                    formatter={(value: number) => inr(value, lang)}
                    contentStyle={{ background: "hsl(var(--surface))", border: "1px solid hsl(var(--line))", borderRadius: 12, fontSize: 11 }}
                  />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={46} isAnimationActive={false} minPointSize={2}>
                    {plan.map((entry) => (
                      <Cell key={entry.month} fill={entry.done ? "#10B981" : "#4F46E5"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-muted">
                <ArrowUpRight className="h-3.5 w-3.5 text-emerald-300" />
                {t("runway.target")}: {inr(target, lang)} · {inr(monthlySave, lang)} / {t("common.month")}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PiggyBank className="h-4 w-4 text-emerald-300" />
              {t("runway.smoothing")}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-1">
            <p className="text-[12.5px] leading-relaxed text-muted">
              {t("runway.smoothingBody", { amount: inr(monthlySave, lang) })}
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/8 px-3 py-2 text-[11.5px] text-emerald-200">
              <Wallet className="h-3.5 w-3.5" />
              {data.positiveMonths}/{data.totalMonths} months had income above your survival need.
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-amber-300" />
              {t("runway.plan")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-1">
            {[
              { step: 1, text: `Move ${inr(monthlySave, lang)} into a separate buffer account on every good week.` },
              { step: 2, text: `Keep fixed bills under ${inr(Math.round(data.monthlyNeed * 0.55), lang)} a month.` },
              { step: 3, text: `Only accept work that pays within 30 days while the runway is under 60 days.` },
            ].map((item) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: item.step * 0.08 }}
                className="flex items-start gap-2.5 rounded-xl border border-line/60 bg-elevated/25 p-2.5"
              >
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand/15 text-[10px] font-semibold text-brand-200">
                  {item.step}
                </span>
                <p className="text-[11.5px] leading-relaxed text-muted">{item.text}</p>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="border-brand/20 bg-brand/5">
        <CardContent className="flex items-center gap-3 p-4 text-[12.5px] text-muted">
          <Sparkles className="h-4 w-4 text-brand-300" />
          Your runway is measured against the amount you said you need for three months, not your full expenses. Update it whenever your rent or city changes.
        </CardContent>
      </Card>
    </div>
  );
}
