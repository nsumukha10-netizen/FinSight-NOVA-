"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Download, Globe2, LogOut, Moon, Plus, RotateCcw, Save, Sun, Trash2, UserRound, Volume2, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Label } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/controls";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { useI18n, useTheme, useToast } from "@/components/providers";
import { LANGUAGES, type LangCode } from "@/lib/i18n";
import { inr } from "@/lib/money";
import { cn } from "@/lib/utils";

export interface SettingsData {
  name: string;
  email: string;
  phone: string;
  persona: string;
  monthlyIncome: number;
  incomeDay: number;
  survivalTarget: number;
  dailySales: number;
  voiceEnabled: boolean;
  isDemo: boolean;
  obligations: { name: string; type: string; amount: number; dueDay: number }[];
}

const TYPES = [
  ["RENT", "Rent"],
  ["EMI", "EMI"],
  ["LOAN", "Loan"],
  ["SIP", "SIP"],
  ["SUBSCRIPTION", "Subscription"],
  ["GROCERY", "Groceries"],
  ["OTHER", "Other"],
];

export function SettingsView({ data }: { data: SettingsData }) {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const router = useRouter();

  const [profile, setProfile] = React.useState({ name: data.name, phone: data.phone });
  const [income, setIncome] = React.useState({
    monthlyIncome: String(data.monthlyIncome),
    incomeDay: String(data.incomeDay),
    survivalTarget: String(data.survivalTarget || ""),
    dailySales: String(data.dailySales || ""),
  });
  const [voice, setVoice] = React.useState(data.voiceEnabled);
  const [obligations, setObligations] = React.useState(
    data.obligations.map((o) => ({ name: o.name, type: o.type, amount: String(o.amount), dueDay: String(o.dueDay) })),
  );
  const [saving, setSaving] = React.useState<string | null>(null);
  const [resetOpen, setResetOpen] = React.useState(false);

  async function save(section: string, body: Record<string, unknown>, endpoint = "/api/settings") {
    setSaving(section);
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error("failed");
      toast({ kind: "success", title: t("settings.saved") });
      router.refresh();
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setSaving(null);
    }
  }

  async function resetDemo() {
    setSaving("reset");
    try {
      const res = await fetch("/api/demo/reset", { method: "POST" });
      if (!res.ok) throw new Error("failed");
      toast({ kind: "success", title: t("settings.saved") });
      setResetOpen(false);
      router.refresh();
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setSaving(null);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="h1">{t("settings.title")}</h1>
        <p className="mt-1 text-sm text-muted">
          {data.email} · {data.persona.toLowerCase()}
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserRound className="h-4 w-4 text-brand-300" />
              {t("settings.profile")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="name">{t("landing.name")}</Label>
              <Input id="name" value={profile.name} onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="phone">{t("landing.phone")}</Label>
              <Input id="phone" value={profile.phone} onChange={(e) => setProfile((p) => ({ ...p, phone: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Email</Label>
              <Input value={data.email} disabled />
            </div>
            <Button onClick={() => save("profile", profile)} loading={saving === "profile"}>
              <Save className="h-4 w-4" />
              {t("common.save")}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-emerald-300" />
              {t("settings.income")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-2">
            {data.persona === "BUSINESS" ? (
              <div className="space-y-1.5">
                <Label htmlFor="dailySales">{t("onboarding.income.sales")}</Label>
                <Input
                  id="dailySales"
                  inputMode="numeric"
                  value={income.dailySales}
                  onChange={(e) => setIncome((p) => ({ ...p, dailySales: e.target.value.replace(/[^\d]/g, "") }))}
                />
                <p className="text-[11px] text-faint">≈ {inr(Number(income.dailySales || 0) * 30, lang)} / {t("common.month")}</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="monthlyIncome">{t("onboarding.income.salary")}</Label>
                  <Input
                    id="monthlyIncome"
                    inputMode="numeric"
                    value={income.monthlyIncome}
                    onChange={(e) => setIncome((p) => ({ ...p, monthlyIncome: e.target.value.replace(/[^\d]/g, "") }))}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("onboarding.income.day")}</Label>
                  <Select value={income.incomeDay} onValueChange={(v) => setIncome((p) => ({ ...p, incomeDay: v }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 28 }).map((_, index) => (
                        <SelectItem key={index + 1} value={String(index + 1)}>
                          {index + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            {data.persona === "IRREGULAR" && (
              <div className="space-y-1.5">
                <Label htmlFor="survival">{t("runway.target")}</Label>
                <Input
                  id="survival"
                  inputMode="numeric"
                  value={income.survivalTarget}
                  onChange={(e) => setIncome((p) => ({ ...p, survivalTarget: e.target.value.replace(/[^\d]/g, "") }))}
                />
              </div>
            )}
            <Button
              onClick={() =>
                save("income", {
                  monthlyIncome: Number(income.monthlyIncome || Number(income.dailySales) * 30),
                  incomeDay: Number(income.incomeDay),
                  survivalTarget: Number(income.survivalTarget || 0),
                  dailySales: Number(income.dailySales || 0),
                })
              }
              loading={saving === "income"}
            >
              <Save className="h-4 w-4" />
              {t("common.save")}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe2 className="h-4 w-4 text-brand-300" />
              {t("settings.language")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-2">
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
              {LANGUAGES.map((language) => (
                <button
                  key={language.code}
                  onClick={() => setLang(language.code as LangCode)}
                  className={cn(
                    "rounded-xl border px-2.5 py-2 text-left text-[12px] transition-colors",
                    lang === language.code ? "border-brand/60 bg-brand/12 text-ink" : "border-line/70 text-muted hover:text-ink",
                  )}
                >
                  <span className="block font-medium">{language.native}</span>
                  <span className="block text-[10px] text-faint">{language.label}</span>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between rounded-xl border border-line/60 bg-elevated/25 px-3 py-2.5">
              <div>
                <p className="text-[12.5px] font-medium">{t("settings.theme")}</p>
                <p className="text-[10.5px] text-faint">{theme === "dark" ? t("settings.dark") : t("settings.light")}</p>
              </div>
              <div className="flex gap-1 rounded-full border border-line/70 p-1">
                <button
                  onClick={() => setTheme("dark")}
                  className={cn("rounded-full p-1.5", theme === "dark" ? "bg-brand text-white" : "text-faint")}
                  aria-label={t("settings.dark")}
                >
                  <Moon className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => setTheme("light")}
                  className={cn("rounded-full p-1.5", theme === "light" ? "bg-brand text-white" : "text-faint")}
                  aria-label={t("settings.light")}
                >
                  <Sun className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-amber-300" />
              {t("settings.voice")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-2">
            <div className="flex items-center justify-between rounded-xl border border-line/60 bg-elevated/25 px-3 py-2.5">
              <div>
                <p className="text-[12.5px] font-medium">{voice ? t("settings.voiceOn") : t("settings.voiceOff")}</p>
                <p className="text-[10.5px] text-faint">{t("voice.expensePrompt")}</p>
              </div>
              <Switch
                checked={voice}
                onCheckedChange={(checked) => {
                  setVoice(checked);
                  void save("voice", { voiceEnabled: checked });
                }}
                aria-label={t("settings.voice")}
              />
            </div>
            <div className="rounded-xl border border-line/60 bg-elevated/25 p-3 text-[11.5px] leading-relaxed text-muted">
              Voice input uses your microphone through the browser. Audio is sent to the transcription service only for the moment you speak and is never stored.
            </div>
            <Button
              variant="secondary"
              onClick={() => window.dispatchEvent(new CustomEvent("finsight:open-voice"))}
              className="w-full"
            >
              <Volume2 className="h-4 w-4" />
              {t("voice.title")}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>{t("settings.obligations")}</CardTitle>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setObligations((prev) => [...prev, { name: "", type: "OTHER", amount: "", dueDay: "5" }])}
          >
            <Plus className="h-4 w-4" />
            {t("common.add")}
          </Button>
        </CardHeader>
        <CardContent className="space-y-2 pt-2">
          {obligations.map((row, index) => (
            <div key={index} className="grid grid-cols-12 gap-2 rounded-xl border border-line/60 bg-elevated/20 p-2">
              <div className="col-span-12 sm:col-span-4">
                <Input
                  value={row.name}
                  placeholder={t("onboarding.obligations.name")}
                  onChange={(e) => setObligations((prev) => prev.map((item, i) => (i === index ? { ...item, name: e.target.value } : item)))}
                />
              </div>
              <div className="col-span-5 sm:col-span-3">
                <Select
                  value={row.type}
                  onValueChange={(value) => setObligations((prev) => prev.map((item, i) => (i === index ? { ...item, type: value } : item)))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPES.map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-4 sm:col-span-2">
                <Input
                  inputMode="numeric"
                  value={row.amount}
                  placeholder={t("onboarding.obligations.amount")}
                  onChange={(e) =>
                    setObligations((prev) => prev.map((item, i) => (i === index ? { ...item, amount: e.target.value.replace(/[^\d]/g, "") } : item)))
                  }
                />
              </div>
              <div className="col-span-2 sm:col-span-2">
                <Input
                  inputMode="numeric"
                  value={row.dueDay}
                  placeholder="5"
                  onChange={(e) =>
                    setObligations((prev) =>
                      prev.map((item, i) => (i === index ? { ...item, dueDay: e.target.value.replace(/[^\d]/g, "").slice(0, 2) } : item)),
                    )
                  }
                />
              </div>
              <div className="col-span-1 flex items-center justify-end">
                <button
                  onClick={() => setObligations((prev) => prev.filter((_, i) => i !== index))}
                  className="rounded-lg p-1.5 text-faint hover:bg-rose-500/10 hover:text-rose-300"
                  aria-label={t("common.delete")}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
          <div className="flex items-center justify-between pt-1">
            <p className="text-[11.5px] text-muted">
              {t("onboarding.review.perMonth")}:{" "}
              <span className="num font-medium text-ink">{inr(obligations.reduce((sum, row) => sum + (Number(row.amount) || 0), 0), lang)}</span>
            </p>
            <Button
              onClick={() =>
                save("obligations", {
                  obligations: obligations
                    .filter((row) => row.name && Number(row.amount) > 0)
                    .map((row) => ({ name: row.name, type: row.type, amount: Number(row.amount), dueDay: Number(row.dueDay) })),
                }, "/api/obligations")
              }
              loading={saving === "obligations"}
            >
              <Save className="h-4 w-4" />
              {t("common.save")}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.data")}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2 pt-1">
          <Button variant="secondary" asChild>
            <a href="/api/export/csv" download>
              <Download className="h-4 w-4" />
              CSV
            </a>
          </Button>
          {data.isDemo && (
            <Button variant="secondary" onClick={() => setResetOpen(true)} loading={saving === "reset"}>
              <RotateCcw className="h-4 w-4" />
              {t("settings.reset")}
            </Button>
          )}
          <Button variant="ghost" onClick={logout} className="ml-auto text-rose-300 hover:bg-rose-500/10">
            <LogOut className="h-4 w-4" />
            {t("settings.logout")}
          </Button>
        </CardContent>
      </Card>

      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent className="max-w-sm">
          <DialogTitle>{t("settings.reset")}</DialogTitle>
          <DialogDescription>{t("settings.demoNote")}</DialogDescription>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setResetOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button variant="danger" onClick={resetDemo} loading={saving === "reset"}>
              <RotateCcw className="h-4 w-4" />
              {t("settings.reset")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
