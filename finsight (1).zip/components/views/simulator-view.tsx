"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Banknote, CalendarClock, ChartNoAxesCombined, CircleCheck, CircleX, Home, TrendingDown, TriangleAlert, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input, Label } from "@/components/ui/input";
import { Slider } from "@/components/ui/controls";
import { ForecastChart } from "@/components/charts";
import { useI18n, useToast } from "@/components/providers";
import { inr, inrCompact } from "@/lib/money";
import { longDate } from "@/lib/dates";
import type { ForecastPoint } from "@/lib/types";
import { cn } from "@/lib/utils";

type Kind = "purchase" | "loan" | "prepay" | "salary";

interface SimResponse {
  verdict: "Safe" | "Risky" | "Not advisable";
  reasons: string[];
  deltas: { endBalance: number; minBalance: number; shortageDays: number };
  before: { points: ForecastPoint[]; endP50: number; minP50: number; shortageDate: string | null; shortageProbability: number };
  after: { points: ForecastPoint[]; endP50: number; minP50: number; shortageDate: string | null; shortageProbability: number };
  balance: number;
  error?: string;
}

const TABS: { key: Kind; icon: typeof Wallet }[] = [
  { key: "purchase", icon: Wallet },
  { key: "loan", icon: Home },
  { key: "prepay", icon: Banknote },
  { key: "salary", icon: ChartNoAxesCombined },
];

export function SimulatorView({ balance, monthlyIncome }: { balance: number; monthlyIncome: number }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const locale = lang === "en" ? "en-IN" : `${lang}-IN`;

  const [kind, setKind] = React.useState<Kind>("purchase");
  const [amount, setAmount] = React.useState(25000);
  const [months, setMonths] = React.useState(12);
  const [interest, setInterest] = React.useState(12);
  const [salary, setSalary] = React.useState(Math.max(20000, Math.round(monthlyIncome * 1.2)));
  const [result, setResult] = React.useState<SimResponse | null>(null);
  const [loading, setLoading] = React.useState(false);

  const run = React.useCallback(
    async (nextKind: Kind = kind, overrides?: Partial<{ amount: number; months: number; interest: number; salary: number }>) => {
      setLoading(true);
      try {
        const payload = {
          kind: nextKind,
          amount: overrides?.amount ?? amount,
          months: overrides?.months ?? months,
          interestRate: overrides?.interest ?? interest,
          newSalary: overrides?.salary ?? salary,
        };
        const res = await fetch("/api/simulator", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = (await res.json()) as SimResponse;
        if (!res.ok) throw new Error(data.error ?? "failed");
        setResult(data);
      } catch {
        toast({ kind: "error", title: t("common.error") });
      } finally {
        setLoading(false);
      }
    },
    [amount, interest, kind, months, salary, t, toast],
  );

  React.useEffect(() => {
    void run("purchase", { amount: 25000 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function changeKind(next: Kind) {
    setKind(next);
    const defaults = next === "purchase" ? { amount: 25000 } : next === "loan" ? { amount: 200000, months: 24, interest: 14 } : next === "prepay" ? { amount: 100000 } : { salary: Math.round(monthlyIncome * 1.2) };
    if (defaults.amount) setAmount(defaults.amount);
    if ("months" in defaults && defaults.months) setMonths(defaults.months);
    if ("interest" in defaults && defaults.interest) setInterest(defaults.interest);
    if ("salary" in defaults && defaults.salary) setSalary(defaults.salary);
    void run(next, defaults as Partial<{ amount: number; months: number; interest: number; salary: number }>);
  }

  const verdictTone =
    result?.verdict === "Safe" ? "safe" : result?.verdict === "Risky" ? "caution" : "critical";
  const VerdictIcon = result?.verdict === "Safe" ? CircleCheck : result?.verdict === "Risky" ? TriangleAlert : CircleX;

  const amountLabel = kind === "salary" ? t("sim.newSalary") : kind === "loan" ? t("sim.amount") : t("sim.amount");
  const maxAmount = kind === "loan" ? 1000000 : kind === "salary" ? 500000 : 300000;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="h1">{t("sim.title")}</h1>
        <p className="mt-1 text-sm text-muted">{t("sim.subtitle")}</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <Card className="lg:col-span-5">
          <CardContent className="space-y-5 p-5">
            <div className="grid grid-cols-4 gap-1 rounded-xl border border-line/70 bg-elevated/40 p-1">
              {TABS.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => changeKind(tab.key)}
                  className={cn(
                    "flex flex-col items-center gap-1 rounded-lg px-1 py-2 text-[10.5px] font-medium transition-colors",
                    kind === tab.key ? "bg-brand text-white" : "text-faint hover:text-ink",
                  )}
                >
                  <tab.icon className="h-4 w-4" />
                  <span className="truncate">{t(`sim.${tab.key}`)}</span>
                </button>
              ))}
            </div>

            {kind === "salary" ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>{t("sim.newSalary")}</Label>
                  <span className="num text-sm font-semibold">{inr(salary, lang)}</span>
                </div>
                <Slider value={[salary]} min={10000} max={500000} step={1000} onValueChange={(value) => setSalary(value[0])} />
                <Input
                  inputMode="numeric"
                  value={salary}
                  onChange={(e) => setSalary(Number(e.target.value.replace(/[^\d]/g, "")) || 0)}
                  className="mt-1"
                />
                <p className="text-[11px] text-faint">
                  {t("dash.income")}: {inr(monthlyIncome, lang)}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>{amountLabel}</Label>
                  <span className="num text-sm font-semibold">{inr(amount, lang)}</span>
                </div>
                <Slider value={[amount]} min={1000} max={maxAmount} step={1000} onValueChange={(value) => setAmount(value[0])} />
                <Input
                  inputMode="numeric"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value.replace(/[^\d]/g, "")) || 0)}
                  className="mt-1"
                />
              </div>
            )}

            {kind === "loan" && (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>{t("sim.months")}</Label>
                  <Input inputMode="numeric" value={months} onChange={(e) => setMonths(Number(e.target.value.replace(/[^\d]/g, "")) || 0)} />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("sim.interest")}</Label>
                  <Input inputMode="decimal" value={interest} onChange={(e) => setInterest(Number(e.target.value.replace(/[^\d.]/g, "")) || 0)} />
                </div>
              </div>
            )}

            {kind === "loan" && (
              <div className="rounded-xl border border-line/60 bg-elevated/30 p-3 text-[11.5px] text-muted">
                EMI ≈ <span className="num font-medium text-ink">{inr(Math.round((amount * (interest / 1200)) / (1 - Math.pow(1 + interest / 1200, -months))), lang)}</span> / {t("common.month")}
              </div>
            )}

            <div className="flex items-center justify-between rounded-xl border border-line/60 bg-elevated/25 px-3 py-2 text-[11.5px]">
              <span className="text-faint">{t("dash.balance")}</span>
              <span className="num font-medium">{inr(balance, lang)}</span>
            </div>

            <Button className="w-full" onClick={() => run(kind)} loading={loading}>
              <ChartNoAxesCombined className="h-4 w-4" />
              {t("sim.run")}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-5 lg:col-span-7">
          <Card className={cn(result?.verdict === "Not advisable" && "border-rose-500/30 glow-critical", result?.verdict === "Safe" && "border-emerald-500/25")}>
            <CardContent className="p-5">
              {!result ? (
                <div className="flex h-40 items-center justify-center text-[12.5px] text-faint">{t("common.loading")}</div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-xl",
                          verdictTone === "safe" && "bg-emerald-500/15 text-emerald-300",
                          verdictTone === "caution" && "bg-amber-500/15 text-amber-300",
                          verdictTone === "critical" && "bg-rose-500/15 text-rose-300",
                        )}
                      >
                        <VerdictIcon className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="text-[10.5px] uppercase tracking-wider text-faint">{t("sim.verdict")}</p>
                        <p
                          className={cn(
                            "font-display text-xl font-semibold",
                            verdictTone === "safe" && "text-emerald-300",
                            verdictTone === "caution" && "text-amber-300",
                            verdictTone === "critical" && "text-rose-300",
                          )}
                        >
                          {result.verdict === "Safe" ? t("sim.safe") : result.verdict === "Risky" ? t("sim.risky") : t("sim.notAdvisable")}
                        </p>
                      </div>
                    </div>
                    <Badge variant={verdictTone}>
                      {t(`sim.${kind}`)} · {kind === "salary" ? inr(salary, lang) : inr(amount, lang)}
                    </Badge>
                  </div>

                  <div className="mt-4 grid grid-cols-3 gap-2">
                    {[
                      { label: t("sim.end"), value: inr(result.after.endP50, lang), delta: result.deltas.endBalance },
                      { label: t("sim.lowest"), value: inr(result.after.minP50, lang), delta: result.deltas.minBalance },
                      {
                        label: t("sim.shortage"),
                        value: result.after.shortageDate ? longDate(result.after.shortageDate, locale) : t("fc.none"),
                        delta: -result.deltas.shortageDays,
                      },
                    ].map((stat) => (
                      <div key={stat.label} className="rounded-xl border border-line/60 bg-elevated/25 p-2.5">
                        <p className="text-[10px] uppercase tracking-wider text-faint">{stat.label}</p>
                        <p className="num mt-1 text-[12.5px] font-semibold">{stat.value}</p>
                        <p className={cn("num text-[10px]", stat.delta >= 0 ? "text-emerald-300" : "text-rose-300")}>
                          {stat.delta >= 0 ? "+" : ""}
                          {stat.delta.toLocaleString("en-IN")}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 space-y-1.5">
                    {result.reasons.map((reason) => (
                      <motion.p
                        key={reason}
                        initial={{ opacity: 0, x: -6 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-start gap-2 text-[12px] leading-relaxed text-muted"
                      >
                        <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-300" />
                        {reason}
                      </motion.p>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle>{t("sim.before")} / {t("sim.after")}</CardTitle>
              <div className="flex items-center gap-3 text-[10.5px] text-muted">
                <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-slate-400" />{t("sim.before")}</span>
                <span className="flex items-center gap-1.5"><span className="h-1.5 w-4 rounded-full bg-gradient-to-r from-brand-400 to-emerald-400" />{t("sim.after")}</span>
              </div>
            </CardHeader>
            <CardContent className="pt-2">
              {result ? (
                <ForecastChart points={result.after.points} compare={result.before.points} height={240} />
              ) : (
                <div className="h-[240px] animate-pulse rounded-xl bg-elevated/40" />
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-line/60 bg-elevated/25 p-3">
              <p className="flex items-center gap-1.5 text-[10.5px] uppercase tracking-wider text-faint">
                <CalendarClock className="h-3.5 w-3.5" /> {t("sim.before")}
              </p>
              <p className="num mt-1 text-[13px] font-semibold">{result ? inrCompact(result.before.endP50, lang) : "—"}</p>
              <p className="text-[10.5px] text-faint">
                {result?.before.shortageDate ? longDate(result.before.shortageDate, locale) : t("fc.none")}
              </p>
            </div>
            <div className="rounded-xl border border-line/60 bg-elevated/25 p-3">
              <p className="flex items-center gap-1.5 text-[10.5px] uppercase tracking-wider text-faint">
                <TrendingDown className="h-3.5 w-3.5" /> {t("sim.after")}
              </p>
              <p className="num mt-1 text-[13px] font-semibold">{result ? inrCompact(result.after.endP50, lang) : "—"}</p>
              <p className="text-[10.5px] text-faint">
                {result?.after.shortageDate ? longDate(result.after.shortageDate, locale) : t("fc.none")}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
