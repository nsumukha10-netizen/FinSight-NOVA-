"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight, Download, Pencil, Plus, Repeat, Search, ShieldAlert, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { usePayment } from "@/components/payments/payment-flow";
import { useI18n, useToast } from "@/components/providers";
import { CATEGORIES, categoryColor, categoryI18nKey } from "@/lib/categories";
import { inr } from "@/lib/money";
import { shortDate } from "@/lib/dates";
import { cn } from "@/lib/utils";

export interface TxRow {
  id: string;
  date: string;
  amount: number;
  type: string;
  payee: string;
  rawDescription: string;
  category: string;
  isRecurring: boolean;
  isAnomaly: boolean;
  anomalyReason: string | null;
  voiceLabel: string | null;
  note: string | null;
  balanceAfter: number;
}

export function TransactionsView({ transactions, isDemo }: { transactions: TxRow[]; isDemo: boolean }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const { open, demo } = usePayment();
  const locale = lang === "en" ? "en-IN" : `${lang}-IN`;

  const [query, setQuery] = React.useState("");
  const [type, setType] = React.useState<"ALL" | "DEBIT" | "CREDIT">("ALL");
  const [category, setCategory] = React.useState<string>("ALL");
  const [onlyAnomalies, setOnlyAnomalies] = React.useState(false);
  const [visible, setVisible] = React.useState(40);
  const [editing, setEditing] = React.useState<TxRow | null>(null);
  const [newCategory, setNewCategory] = React.useState("");
  const [rows, setRows] = React.useState(transactions);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => setRows(transactions), [transactions]);

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((tx) => {
      if (type !== "ALL" && tx.type !== type) return false;
      if (category !== "ALL" && tx.category !== category) return false;
      if (onlyAnomalies && !tx.isAnomaly) return false;
      if (!q) return true;
      return [tx.payee, tx.note, tx.voiceLabel, tx.rawDescription, tx.category].some((value) => (value ?? "").toLowerCase().includes(q));
    });
  }, [rows, query, type, category, onlyAnomalies]);

  const totals = React.useMemo(() => {
    return filtered.reduce(
      (acc, tx) => {
        if (tx.type === "CREDIT") acc.in += tx.amount;
        else acc.out += tx.amount;
        return acc;
      },
      { in: 0, out: 0 },
    );
  }, [filtered]);

  async function saveCategory() {
    if (!editing || !newCategory) return;
    setSaving(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: editing.id, category: newCategory }),
      });
      if (!res.ok) throw new Error("failed");
      setRows((prev) => prev.map((tx) => (tx.id === editing.id ? { ...tx, category: newCategory } : tx)));
      toast({ kind: "success", title: t("tx.editCategory"), description: newCategory });
      setEditing(null);
    } catch {
      toast({ kind: "error", title: t("common.error") });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="h1">{t("tx.title")}</h1>
          <p className="mt-1 text-sm text-muted">{t("tx.subtitle")}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={() => open()}>
            <Plus className="h-4 w-4" />
            {t("tx.simulate")}
          </Button>
          {isDemo && (
            <Button size="sm" variant="secondary" onClick={() => demo("swiggy")}>
              <Sparkles className="h-4 w-4" />
              Swiggy
            </Button>
          )}
          <Button size="sm" variant="secondary" asChild>
            <a href="/api/export/csv" download>
              <Download className="h-4 w-4" />
              CSV
            </a>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: t("tx.count", { n: filtered.length }), value: "", tone: "text-ink" },
          { label: t("tx.out"), value: inr(totals.out, lang), tone: "text-rose-300" },
          { label: t("tx.in"), value: inr(totals.in, lang), tone: "text-emerald-300" },
          { label: t("tx.anomaly"), value: String(filtered.filter((tx) => tx.isAnomaly).length), tone: "text-amber-300" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-3.5">
              <p className="text-[10.5px] uppercase tracking-wider text-faint">{stat.label}</p>
              {stat.value && <p className={cn("num mt-1 text-[15px] font-semibold", stat.tone)}>{stat.value}</p>}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="space-y-3 p-4 sm:p-5">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("tx.search")}
                className="pl-9"
                aria-label={t("tx.search")}
              />
            </div>
            <div className="flex gap-1 rounded-xl border border-line/70 bg-elevated/40 p-1">
              {[
                ["ALL", t("tx.all")],
                ["DEBIT", t("tx.out")],
                ["CREDIT", t("tx.in")],
              ].map(([value, label]) => (
                <button
                  key={value}
                  onClick={() => setType(value as typeof type)}
                  className={cn(
                    "rounded-lg px-2.5 py-1.5 text-[11.5px] font-medium transition-colors",
                    type === value ? "bg-brand text-white" : "text-faint hover:text-ink",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full sm:w-[170px]">
                <SelectValue placeholder={t("tx.category")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">{t("tx.all")}</SelectItem>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c.key} value={c.key}>
                    {t(categoryI18nKey(c.key))}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <button
              onClick={() => setOnlyAnomalies((v) => !v)}
              className={cn(
                "flex h-11 items-center gap-1.5 rounded-xl border px-3 text-[11.5px] font-medium transition-colors",
                onlyAnomalies ? "border-rose-500/40 bg-rose-500/10 text-rose-200" : "border-line/70 text-faint hover:text-ink",
              )}
              aria-pressed={onlyAnomalies}
            >
              <ShieldAlert className="h-3.5 w-3.5" />
              {t("tx.anomaly")}
            </button>
          </div>

          <div className="hidden overflow-x-auto md:block">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-line/60 text-[10.5px] uppercase tracking-wider text-faint">
                  <th className="py-2 pr-3 font-medium">{t("tx.date")}</th>
                  <th className="py-2 pr-3 font-medium">{t("tx.payee")}</th>
                  <th className="py-2 pr-3 font-medium">{t("tx.category")}</th>
                  <th className="py-2 pr-3 text-right font-medium">{t("tx.amount")}</th>
                  <th className="py-2 text-right font-medium">Balance</th>
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, visible).map((tx) => (
                  <tr key={tx.id} className="group border-b border-line/40 last:border-0">
                    <td className="whitespace-nowrap py-2.5 pr-3 text-[11.5px] text-muted">{shortDate(tx.date, locale)}</td>
                    <td className="py-2.5 pr-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[12.5px] font-medium">{tx.payee}</span>
                        {tx.isRecurring && <Repeat className="h-3 w-3 text-brand-300" aria-label={t("tx.recurring")} />}
                        {tx.isAnomaly && <Badge variant="critical">{t("tx.anomaly")}</Badge>}
                      </div>
                      <p className="max-w-[260px] truncate text-[10.5px] text-faint">
                        {tx.voiceLabel ? `${t("tx.voiceLabel")}: ${tx.voiceLabel}` : tx.note || tx.rawDescription}
                      </p>
                    </td>
                    <td className="py-2.5 pr-3">
                      <button
                        onClick={() => {
                          setEditing(tx);
                          setNewCategory(tx.category);
                        }}
                        className="inline-flex items-center gap-1.5 rounded-full border border-line/70 px-2 py-0.5 text-[10.5px] text-muted transition-colors hover:text-ink"
                      >
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: categoryColor(tx.category) }} />
                        {t(categoryI18nKey(tx.category))}
                        <Pencil className="h-2.5 w-2.5 opacity-0 transition-opacity group-hover:opacity-70" />
                      </button>
                    </td>
                    <td className={cn("num whitespace-nowrap py-2.5 pr-3 text-right text-[12.5px] font-semibold", tx.type === "CREDIT" ? "text-emerald-300" : "text-ink")}>
                      {tx.type === "CREDIT" ? "+" : "−"}
                      {inr(tx.amount, lang)}
                    </td>
                    <td className="num py-2.5 text-right text-[11.5px] text-muted">{inr(tx.balanceAfter, lang)}</td>
                    <td className="py-2.5 pl-2 text-right">
                      <span className={cn("inline-flex h-6 w-6 items-center justify-center rounded-md", tx.type === "CREDIT" ? "bg-emerald-500/10 text-emerald-300" : "bg-elevated text-muted")}>
                        {tx.type === "CREDIT" ? <ArrowDownLeft className="h-3.5 w-3.5" /> : <ArrowUpRight className="h-3.5 w-3.5" />}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="space-y-2 md:hidden">
            {filtered.slice(0, visible).map((tx) => (
              <div key={tx.id} className="flex items-center gap-3 rounded-xl border border-line/60 bg-elevated/25 p-3">
                <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg", tx.type === "CREDIT" ? "bg-emerald-500/12 text-emerald-300" : "bg-elevated text-muted")}>
                  {tx.type === "CREDIT" ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-medium">{tx.payee}</p>
                  <p className="truncate text-[10.5px] text-faint">
                    {shortDate(tx.date, locale)} · {t(categoryI18nKey(tx.category))}
                  </p>
                </div>
                <div className="text-right">
                  <p className={cn("num text-[12.5px] font-semibold", tx.type === "CREDIT" ? "text-emerald-300" : "text-ink")}>
                    {tx.type === "CREDIT" ? "+" : "−"}
                    {inr(tx.amount, lang)}
                  </p>
                  {tx.isAnomaly && <span className="text-[9.5px] text-rose-300">{t("tx.anomaly")}</span>}
                </div>
                <button
                  onClick={() => {
                    setEditing(tx);
                    setNewCategory(tx.category);
                  }}
                  className="rounded-lg p-1.5 text-faint"
                  aria-label={t("tx.editCategory")}
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          {!filtered.length && <p className="py-10 text-center text-[12.5px] text-faint">{t("tx.empty")}</p>}

          {filtered.length > visible && (
            <div className="pt-1 text-center">
              <Button variant="ghost" size="sm" onClick={() => setVisible((v) => v + 40)}>
                {t("common.viewAll")} ({filtered.length - visible})
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-w-sm">
          <DialogTitle>{t("tx.editCategory")}</DialogTitle>
          <DialogDescription>
            {editing?.payee} · {editing ? inr(editing.amount, lang) : ""}
          </DialogDescription>
          <Select value={newCategory} onValueChange={setNewCategory}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map((c) => (
                <SelectItem key={c.key} value={c.key}>
                  {t(categoryI18nKey(c.key))}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[11px] leading-relaxed text-faint">
            FinSight remembers this correction for {editing?.payee} and applies it to future payments.
          </p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>
              {t("common.cancel")}
            </Button>
            <Button onClick={saveCategory} loading={saving}>
              {t("common.save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
