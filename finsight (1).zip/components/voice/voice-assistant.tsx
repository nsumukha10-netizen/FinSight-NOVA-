"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AudioLines, Keyboard, Loader2, Mic, Square, Volume2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n, useToast } from "@/components/providers";
import { speak, stopSpeaking } from "@/lib/speech";
import { cn } from "@/lib/utils";

type Mode = "coach" | "expense";
type Phase = "idle" | "recording" | "processing" | "result";

interface OpenOptions {
  mode?: Mode;
  transactionId?: string;
  prompt?: string;
}

interface VoiceContextValue {
  open: (options?: OpenOptions) => void;
}

const VoiceContext = React.createContext<VoiceContextValue | null>(null);

export function useVoice() {
  const ctx = React.useContext(VoiceContext);
  if (!ctx) throw new Error("useVoice outside provider");
  return ctx;
}

function Waveform({ active }: { active: boolean }) {
  return (
    <div className="flex h-10 items-center justify-center gap-1" aria-hidden>
      {Array.from({ length: 18 }).map((_, i) => (
        <span
          key={i}
          className={cn(
            "w-1 rounded-full bg-gradient-to-t from-brand-500 to-emerald-400 transition-opacity",
            active ? "animate-wave" : "opacity-30",
          )}
          style={{ height: `${12 + ((i * 7) % 26)}px`, animationDelay: `${(i % 6) * 0.11}s` }}
        />
      ))}
    </div>
  );
}

export function VoiceProvider({ children }: { children: React.ReactNode }) {
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const [open, setOpen] = React.useState(false);
  const [mode, setMode] = React.useState<Mode>("coach");
  const [transactionId, setTransactionId] = React.useState<string | undefined>();
  const [prompt, setPrompt] = React.useState<string>("");
  const [phase, setPhase] = React.useState<Phase>("idle");
  const [transcript, setTranscript] = React.useState("");
  const [reply, setReply] = React.useState("");
  const [typed, setTyped] = React.useState("");
  const [showTyped, setShowTyped] = React.useState(false);
  const [speaking, setSpeaking] = React.useState(false);
  const recorderRef = React.useRef<MediaRecorder | null>(null);
  const chunksRef = React.useRef<Blob[]>([]);
  const streamRef = React.useRef<MediaStream | null>(null);

  const cleanupStream = React.useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  }, []);

  const openAssistant = React.useCallback(
    (options?: OpenOptions) => {
      setMode(options?.mode ?? "coach");
      setTransactionId(options?.transactionId);
      setPrompt(options?.prompt ?? (options?.mode === "expense" ? t("voice.expensePrompt") : ""));
      setPhase("idle");
      setTranscript("");
      setReply("");
      setTyped("");
      setShowTyped(false);
      setOpen(true);
    },
    [t],
  );

  React.useEffect(() => () => cleanupStream(), [cleanupStream]);

  const runCoach = React.useCallback(
    async (text: string) => {
      setPhase("processing");
      try {
        const res = await fetch("/api/coach", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: text, speak: true }),
        });
        const data = (await res.json()) as { reply?: string; error?: string };
        if (!res.ok || !data.reply) throw new Error(data.error ?? "coach_failed");
        setReply(data.reply);
        setPhase("result");
        setSpeaking(true);
        await speak(data.reply, lang);
        setSpeaking(false);
      } catch {
        toast({ kind: "error", title: t("common.error") });
        setPhase("idle");
      }
    },
    [lang, t, toast],
  );

  const saveLabel = React.useCallback(
    async (text: string) => {
      setPhase("processing");
      try {
        const res = await fetch("/api/voice/label", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ transactionId, transcript: text, language: lang }),
        });
        if (!res.ok) throw new Error("label_failed");
        toast({ kind: "success", title: t("voice.saved"), description: text });
        setOpen(false);
        setPhase("idle");
        window.dispatchEvent(new CustomEvent("finsight:refresh"));
      } catch {
        toast({ kind: "error", title: t("common.error") });
        setPhase("idle");
      }
    },
    [lang, t, toast, transactionId],
  );

  const handleTranscript = React.useCallback(
    async (text: string) => {
      const clean = text.trim();
      if (!clean) {
        setPhase("idle");
        toast({ kind: "error", title: t("voice.error") });
        return;
      }
      setTranscript(clean);
      if (mode === "expense") await saveLabel(clean);
      else await runCoach(clean);
    },
    [mode, runCoach, saveLabel, t, toast],
  );

  const startRecording = React.useCallback(async () => {
    try {
      stopSpeaking();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "" });
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onstop = async () => {
        cleanupStream();
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        if (blob.size < 800) {
          setPhase("idle");
          toast({ kind: "error", title: t("voice.error") });
          return;
        }
        setPhase("processing");
        try {
          const form = new FormData();
          form.append("audio", blob, "speech.webm");
          form.append("language", lang);
          const res = await fetch("/api/voice/stt", { method: "POST", body: form });
          const data = (await res.json()) as { transcript?: string };
          if (!data.transcript) throw new Error("no_transcript");
          await handleTranscript(data.transcript);
        } catch {
          setPhase("idle");
          toast({ kind: "error", title: t("voice.error"), description: t("voice.type") });
          setShowTyped(true);
        }
      };
      recorder.start();
      recorderRef.current = recorder;
      setPhase("recording");
    } catch {
      setShowTyped(true);
      toast({ kind: "error", title: t("voice.error"), description: t("voice.type") });
    }
  }, [cleanupStream, handleTranscript, lang, t, toast]);

  const stopRecording = React.useCallback(() => {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
  }, []);

  const submitTyped = React.useCallback(
    async (event: React.FormEvent) => {
      event.preventDefault();
      if (!typed.trim()) return;
      await handleTranscript(typed);
      setTyped("");
    },
    [handleTranscript, typed],
  );

  return (
    <VoiceContext.Provider value={{ open: openAssistant }}>
      {children}
      <Dialog
        open={open}
        onOpenChange={(next) => {
          setOpen(next);
          if (!next) {
            cleanupStream();
            stopSpeaking();
            setPhase("idle");
          }
        }}
      >
        <DialogContent className="max-w-md overflow-hidden">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-brand/15 to-transparent" />
          <div className="relative flex items-center gap-3">
            <span className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white">
              <AudioLines className="h-5 w-5" />
            </span>
            <div>
              <DialogTitle className="text-lg">{t("voice.title")}</DialogTitle>
              <DialogDescription className="text-xs">{prompt || t("coach.subtitle")}</DialogDescription>
            </div>
          </div>

          <div className="relative rounded-2xl border border-line/80 bg-elevated/40 p-4">
            <AnimatePresence mode="wait">
              {phase === "idle" && (
                <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center">
                  <Waveform active={false} />
                  <p className="mt-2 text-sm font-medium">{prompt || t("coach.placeholder")}</p>
                  <p className="mt-1 text-xs text-muted">{t("voice.listen")}</p>
                </motion.div>
              )}
              {phase === "recording" && (
                <motion.div key="rec" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center">
                  <Waveform active />
                  <p className="mt-2 text-sm font-medium text-brand-200">{t("voice.listening")}</p>
                </motion.div>
              )}
              {phase === "processing" && (
                <motion.div key="proc" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center gap-2 py-3 text-center">
                  <Loader2 className="h-6 w-6 animate-spin text-brand-300" />
                  <p className="text-sm text-muted">{mode === "expense" ? t("voice.processing") : t("coach.thinking")}</p>
                </motion.div>
              )}
              {phase === "result" && (
                <motion.div key="result" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-3">
                  <p className="text-[11px] uppercase tracking-widest text-faint">{transcript}</p>
                  <p className="text-sm leading-relaxed">{reply}</p>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={async () => {
                      setSpeaking(true);
                      await speak(reply, lang);
                      setSpeaking(false);
                    }}
                  >
                    <Volume2 className={cn("h-4 w-4", speaking && "animate-pulse")} />
                    {t("voice.speak")}
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {showTyped && (
            <form onSubmit={submitTyped} className="flex gap-2">
              <Input
                value={typed}
                onChange={(e) => setTyped(e.target.value)}
                placeholder={t("voice.placeholder")}
                autoFocus
              />
              <Button type="submit" size="sm" className="h-11 px-4">
                {t("common.save")}
              </Button>
            </form>
          )}

          <div className="flex items-center justify-between gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowTyped((v) => !v)}>
              <Keyboard className="h-4 w-4" />
              {t("voice.type")}
            </Button>
            {phase === "recording" ? (
              <Button variant="danger" onClick={stopRecording}>
                <Square className="h-4 w-4" />
                {t("voice.stop")}
              </Button>
            ) : (
              <Button onClick={startRecording} disabled={phase === "processing"}>
                <Mic className="h-4 w-4" />
                {t("voice.listen")}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </VoiceContext.Provider>
  );
}
