import { sarvamChat, sarvamEnabled, type SarvamMessage } from "@/lib/sarvam";

export type AIMessage = SarvamMessage;

export interface AIResult {
  text: string;
  engine: "sarvam" | "platform" | "offline";
}

const PLATFORM_MODEL = process.env.AI_MODEL || "gpt-5-mini";

export const LANGUAGE_NAME: Record<string, string> = {
  en: "English",
  hi: "Hindi",
  kn: "Kannada",
  ta: "Tamil",
  te: "Telugu",
  ml: "Malayalam",
  mr: "Marathi",
  bn: "Bengali",
  gu: "Gujarati",
  pa: "Punjabi",
  or: "Odia",
};

async function platformChat(messages: AIMessage[], maxTokens: number): Promise<string> {
  const base = process.env.MANUS_API_URL;
  const key = process.env.MANUS_API_KEY;
  if (!base || !key) throw new Error("platform_ai_unavailable");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30_000);
  try {
    const res = await fetch(`${base}/v1/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: PLATFORM_MODEL,
        messages,
        max_completion_tokens: maxTokens,
      }),
    });
    const data = (await res.json()) as {
      error?: { message?: string };
      choices?: { message?: { content?: string } }[];
    };
    if (data.error) throw new Error(data.error.message ?? "platform_ai_error");
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("platform_ai_empty");
    return text;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Sarvam first (when configured), then the platform's built-in model, then a caller
 * supplied offline string. Never throws.
 */
export async function aiChat(
  messages: AIMessage[],
  opts: { maxTokens?: number; offline?: string } = {},
): Promise<AIResult> {
  const maxTokens = opts.maxTokens ?? 700;
  if (sarvamEnabled()) {
    try {
      return { text: await sarvamChat(messages, { maxTokens }), engine: "sarvam" };
    } catch {
      /* fall through */
    }
  }
  try {
    return { text: await platformChat(messages, maxTokens), engine: "platform" };
  } catch {
    return { text: opts.offline ?? "", engine: "offline" };
  }
}

function stripFence(text: string): string {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced ? fenced[1] : text;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  return start >= 0 && end > start ? body.slice(start, end + 1) : body;
}

export async function aiJson<T>(messages: AIMessage[], fallback: T): Promise<{ data: T; engine: AIResult["engine"] }> {
  const result = await aiChat(messages, { maxTokens: 500 });
  if (!result.text) return { data: fallback, engine: result.engine };
  try {
    return { data: JSON.parse(stripFence(result.text)) as T, engine: result.engine };
  } catch {
    return { data: fallback, engine: result.engine };
  }
}

export function coachSystemPrompt(context: string, language: string): string {
  return [
    "You are FinSight's money coach for Indian users. You are warm, concrete and brief (max 120 words unless asked for a plan).",
    `Always reply in ${LANGUAGE_NAME[language] ?? "English"} using the same script.`,
    "Use rupees and Indian examples (UPI, SIP, emergency fund, PPF, recurring deposits).",
    "Never guarantee returns, never present stock tips as certainties, and never recommend a specific regulated product as advice.",
    "End with one short line: 'This is general guidance, not regulated financial advice.' in the user's language.",
    "Here is the user's live financial snapshot:",
    context,
  ].join("\n");
}

export function offlineCoachReply(language: string): string {
  const replies: Record<string, string> = {
    en: "I can't reach the AI service right now, but here is the safe move: keep this month's fixed bills aside first, then cap discretionary spending at the smallest category limit on your Budget page. This is general guidance, not regulated financial advice.",
    hi: "अभी AI सेवा उपलब्ध नहीं है। सुरक्षित कदम: पहले इस महीने के तय बिल अलग रखें, फिर बजट पेज पर सबसे छोटी श्रेणी की सीमा तक ही खर्च करें। यह सामान्य मार्गदर्शन है, नियामकीय वित्तीय सलाह नहीं।",
  };
  return replies[language] ?? replies.en;
}
