import { normalizePayee } from "@/lib/categories";

export interface AnomalyTxn {
  date: Date;
  amount: number;
  type: "DEBIT" | "CREDIT";
  payee: string;
  category: string;
}

export interface AnomalyResult {
  score: number;
  isAnomaly: boolean;
  reason: string | null;
  signals: string[];
}

function stats(values: number[]) {
  if (!values.length) return { mean: 0, sd: 0, count: 0 };
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  const sd = Math.sqrt(values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length);
  return { mean, sd, count: values.length };
}

/**
 * Score a candidate payment against 90 days of history.
 * z-score per category plus rules: 3x category average, brand-new payee with a
 * high amount, odd-hour payment, duplicate within minutes.
 */
export function scoreAnomaly(
  candidate: { amount: number; payee: string; category: string; date?: Date },
  history: AnomalyTxn[],
): AnomalyResult {
  const signals: string[] = [];
  let score = 0;
  const key = normalizePayee(candidate.payee);
  const debits = history.filter((t) => t.type === "DEBIT");
  const sameCategory = debits.filter((t) => t.category === candidate.category).map((t) => t.amount);
  const samePayee = debits.filter((t) => normalizePayee(t.payee) === key);

  const cat = stats(sameCategory);
  if (cat.count >= 3 && cat.sd > 0) {
    const z = (candidate.amount - cat.mean) / cat.sd;
    if (z > 2) {
      score += Math.min(0.45, 0.12 * z);
      signals.push(`amount_zscore:${z.toFixed(1)}`);
    }
    if (candidate.amount > cat.mean * 3 && candidate.amount > 1500) {
      score += 0.3;
      signals.push("amount_3x_category_average");
    }
  }

  if (samePayee.length === 0 && candidate.amount >= 5000) {
    score += 0.4;
    signals.push("new_payee_high_amount");
  }

  const hour = (candidate.date ?? new Date()).getHours();
  if ((hour >= 0 && hour <= 5) && candidate.amount >= 2000) {
    score += 0.15;
    signals.push("odd_hour");
  }

  const recentDuplicate = samePayee.find(
    (t) => Math.abs(t.amount - candidate.amount) < 1 && Math.abs(t.date.getTime() - (candidate.date ?? new Date()).getTime()) < 15 * 60_000,
  );
  if (recentDuplicate) {
    score += 0.55;
    signals.push("duplicate_within_minutes");
  }

  if (candidate.amount >= 40000) {
    score += 0.2;
    signals.push("very_large_amount");
  }

  const final = Math.min(1, Number(score.toFixed(2)));
  const isAnomaly = final >= 0.5;
  let reason: string | null = null;
  if (isAnomaly) {
    if (signals.includes("duplicate_within_minutes")) reason = "duplicate";
    else if (signals.includes("new_payee_high_amount")) reason = "unknown_payee";
    else if (signals.includes("amount_3x_category_average")) reason = "spike";
    else if (signals.includes("odd_hour")) reason = "odd_hour";
    else reason = "unusual";
  }
  return { score: final, isAnomaly, reason, signals };
}

/** Re-scan a full transaction history and flag outliers. */
export function scanAnomalies<T extends AnomalyTxn & { id: string }>(transactions: T[]) {
  const sorted = [...transactions].sort((a, b) => a.date.getTime() - b.date.getTime());
  const flags: Record<string, AnomalyResult> = {};
  for (let i = 0; i < sorted.length; i++) {
    const tx = sorted[i];
    if (tx.type !== "DEBIT") continue;
    const history = sorted.slice(Math.max(0, i - 120), i);
    const result = scoreAnomaly(tx, history);
    if (result.isAnomaly) flags[tx.id] = result;
  }
  return flags;
}
