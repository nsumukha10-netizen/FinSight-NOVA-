export type CategoryGroup = "Needs" | "Wants" | "Savings" | "Income" | "Transfer" | "Other";

export interface CategoryMeta {
  key: string;
  group: CategoryGroup;
  color: string;
  discretionary: boolean;
  fixed: boolean;
  icon: string;
}

export const CATEGORIES: CategoryMeta[] = [
  { key: "Income", group: "Income", color: "#10B981", discretionary: false, fixed: false, icon: "ArrowDownLeft" },
  { key: "Rent", group: "Needs", color: "#6366F1", discretionary: false, fixed: true, icon: "Home" },
  { key: "EMI & Loans", group: "Needs", color: "#8B5CF6", discretionary: false, fixed: true, icon: "Landmark" },
  { key: "Investments", group: "Savings", color: "#14B8A6", discretionary: false, fixed: true, icon: "TrendingUp" },
  { key: "Groceries", group: "Needs", color: "#22C55E", discretionary: false, fixed: false, icon: "ShoppingBasket" },
  { key: "Food Delivery", group: "Wants", color: "#F97316", discretionary: true, fixed: false, icon: "Bike" },
  { key: "Dining & Cafes", group: "Wants", color: "#FB923C", discretionary: true, fixed: false, icon: "UtensilsCrossed" },
  { key: "Shopping", group: "Wants", color: "#EC4899", discretionary: true, fixed: false, icon: "ShoppingBag" },
  { key: "Subscriptions", group: "Wants", color: "#A855F7", discretionary: true, fixed: true, icon: "Repeat" },
  { key: "Transport", group: "Needs", color: "#0EA5E9", discretionary: false, fixed: false, icon: "Car" },
  { key: "Utilities", group: "Needs", color: "#64748B", discretionary: false, fixed: false, icon: "Zap" },
  { key: "Health", group: "Needs", color: "#EF4444", discretionary: false, fixed: false, icon: "HeartPulse" },
  { key: "Education", group: "Needs", color: "#3B82F6", discretionary: false, fixed: false, icon: "GraduationCap" },
  { key: "Entertainment", group: "Wants", color: "#F43F5E", discretionary: true, fixed: false, icon: "Clapperboard" },
  { key: "Business Supplies", group: "Needs", color: "#84CC16", discretionary: false, fixed: false, icon: "Package" },
  { key: "Transfer", group: "Transfer", color: "#94A3B8", discretionary: false, fixed: false, icon: "ArrowLeftRight" },
  { key: "Cash & ATM", group: "Other", color: "#A1A1AA", discretionary: false, fixed: false, icon: "Banknote" },
  { key: "Other", group: "Other", color: "#71717A", discretionary: false, fixed: false, icon: "Circle" },
];

export const CATEGORY_MAP: Record<string, CategoryMeta> = Object.fromEntries(
  CATEGORIES.map((c) => [c.key, c]),
);

export const CATEGORY_KEYS = CATEGORIES.map((c) => c.key);

export function categoryMeta(key: string): CategoryMeta {
  return CATEGORY_MAP[key] ?? CATEGORY_MAP.Other;
}

export function categoryColor(key: string): string {
  return categoryMeta(key).color;
}

/** i18n key for a category label, e.g. "cat.food_delivery". */
export function categoryI18nKey(key: string): string {
  const slug = key
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
  return `cat.${slug}`;
}

export const DISCRETIONARY_CATEGORIES = CATEGORIES.filter((c) => c.discretionary).map((c) => c.key);

interface MerchantRule {
  match: string[];
  category: string;
  subcategory?: string;
  payee?: string;
}

export const MERCHANT_RULES: MerchantRule[] = [
  { match: ["swiggy", "swiggy instamart"], category: "Food Delivery", subcategory: "Swiggy", payee: "Swiggy" },
  { match: ["zomato", "zomato gold"], category: "Food Delivery", subcategory: "Zomato", payee: "Zomato" },
  { match: ["dominos", "domino's", "pizza hut", "kfc", "burger king", "mcdonald"], category: "Food Delivery" },
  { match: ["eatsure", "faasos", "behrouz", "box8", "rebelfoods"], category: "Food Delivery" },
  { match: ["blinkit", "zepto", "instamart", "dunzo"], category: "Groceries" },
  { match: ["bigbasket", "dmart", "d-mart", "reliance fresh", "more retail", "spencer", "jiomart"], category: "Groceries", payee: "BigBasket" },
  { match: ["amazon", "amzn"], category: "Shopping", subcategory: "Amazon", payee: "Amazon" },
  { match: ["flipkart", "myntra", "ajio", "meesho", "nykaa", "tata cliq", "snapdeal"], category: "Shopping" },
  { match: ["netflix"], category: "Subscriptions", subcategory: "Netflix", payee: "Netflix" },
  { match: ["spotify"], category: "Subscriptions", subcategory: "Spotify", payee: "Spotify" },
  { match: ["hotstar", "disney", "prime video", "sonyliv", "zee5", "jiocinema"], category: "Subscriptions" },
  { match: ["youtube premium", "google one", "icloud", "apple"], category: "Subscriptions" },
  { match: ["jio", "airtel", "vi ", "vodafone", "bsnl"], category: "Utilities", subcategory: "Mobile" },
  { match: ["electricity", "bescom", "mseb", "tneb", "bses", "adani electricity", "torrent power"], category: "Utilities" },
  { match: ["gas", "indane", "hp gas", "bharat gas"], category: "Utilities" },
  { match: ["water bill", "municipal"], category: "Utilities" },
  { match: ["uber", "ola", "rapido", "namma yatri", "blusmart"], category: "Transport" },
  { match: ["irctc", "indian rail", "redbus", "metro", "fastag", "petrol", "hpcl", "iocl", "bpcl"], category: "Transport" },
  { match: ["pharmacy", "apollo", "medplus", "netmeds", "1mg", "practo", "hospital", "clinic", "dental"], category: "Health" },
  { match: ["gym", "cult.fit", "cultfit", "fitness"], category: "Health" },
  { match: ["school", "college", "tuition", "udemy", "coursera", "byju", "unacademy", "vedantu", "book"], category: "Education" },
  { match: ["bookmyshow", "pvr", "inox", "cinema", "gaming", "steam", "playstation"], category: "Entertainment" },
  { match: ["rent", "landlord", "nobroker", "housing"], category: "Rent" },
  { match: ["emi", "loan", "hdfc loan", "bajaj finance", "tata capital", "home loan", "car loan"], category: "EMI & Loans" },
  { match: ["sip", "mutual fund", "groww", "zerodha", "kuvera", "coin", "indmoney", "smallcase", "ppf", "nps"], category: "Investments" },
  { match: ["lic", "insurance", "policybazaar", "acko", "digit"], category: "Health" },
  { match: ["salary", "payroll", "stipend", "wages"], category: "Income" },
  { match: ["upi/unknown", "unknown", "unlisted"], category: "Other" },
  { match: ["cash withdrawal", "atm", "cash"], category: "Cash & ATM" },
  { match: ["supplier", "wholesale", "inventory", "stock purchase", "distributor"], category: "Business Supplies" },
  { match: ["self transfer", "own account", "imps", "neft", "rtgs"], category: "Transfer" },
];

/** Normalize a payee for matching and grouping. */
export function normalizePayee(payee: string): string {
  return payee
    .toLowerCase()
    .replace(/\b(upi|paytm|phonepe|gpay|googlepay|razorpay|billdesk|payment|pvt|ltd|limited|india|in)\b/g, " ")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function matchMerchant(payee: string, description = ""): MerchantRule | null {
  const hay = `${payee} ${description}`.toLowerCase();
  return MERCHANT_RULES.find((rule) => rule.match.some((m) => hay.includes(m))) ?? null;
}
