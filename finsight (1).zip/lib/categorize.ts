import { matchMerchant, normalizePayee, categoryMeta } from "@/lib/categories";

export interface CategorizeResult {
  category: string;
  subcategory?: string;
  payee: string;
  confidence: number;
  source: "rule" | "learned" | "llm" | "default";
}

export function categorizeByRules(
  payee: string,
  rawDescription = "",
  learned?: Record<string, string>,
): CategorizeResult {
  const key = normalizePayee(payee);
  if (learned && learned[key]) {
    return { category: learned[key], payee, confidence: 0.95, source: "learned" };
  }
  const rule = matchMerchant(payee, rawDescription);
  if (rule) {
    return {
      category: rule.category,
      subcategory: rule.subcategory,
      payee: rule.payee ?? payee,
      confidence: 0.9,
      source: "rule",
    };
  }
  return { category: "Other", payee, confidence: 0.3, source: "default" };
}

export function isValidCategory(category: string): boolean {
  return Boolean(categoryMeta(category));
}

export function suggestCategoryFromText(text: string): string {
  const rule = matchMerchant(text);
  return rule?.category ?? "Other";
}
