export const DAY_MS = 86_400_000;

export function startOfDay(d: Date | string): Date {
  const date = typeof d === "string" ? new Date(d) : new Date(d.getTime());
  date.setHours(0, 0, 0, 0);
  return date;
}

export function addDays(d: Date, n: number): Date {
  const next = new Date(d.getTime());
  next.setDate(next.getDate() + n);
  next.setHours(0, 0, 0, 0);
  return next;
}

export function daysBetween(a: Date, b: Date): number {
  return Math.round((startOfDay(b).getTime() - startOfDay(a).getTime()) / DAY_MS);
}

export function iso(d: Date): string {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function monthKey(d: Date): string {
  return `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, "0")}`;
}

export function startOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

export function endOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
}

/** Due date for a given month, clamped to the month length (e.g. 31 -> 30). */
export function dueDateInMonth(year: number, month: number, dueDay: number): Date {
  const last = new Date(year, month + 1, 0).getDate();
  return new Date(year, month, Math.min(Math.max(1, dueDay), last));
}

export function shortDate(d: Date | string, lang = "en-IN"): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString(lang, { day: "numeric", month: "short" });
}

export function longDate(d: Date | string, lang = "en-IN"): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString(lang, { day: "numeric", month: "long", year: "numeric" });
}

export function relativeDays(target: Date | string): number {
  return daysBetween(new Date(), typeof target === "string" ? new Date(target) : target);
}
