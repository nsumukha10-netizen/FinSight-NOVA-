import { prisma } from "@/lib/prisma";
import { addDays, dueDateInMonth, endOfMonth, iso, startOfDay, startOfMonth } from "@/lib/dates";
import { buildForecast, backtestForecast } from "@/lib/forecast";
import { buildLimits } from "@/lib/limits";
import { computeHealth } from "@/lib/health";
import type {
  BacktestResult,
  BudgetRow,
  ForecastInput,
  ForecastResult,
  ForecastTxn,
  HealthResult,
  PersonaKey,
} from "@/lib/types";
import { categoryMeta } from "@/lib/categories";

export interface UpcomingBill {
  name: string;
  amount: number;
  dueDate: string;
  daysAway: number;
  type: string;
}

export interface FinanceSnapshot {
  userId: string;
  name: string;
  persona: PersonaKey;
  language: string;
  monthlyIncome: number;
  incomeDay: number;
  survivalTarget: number | null;
  balance: number;
  bankName: string | null;
  last4: string | null;
  monthIncome: number;
  monthExpenses: number;
  avgMonthlyIncome: number;
  monthlyObligations: number;
  spendByCategory: Record<string, number>;
  baselineByCategory: Record<string, number>;
  transactions: {
    id: string;
    date: string;
    amount: number;
    type: "DEBIT" | "CREDIT";
    payee: string;
    rawDescription: string;
    category: string;
    isRecurring: boolean;
    isAnomaly: boolean;
    anomalyScore: number;
    anomalyReason: string | null;
    voiceLabel: string | null;
    note: string | null;
    balanceAfter: number;
  }[];
  obligations: { id: string; name: string; type: string; amount: number; dueDay: number }[];
  limits: BudgetRow[];
  forecast: ForecastResult;
  backtest: BacktestResult;
  health: HealthResult;
  upcomingBills: UpcomingBill[];
  runwayDays: number;
  anomalies90: number;
  goals: { id: string; name: string; targetAmount: number; savedAmount: number; targetDate: string }[];
  alerts: { id: string; type: string; severity: string; message: string; explanation: string; createdAt: string; resolved: boolean }[];
  generatedAt: string;
}

const cache = new Map<string, { at: number; value: FinanceSnapshot }>();
const TTL_MS = 45_000;

export function invalidateFinance(userId: string) {
  cache.delete(userId);
}

export async function getFinanceSnapshot(userId: string, force = false): Promise<FinanceSnapshot> {
  const hit = cache.get(userId);
  if (!force && hit && Date.now() - hit.at < TTL_MS) return hit.value;

  const [user, account, transactions, obligations, goals, alerts] = await Promise.all([
    prisma.user.findUniqueOrThrow({ where: { id: userId } }),
    prisma.bankAccount.findFirst({ where: { userId }, orderBy: { linkedAt: "desc" } }),
    prisma.transaction.findMany({ where: { userId }, orderBy: { date: "asc" }, take: 4000 }),
    prisma.obligation.findMany({ where: { userId, active: true } }),
    prisma.goal.findMany({ where: { userId }, orderBy: { targetDate: "asc" } }),
    prisma.alert.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 20 }),
  ]);

  const now = new Date();
  const monthStart = startOfMonth(now);
  const monthEnd = endOfMonth(now);
  const last90 = addDays(now, -90);

  const inMonth = transactions.filter((t) => t.date >= monthStart && t.date <= monthEnd);
  const monthIncome = inMonth.filter((t) => t.type === "CREDIT").reduce((s, t) => s + t.amount, 0);
  const monthExpenses = inMonth.filter((t) => t.type === "DEBIT" && !t.isAnomaly).reduce((s, t) => s + t.amount, 0);

  const spendByCategory: Record<string, number> = {};
  for (const t of inMonth) {
    if (t.type !== "DEBIT" || t.isAnomaly) continue;
    spendByCategory[t.category] = (spendByCategory[t.category] ?? 0) + t.amount;
  }

  // Three-month monthly average, excluding flagged anomalies, used to size budgets.
  const baselineByCategory: Record<string, number> = {};
  for (const t of transactions) {
    if (t.type !== "DEBIT" || t.isAnomaly || t.date < last90) continue;
    baselineByCategory[t.category] = (baselineByCategory[t.category] ?? 0) + t.amount;
  }
  for (const key of Object.keys(baselineByCategory)) {
    baselineByCategory[key] = Math.round(baselineByCategory[key] / 3);
  }

  const last3 = transactions.filter((t) => t.date >= addDays(now, -120) && t.type === "CREDIT");
  const avgMonthlyIncome = last3.length
    ? Math.round((last3.reduce((s, t) => s + t.amount, 0) / 120) * 30)
    : user.monthlyIncome;

  const monthlyObligations = obligations.reduce((s, o) => s + o.amount, 0);
  const forecastInput: ForecastInput = {
    persona: user.persona as PersonaKey,
    balance: account?.balance ?? 0,
    monthlyIncome: user.monthlyIncome,
    incomeDay: user.incomeDay,
    dailySales: user.dailySales,
    obligations: obligations.map((o) => ({ name: o.name, type: o.type, amount: o.amount, dueDay: o.dueDay })),
    transactions: transactions.map((t) => ({
      date: t.date,
      amount: t.amount,
      type: t.type as "DEBIT" | "CREDIT",
      category: t.category,
      payee: t.payee,
      isAnomaly: t.isAnomaly,
    })) satisfies ForecastTxn[],
    horizon: 90,
    startDate: startOfDay(now),
  };

  const forecast = buildForecast(forecastInput);
  const backtest = backtestForecast(forecastInput, 30);

  const limits = buildLimits({
    persona: user.persona as PersonaKey,
    monthlyIncome: user.monthlyIncome || avgMonthlyIncome,
    obligations: forecastInput.obligations,
    transactions: forecastInput.transactions,
    spendByCategory,
    baselineByCategory,
    shortageWithin30: (forecast.cumulativeShortage[29] ?? 0) >= 0.3,
  });

  const essentialMonthly = obligations.reduce(
    (s, o) => s + (["RENT", "EMI", "LOAN", "GROCERY", "OTHER"].includes(o.type) ? o.amount : 0),
    0,
  );
  const dailyNeed = essentialMonthly > 0 ? essentialMonthly / 30 : Math.max(1, monthExpenses / Math.max(1, now.getDate()));
  const runwayDays = Math.max(0, Math.round((account?.balance ?? 0) / dailyNeed));

  const anomalies90 = transactions.filter((t) => t.isAnomaly && t.date >= last90).length;
  const withinBudget = limits.filter((l) => l.spent <= l.monthlyLimit).length;
  const health = computeHealth({
    monthlyIncome: user.monthlyIncome || avgMonthlyIncome,
    monthlyExpenses: monthExpenses,
    balance: account?.balance ?? 0,
    monthlyObligations,
    anomalyCount: anomalies90,
    budgetAdherence: limits.length ? withinBudget / limits.length : 0.5,
    runwayDays,
    hasForecastShortage: (forecast.cumulativeShortage[29] ?? 0) >= 0.4,
  });

  const upcomingBills: UpcomingBill[] = [];
  for (const ob of obligations) {
    for (let m = 0; m < 2; m++) {
      const base = new Date(now.getFullYear(), now.getMonth() + m, 1);
      const due = dueDateInMonth(base.getFullYear(), base.getMonth(), ob.dueDay);
      const daysAway = Math.round((due.getTime() - startOfDay(now).getTime()) / 86_400_000);
      if (daysAway >= 0 && daysAway <= 45) {
        upcomingBills.push({
          name: ob.name,
          amount: ob.amount,
          dueDate: iso(due),
          daysAway,
          type: ob.type,
        });
      }
    }
  }
  upcomingBills.sort((a, b) => a.daysAway - b.daysAway);

  const snapshot: FinanceSnapshot = {
    userId: user.id,
    name: user.name,
    persona: user.persona as PersonaKey,
    language: user.language,
    monthlyIncome: user.monthlyIncome,
    incomeDay: user.incomeDay,
    survivalTarget: user.survivalTarget,
    balance: account?.balance ?? 0,
    bankName: account?.bankName ?? null,
    last4: account?.last4 ?? null,
    monthIncome,
    monthExpenses,
    avgMonthlyIncome,
    monthlyObligations,
    spendByCategory,
    baselineByCategory,
    transactions: transactions.map((t) => ({
      id: t.id,
      date: t.date.toISOString(),
      amount: t.amount,
      type: t.type as "DEBIT" | "CREDIT",
      payee: t.payee,
      rawDescription: t.rawDescription,
      category: t.category,
      isRecurring: t.isRecurring,
      isAnomaly: t.isAnomaly,
      anomalyScore: t.anomalyScore,
      anomalyReason: t.anomalyReason,
      voiceLabel: t.voiceLabel,
      note: t.note,
      balanceAfter: t.balanceAfter,
    })),
    obligations: obligations.map((o) => ({ id: o.id, name: o.name, type: o.type, amount: o.amount, dueDay: o.dueDay })),
    limits,
    forecast,
    backtest,
    health,
    upcomingBills,
    runwayDays,
    anomalies90,
    goals: goals.map((g) => ({
      id: g.id,
      name: g.name,
      targetAmount: g.targetAmount,
      savedAmount: g.savedAmount,
      targetDate: g.targetDate.toISOString(),
    })),
    alerts: alerts.map((a) => ({
      id: a.id,
      type: a.type,
      severity: a.severity,
      message: a.message,
      explanation: a.explanation,
      createdAt: a.createdAt.toISOString(),
      resolved: a.resolved,
    })),
    generatedAt: new Date().toISOString(),
  };

  cache.set(userId, { at: Date.now(), value: snapshot });
  return snapshot;
}

/** Text block used as context for the coach and explanations. */
export function financeContextText(s: FinanceSnapshot): string {
  const topCats = Object.entries(s.spendByCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([c, v]) => `${c} ₹${Math.round(v)}`)
    .join(", ");
  return [
    `Persona: ${s.persona}`,
    `Balance: ₹${Math.round(s.balance)}`,
    `Monthly income: ₹${Math.round(s.monthlyIncome)} (credit day ${s.incomeDay})`,
    `This month income ₹${Math.round(s.monthIncome)}, expenses ₹${Math.round(s.monthExpenses)}`,
    `Fixed monthly obligations ₹${Math.round(s.monthlyObligations)}`,
    `Health score ${s.health.score}/100 (${s.health.grade})`,
    `Runway ${s.runwayDays} days`,
    `Top spend categories: ${topCats || "none yet"}`,
    `Forecast in 90 days: expected ₹${s.forecast.endP50}, worst ₹${s.forecast.endP10}, best ₹${s.forecast.endP90}`,
    s.forecast.shortageDate
      ? `Shortage risk: ${Math.round(s.forecast.shortageProbability * 100)}% chance of hitting zero around ${s.forecast.shortageDate}`
      : `Shortage risk: ${Math.round(s.forecast.shortageProbability * 100)}% within 90 days`,
    `Budget categories: ${s.limits.map((l) => `${l.category} ₹${l.monthlyLimit} (spent ₹${l.spent})`).join("; ")}`,
  ].join("\n");
}

export function spendShare(s: FinanceSnapshot, category: string): number {
  const total = Object.values(s.spendByCategory).reduce((a, b) => a + b, 0);
  if (!total) return 0;
  return (s.spendByCategory[category] ?? 0) / total;
}

export function forecastInputFromSnapshot(s: FinanceSnapshot, horizon = 90): ForecastInput {
  return {
    persona: s.persona,
    balance: s.balance,
    monthlyIncome: s.monthlyIncome,
    incomeDay: s.incomeDay,
    obligations: s.obligations.map((o) => ({ name: o.name, type: o.type, amount: o.amount, dueDay: o.dueDay })),
    transactions: s.transactions.map((t) => ({
      date: new Date(t.date),
      amount: t.amount,
      type: t.type,
      category: t.category,
      payee: t.payee,
      isAnomaly: t.isAnomaly,
    })),
    horizon,
    startDate: startOfDay(new Date()),
  };
}

export function groupSpend(s: FinanceSnapshot): { group: string; value: number; color: string }[] {
  const groups: Record<string, number> = {};
  for (const [cat, value] of Object.entries(s.spendByCategory)) {
    const group = categoryMeta(cat).group;
    groups[group] = (groups[group] ?? 0) + value;
  }
  const colors: Record<string, string> = { Needs: "#4F46E5", Wants: "#F59E0B", Savings: "#10B981", Other: "#64748B" };
  return Object.entries(groups).map(([group, value]) => ({ group, value, color: colors[group] ?? "#64748B" }));
}
