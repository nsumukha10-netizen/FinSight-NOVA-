import { addDays, DAY_MS, dueDateInMonth, iso, startOfDay } from "@/lib/dates";
import type {
  BacktestResult,
  ForecastInput,
  ForecastObligation,
  ForecastPoint,
  ForecastResult,
  ForecastTxn,
} from "@/lib/types";

const SIMULATIONS = 1000;
const FIXED_CATEGORIES = new Set(["Rent", "EMI & Loans", "Investments"]);

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function rng() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gauss(rng: () => number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function percentile(sorted: number[], p: number): number {
  if (!sorted.length) return 0;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function mean(nums: number[]): number {
  return nums.length ? nums.reduce((s, n) => s + n, 0) / nums.length : 0;
}

function sd(nums: number[]): number {
  if (nums.length < 2) return 0;
  const m = mean(nums);
  return Math.sqrt(nums.reduce((s, n) => s + (n - m) ** 2, 0) / nums.length);
}

interface WeekdayStat {
  mean: number;
  sd: number;
}

function weekdayStats(transactions: ForecastTxn[], endDate: Date, days = 120, filter: (t: ForecastTxn) => boolean): WeekdayStat[] {
  const buckets: number[][] = Array.from({ length: 7 }, () => []);
  const start = addDays(endDate, -days);
  const byDay = new Map<string, number>();
  for (const tx of transactions) {
    const d = startOfDay(tx.date);
    if (d < start || d > endDate) continue;
    if (!filter(tx)) continue;
    const key = iso(d);
    byDay.set(key, (byDay.get(key) ?? 0) + tx.amount);
  }
  for (let i = 0; i < days; i++) {
    const day = addDays(start, i);
    buckets[day.getDay()].push(byDay.get(iso(day)) ?? 0);
  }
  const overall = mean(buckets.flat());
  return buckets.map((values) => {
    const m = values.length >= 3 ? mean(values) : overall;
    const s = values.length >= 4 ? Math.max(80, sd(values)) : Math.max(120, overall * 0.45);
    return { mean: Math.max(0, m), sd: s };
  });
}

function obligationDueOn(date: Date, obligations: ForecastObligation[]): number {
  let total = 0;
  for (const ob of obligations) {
    const due = dueDateInMonth(date.getFullYear(), date.getMonth(), ob.dueDay);
    if (due.getDate() === date.getDate()) total += ob.amount;
  }
  return total;
}

function salaryDueOn(date: Date, incomeDay: number): boolean {
  const due = dueDateInMonth(date.getFullYear(), date.getMonth(), incomeDay);
  return due.getDate() === date.getDate();
}

interface Model {
  persona: ForecastInput["persona"];
  startBalance: number;
  startDate: Date;
  horizon: number;
  monthlyIncome: number;
  incomeDay: number;
  obligations: ForecastObligation[];
  spendByDow: WeekdayStat[];
  incomeByDow: WeekdayStat[];
  eventRate: number;
  eventMean: number;
  eventSd: number;
  otherCreditsPerMonth: number;
  oneOffs: { offset: number; amount: number }[];
  salaryChange: { offset: number; amount: number } | null;
  seed: number;
}

function buildModel(input: ForecastInput): Model {
  const startDate = startOfDay(input.startDate ?? new Date());
  const history = input.transactions.filter((t) => startOfDay(t.date) <= startDate);
  const obligations = [...input.obligations];
  const oneOffs: { offset: number; amount: number }[] = [];
  let monthlyIncome = input.monthlyIncome;
  let startBalance = input.balance;
  let salaryChange: Model["salaryChange"] = null;

  if (input.scenario) {
    const s = input.scenario;
    const offset = Math.max(1, s.effectiveDay ?? 1);
    if (s.kind === "purchase" && s.amount) {
      oneOffs.push({ offset, amount: -Math.abs(s.amount) });
    }
    if (s.kind === "loan" && s.amount) {
      const months = Math.max(3, s.months ?? 12);
      const rate = (s.interestRate ?? 12) / 100 / 12;
      const emi =
        rate > 0
          ? (s.amount * rate * (1 + rate) ** months) / ((1 + rate) ** months - 1)
          : s.amount / months;
      oneOffs.push({ offset: 0, amount: Math.abs(s.amount) });
      obligations.push({
        name: "New loan EMI",
        type: "EMI",
        amount: Math.round(emi),
        dueDay: new Date(startDate.getTime() + offset * DAY_MS).getDate(),
      });
    }
    if (s.kind === "prepay" && s.amount) {
      oneOffs.push({ offset, amount: -Math.abs(s.amount) });
      // Interest saved reduces the EMI load; approximate as 3% of the prepaid amount per month.
      const saving = Math.min(Math.abs(s.amount) * 0.03, obligations.reduce((sum, o) => sum + (o.type === "EMI" || o.type === "LOAN" ? o.amount : 0), 0) * 0.4);
      if (saving > 0) {
        const emiIdx = obligations.findIndex((o) => o.type === "EMI" || o.type === "LOAN");
        if (emiIdx >= 0) {
          obligations[emiIdx] = { ...obligations[emiIdx], amount: Math.max(0, obligations[emiIdx].amount - saving) };
        }
      }
    }
    if (s.kind === "salary" && s.newSalary) {
      salaryChange = { offset, amount: s.newSalary };
    }
  }

  const spendByDow = weekdayStats(
    history,
    startDate,
    120,
    (t) => t.type === "DEBIT" && !FIXED_CATEGORIES.has(t.category) && !t.isAnomaly,
  );
  const incomeByDow = weekdayStats(
    history,
    startDate,
    120,
    (t) => t.type === "CREDIT" && t.category !== "Transfer",
  );

  const credits = history.filter((t) => t.type === "CREDIT" && t.category !== "Transfer");
  const days = 120;
  const eventRate = input.persona === "IRREGULAR" ? Math.min(0.5, (credits.length / days) * 1.1) : 0;
  const eventMean = credits.length ? mean(credits.map((c) => c.amount)) : Math.max(2000, monthlyIncome / 2);
  const eventSd = credits.length > 1 ? Math.max(500, sd(credits.map((c) => c.amount))) : eventMean * 0.5;

  const salaryCredits = credits.filter((c) => c.category === "Income");
  const otherCreditsPerMonth =
    input.persona === "SALARIED" && salaryCredits.length > 3
      ? Math.max(0, (credits.length - salaryCredits.length) * (mean(credits.filter((c) => c.category !== "Income").map((c) => c.amount)) || 0) / 4)
      : 0;

  if (monthlyIncome <= 0) {
    monthlyIncome = credits.length ? mean(credits.map((c) => c.amount)) * (input.persona === "SALARIED" ? 1 : 3) : 0;
  }

  return {
    persona: input.persona,
    startBalance,
    startDate,
    horizon: input.horizon,
    monthlyIncome,
    incomeDay: input.incomeDay || 1,
    obligations,
    spendByDow,
    incomeByDow,
    eventRate,
    eventMean,
    eventSd,
    otherCreditsPerMonth,
    oneOffs,
    salaryChange,
    seed: input.seed ?? 20261114,
  };
}

interface SimOutput {
  balances: number[][];
  probNegative: number[];
  firstNegative: number[];
}

function simulate(model: Model): SimOutput {
  const rng = mulberry32(model.seed);
  const balances: number[][] = Array.from({ length: model.horizon }, () => new Array(SIMULATIONS).fill(0));
  const firstNegative: number[] = new Array(SIMULATIONS).fill(-1);

  for (let s = 0; s < SIMULATIONS; s++) {
    let balance = model.startBalance;
    // Parameter uncertainty: each path draws its own spending and income level, so the
    // band reflects model risk and not only day-to-day noise.
    const spendFactor = Math.max(0.5, 1 + gauss(rng) * 0.22);
    const incomeFactor = Math.max(0.7, 1 + gauss(rng) * 0.06);
    for (let d = 0; d < model.horizon; d++) {
      const date = addDays(model.startDate, d + 1);
      const dow = date.getDay();

      for (const one of model.oneOffs) {
        if (one.offset === d + 1) balance += one.amount;
      }
      balance -= obligationDueOn(date, model.obligations);

      const income = model.salaryChange && model.salaryChange.offset === d + 1 ? model.salaryChange.amount : model.monthlyIncome;
      if (model.persona === "SALARIED" && salaryDueOn(date, model.incomeDay) && income > 0) {
        balance += income * incomeFactor;
      }
      if (model.persona === "SALARIED" && model.otherCreditsPerMonth > 0) {
        balance += model.otherCreditsPerMonth / 30;
      }
      if (model.persona === "IRREGULAR" && rng() < model.eventRate) {
        const draw = model.eventMean + gauss(rng) * model.eventSd;
        balance += Math.max(500, draw);
      }
      if (model.persona === "BUSINESS") {
        const stat = model.incomeByDow[dow];
        balance += Math.max(0, stat.mean + gauss(rng) * stat.sd * 0.6);
      }

      const spend = model.spendByDow[dow];
      const draw = spend.mean + gauss(rng) * spend.sd;
      balance -= Math.max(0, draw) * spendFactor;

      if (rng() < 0.018) balance -= 600 + rng() * 3200;

      balances[d][s] = balance;
      if (balance < 0 && firstNegative[s] === -1) firstNegative[s] = d;
    }
  }

  const probNegative = balances.map((day) => day.filter((b) => b < 0).length / SIMULATIONS);
  return { balances, probNegative, firstNegative };
}

export function buildForecast(input: ForecastInput): ForecastResult {
  const model = buildModel(input);
  const sim = simulate(model);

  const points: ForecastPoint[] = [];
  let prev = model.startBalance;
  for (let d = 0; d < model.horizon; d++) {
    const sorted = [...sim.balances[d]].sort((a, b) => a - b);
    const p10 = Math.round(percentile(sorted, 0.1));
    const p50 = Math.round(percentile(sorted, 0.5));
    const p90 = Math.round(percentile(sorted, 0.9));
    points.push({
      date: iso(addDays(model.startDate, d + 1)),
      p10,
      p50,
      p90,
      expectedNet: Math.round(p50 - prev),
    });
    prev = p50;
  }

  const probNegative = sim.probNegative;
  const cumulativeShortage = Array.from({ length: model.horizon }, (_, d) =>
    sim.firstNegative.filter((first) => first >= 0 && first <= d).length / SIMULATIONS,
  );
  let shortageIdx = probNegative.findIndex((p) => p >= 0.5);
  if (shortageIdx === -1) shortageIdx = points.findIndex((p) => p.p10 < 0);
  const emptyIdx = points.findIndex((p) => p.p50 <= 0);

  const negatives = sim.firstNegative.filter((d) => d >= 0);
  const medianFirstNegative = negatives.length
    ? negatives.sort((a, b) => a - b)[Math.floor(negatives.length / 2)]
    : -1;
  const shortageProbability = negatives.length / SIMULATIONS;
  const shortageDate =
    medianFirstNegative >= 0
      ? iso(addDays(model.startDate, medianFirstNegative + 1))
      : shortageIdx >= 0
        ? points[shortageIdx].date
        : null;

  const monthlyFixed = model.obligations.reduce((s, o) => s + o.amount, 0);
  const dailySpendMean = mean(model.spendByDow.map((d) => d.mean));
  const incomeModel =
    model.persona === "SALARIED"
      ? `Fixed salary of ${Math.round(model.monthlyIncome)} credited on day ${model.incomeDay}`
      : model.persona === "IRREGULAR"
        ? `Lumpy income: about ${(model.eventRate * 30).toFixed(1)} payments a month, average ${Math.round(model.eventMean)}`
        : `Daily sales modelled from your weekday sales pattern`;

  const drivers = [
    { label: "Opening balance", value: `₹${Math.round(model.startBalance).toLocaleString("en-IN")}` },
    { label: "Average daily spend", value: `₹${Math.round(dailySpendMean).toLocaleString("en-IN")} (last 120 days)` },
    { label: "Fixed monthly obligations", value: `₹${Math.round(monthlyFixed).toLocaleString("en-IN")} across ${model.obligations.length} bills` },
    { label: "Income pattern", value: incomeModel },
    { label: "Simulations", value: "1,000 Monte Carlo paths, 10th–90th percentile" },
  ];

  return {
    points,
    probByDay: probNegative.map((p) => Number(p.toFixed(4))),
    cumulativeShortage: cumulativeShortage.map((p) => Number(p.toFixed(4))),
    shortageDate,
    shortageProbability,
    moneyEmptyDate: emptyIdx >= 0 ? points[emptyIdx].date : null,
    minP50: points.length ? Math.min(...points.map((p) => p.p50)) : model.startBalance,
    endP50: points.length ? points[points.length - 1].p50 : model.startBalance,
    endP10: points.length ? points[points.length - 1].p10 : model.startBalance,
    endP90: points.length ? points[points.length - 1].p90 : model.startBalance,
    dailySpendMean: Math.round(dailySpendMean),
    monthlyFixed,
    incomeModel,
    engine: "typescript-montecarlo",
    drivers,
  };
}

/** Hold out the last `testDays`, forecast that window from history only, and score it. */
export function backtestForecast(input: ForecastInput, testDays = 30): BacktestResult {
  const today = startOfDay(input.startDate ?? new Date());
  const cutoff = addDays(today, -testDays);
  const before = input.transactions.filter((t) => startOfDay(t.date) <= cutoff);
  const afterAll = input.transactions.filter((t) => startOfDay(t.date) > cutoff && startOfDay(t.date) <= today);
  // One-off anomalies are not forecastable; score the underlying balance path instead.
  const after = afterAll.filter((t) => !t.isAnomaly);
  const netAfter = after.reduce((s, t) => s + (t.type === "CREDIT" ? t.amount : -t.amount), 0);
  const balanceAtCutoff = input.balance - netAfter;

  const forecast = buildForecast({
    ...input,
    transactions: before,
    balance: balanceAtCutoff,
    startDate: cutoff,
    horizon: testDays,
    scenario: null,
    seed: 424242,
  });
  if (process.env.DEBUG_FORECAST === "1") {
    console.log("[backtest]", {
      balanceAtCutoff,
      dailySpendMean: forecast.dailySpendMean,
      monthlyFixed: forecast.monthlyFixed,
      cutoff: iso(cutoff),
      before: before.length,
      after: after.length,
    });
  }

  const actualByDay = new Map<string, number>();
  for (const t of after) {
    const key = iso(startOfDay(t.date));
    actualByDay.set(key, (actualByDay.get(key) ?? 0) + (t.type === "CREDIT" ? t.amount : -t.amount));
  }

  let balance = balanceAtCutoff;
  const points: BacktestResult["points"] = [];
  let absErr = 0;
  let pctErr = 0;
  let pctCount = 0;
  let hits = 0;
  let prevPred = forecast.points[0] ? forecast.points[0].p50 - forecast.points[0].expectedNet : balanceAtCutoff;

  for (const point of forecast.points) {
    const actualNet = actualByDay.get(point.date) ?? 0;
    balance += actualNet;
    const predictedNet = point.p50 - prevPred;
    prevPred = point.p50;
    absErr += Math.abs(balance - point.p50);
    pctErr += Math.abs(balance - point.p50) / Math.max(5000, Math.abs(balance), input.monthlyIncome * 0.25);
    pctCount++;
    if (balance >= point.p10 && balance <= point.p90) hits++;
    points.push({ date: point.date, actual: Math.round(balance), p10: point.p10, p50: point.p50, p90: point.p90 });
  }

  return {
    mape: pctCount ? (pctErr / pctCount) * 100 : 0,
    mae: points.length ? absErr / points.length : 0,
    hitRate: points.length ? (hits / points.length) * 100 : 0,
    points,
    trainDays: Math.max(0, Math.round((cutoff.getTime() - startOfDay(input.transactions[0]?.date ?? cutoff).getTime()) / DAY_MS)),
    testDays,
  };
}

export function describeForecast(result: ForecastResult, horizon: number, lang = "en"): string[] {
  const lines: string[] = [];
  if (result.shortageDate) {
    lines.push(
      `Across 1,000 simulated paths, your balance is most likely to reach zero around ${result.shortageDate} (${Math.round(result.shortageProbability * 100)}% of runs).`,
    );
  } else {
    lines.push(`In ${Math.round(result.shortageProbability * 100)}% of 1,000 simulated runs your balance stays above zero for the next ${horizon} days.`);
  }
  lines.push(
    `By day ${horizon} we expect ₹${result.endP50.toLocaleString("en-IN")} (expected), with an 80% confidence range of ₹${result.endP10.toLocaleString("en-IN")} to ₹${result.endP90.toLocaleString("en-IN")}.`,
  );
  lines.push(
    `The range comes from day-to-day spending variability around an average of ₹${result.dailySpendMean.toLocaleString("en-IN")} per day plus ₹${result.monthlyFixed.toLocaleString("en-IN")} of fixed monthly bills.`,
  );
  return lines;
}
