import type { HealthResult } from "@/lib/types";
import { clamp } from "@/lib/money";

interface HealthInput {
  monthlyIncome: number;
  monthlyExpenses: number;
  balance: number;
  monthlyObligations: number;
  anomalyCount: number;
  budgetAdherence: number;
  runwayDays: number;
  hasForecastShortage: boolean;
}

export function computeHealth(input: HealthInput): HealthResult {
  const income = Math.max(1, input.monthlyIncome);
  const savingsRate = (income - input.monthlyExpenses) / income;
  const savingsScore = clamp(savingsRate / 0.3, 0, 1) * 100;

  const runwayScore = clamp(input.runwayDays / 90, 0, 1) * 100;
  const obligationRatio = input.monthlyObligations / income;
  const obligationScore = clamp((0.55 - obligationRatio) / 0.35, 0, 1) * 100;
  const anomalyScore = clamp(1 - input.anomalyCount / 6, 0, 1) * 100;
  const budgetScore = clamp(input.budgetAdherence, 0, 1) * 100;

  const parts = [
    { key: "savings", label: "Savings rate", score: Math.round(savingsScore), weight: 0.3, detail: `${Math.round(savingsRate * 100)}% of income left after expenses` },
    { key: "runway", label: "Runway", score: Math.round(runwayScore), weight: 0.25, detail: `${input.runwayDays} days of expenses covered by your balance` },
    { key: "obligations", label: "Obligation load", score: Math.round(obligationScore), weight: 0.2, detail: `${Math.round(obligationRatio * 100)}% of income goes to fixed bills` },
    { key: "anomalies", label: "Anomalies", score: Math.round(anomalyScore), weight: 0.15, detail: `${input.anomalyCount} unusual payments in the last 90 days` },
    { key: "budget", label: "Budget adherence", score: Math.round(budgetScore), weight: 0.1, detail: `${Math.round(input.budgetAdherence * 100)}% of categories are within their limit` },
  ];

  let score = Math.round(parts.reduce((s, p) => s + p.score * p.weight, 0));
  if (input.hasForecastShortage) score = Math.min(score, 54);
  score = Math.round(clamp(score, 1, 100));

  const grade: HealthResult["grade"] = score >= 80 ? "Excellent" : score >= 65 ? "Good" : score >= 45 ? "Fair" : "At risk";
  return { score, grade, parts };
}
