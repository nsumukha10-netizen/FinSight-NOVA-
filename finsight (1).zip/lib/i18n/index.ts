import en from "@/lib/i18n/messages/en.json";
import hi from "@/lib/i18n/messages/hi.json";
import kn from "@/lib/i18n/messages/kn.json";
import ta from "@/lib/i18n/messages/ta.json";
import te from "@/lib/i18n/messages/te.json";
import ml from "@/lib/i18n/messages/ml.json";
import mr from "@/lib/i18n/messages/mr.json";
import bn from "@/lib/i18n/messages/bn.json";
import gu from "@/lib/i18n/messages/gu.json";
import pa from "@/lib/i18n/messages/pa.json";
import or from "@/lib/i18n/messages/or.json";

export type LangCode = "en" | "hi" | "kn" | "ta" | "te" | "ml" | "mr" | "bn" | "gu" | "pa" | "or";

export const LANGUAGES: { code: LangCode; label: string; native: string; bcp47: string; sarvam: string }[] = [
  { code: "en", label: "English", native: "English", bcp47: "en-IN", sarvam: "en-IN" },
  { code: "hi", label: "Hindi", native: "हिन्दी", bcp47: "hi-IN", sarvam: "hi-IN" },
  { code: "kn", label: "Kannada", native: "ಕನ್ನಡ", bcp47: "kn-IN", sarvam: "kn-IN" },
  { code: "ta", label: "Tamil", native: "தமிழ்", bcp47: "ta-IN", sarvam: "ta-IN" },
  { code: "te", label: "Telugu", native: "తెలుగు", bcp47: "te-IN", sarvam: "te-IN" },
  { code: "ml", label: "Malayalam", native: "മലയാളം", bcp47: "ml-IN", sarvam: "ml-IN" },
  { code: "mr", label: "Marathi", native: "मराठी", bcp47: "mr-IN", sarvam: "mr-IN" },
  { code: "bn", label: "Bengali", native: "বাংলা", bcp47: "bn-IN", sarvam: "bn-IN" },
  { code: "gu", label: "Gujarati", native: "ગુજરાતી", bcp47: "gu-IN", sarvam: "gu-IN" },
  { code: "pa", label: "Punjabi", native: "ਪੰਜਾਬੀ", bcp47: "pa-IN", sarvam: "pa-IN" },
  { code: "or", label: "Odia", native: "ଓଡ଼ିଆ", bcp47: "or-IN", sarvam: "od-IN" },
];

export const DICTIONARIES: Record<LangCode, Record<string, string>> = {
  en,
  hi,
  kn,
  ta,
  te,
  ml,
  mr,
  bn,
  gu,
  pa,
  or,
};

export function isLang(value: string | undefined | null): value is LangCode {
  return !!value && value in DICTIONARIES;
}

export function getDictionary(lang: string | undefined | null): Record<string, string> {
  return DICTIONARIES[isLang(lang) ? lang : "en"] ?? DICTIONARIES.en;
}

export type Translator = (key: string, vars?: Record<string, string | number>) => string;

export function makeT(dict: Record<string, string>): Translator {
  return (key, vars) => {
    let value = dict[key] ?? DICTIONARIES.en[key] ?? key;
    if (vars) {
      for (const [k, v] of Object.entries(vars)) value = value.replaceAll(`{${k}}`, String(v));
    }
    return value;
  };
}

export function languageMeta(code: string) {
  return LANGUAGES.find((l) => l.code === code) ?? LANGUAGES[0];
}
