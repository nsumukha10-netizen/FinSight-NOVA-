import { CATEGORIES, categoryMeta } from "@/lib/categories";
import type { BudgetRow, ForecastObligation, ForecastTxn, PersonaKey } from "@/lib/types";

interface LimitInput {
  persona: PersonaKey;
  monthlyIncome: number;
  obligations: ForecastObligation[];
  transactions: ForecastTxn[];
  spendByCategory: Record<string, number>;
  baselineByCategory?: Record<string, number>;
  shortageWithin30: boolean;
}

const FIXED_CATEGORIES = new Set(["Rent", "EMI & Loans", "Investments"]);

const DEFAULT_WEIGHTS: Record<string, number> = {
  Groceries: 0.3,
  "Food Delivery": 0.12,
  "Dining & Cafes": 0.08,
  Shopping: 0.12,
  Subscriptions: 0.05,
  Transport: 0.1,
  Utilities: 0.1,
  Health: 0.06,
  Entertainment: 0.05,
  "Cash & ATM": 0.03,
};

function obligationsByCategory(obligations: ForecastObligation[]): Record<string, number> {
  const map: Record<string, number> = {};
  for (const ob of obligations) {
    const cat =
      ob.type === "RENT"
        ? "Rent"
        : ob.type === "EMI" || ob.type === "LOAN"
          ? "EMI & Loans"
          : ob.type === "SIP"
            ? "Investments"
            : ob.type === "SUBSCRIPTION"
              ? "Subscriptions"
              : ob.type === "GROCERY"
                ? "Groceries"
                : "Other";
    map[cat] = (map[cat] ?? 0) + ob.amount;
  }
  return map;
}

/**
 * 50/30/20 baseline, anchored to the three-month spend baseline so limits are achievable,
 * reallocated against the real obligation load, then trimmed when a shortage is forecast
 * inside 30 days. Every row carries a plain-language reason.
 */
export function buildLimits(input: LimitInput): BudgetRow[] {
  const income = Math.max(1, input.monthlyIncome || 1);
  const obligationMap = obligationsByCategory(input.obligations);
  const fixedTotal = Object.values(obligationMap).reduce((s, v) => s + v, 0);
  const needsBase = income * 0.5;
  const wantsBase = income * 0.3;

  const needsExcess = Math.max(0, fixedTotal - needsBase);
  const wantsPool = Math.max(income * 0.08, wantsBase - needsExcess);
  const variableNeedsPool = Math.max(0, needsBase - fixedTotal);
  const haircut = input.shortageWithin30 ? 0.78 : 1;

  const baseline = input.baselineByCategory ?? {};
  const recentTotalVariable = Object.entries(baseline)
    .filter(([cat]) => !FIXED_CATEGORIES.has(cat))
    .reduce((s, [, v]) => s + v, 0);

  const rows: BudgetRow[] = [];
  for (const meta of CATEGORIES) {
    if (["Income", "Transfer"].includes(meta.key)) continue;
    const fixed = obligationMap[meta.key] ?? 0;
    const base = baseline[meta.key] ?? 0;
    const spent = input.spendByCategory[meta.key] ?? 0;
    const share = recentTotalVariable > 0 ? base / recentTotalVariable : DEFAULT_WEIGHTS[meta.key] ?? 0.05;

    // Do not invent a budget line for a category the user has never used.
    if (fixed <= 0 && base < 200 && spent <= 0) continue;

    let limit: number;
    if (FIXED_CATEGORIES.has(meta.key) || categoryMeta(meta.key).fixed) {
      limit = Math.max(fixed, base * 0.95);
    } else if (meta.group === "Needs") {
      limit = Math.max(fixed, income * 0.02, variableNeedsPool * Math.max(share, 0.05), base * 0.85);
    } else if (meta.group === "Wants") {
      limit = Math.max(fixed, income * 0.012, wantsPool * Math.max(share, 0.08), base * 0.8);
    } else if (meta.group === "Savings") {
      limit = Math.max(fixed, income * 0.05, input.persona === "SALARIED" ? income * 0.1 : income * 0.04);
    } else {
      limit = Math.max(income * 0.01, base * 1.05);
    }

    if (meta.discretionary) limit *= haircut;
    limit = Math.round(limit / 10) * 10;
    if (limit <= 0) continue;

    const reasons: string[] = [];
    if (fixed > 0) reasons.push(`₹${Math.round(fixed).toLocaleString("en-IN")} of fixed commitments is locked into this category`);
    if (base > 0) reasons.push(`your three-month average is ₹${Math.round(base).toLocaleString("en-IN")} a month`);
    if (meta.group === "Wants") reasons.push("kept inside the 30% wants share of your income");
    if (meta.discretionary && input.shortageWithin30) reasons.push("trimmed 22% because the forecast shows a cash crunch within 30 days");
    if (input.persona === "IRREGULAR" && meta.group === "Wants") reasons.push("tighter because your income arrives in uneven lumps");
    if (input.persona === "BUSINESS" && meta.key === "Business Supplies") reasons.push("protects stock purchases so sales do not stall");
    if (!reasons.length) reasons.push("sized from your average monthly spend in this category");

    rows.push({
      category: meta.key,
      group: meta.group === "Savings" ? "Savings" : meta.group === "Needs" ? "Needs" : "Wants",
      monthlyLimit: limit,
      spent: Math.round(spent),
      reason: reasons.join("; ") + ".",
      discretionary: meta.discretionary,
    });
  }
  return rows.sort((a, b) => b.monthlyLimit - a.monthlyLimit);
}
