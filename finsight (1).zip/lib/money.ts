const LOCALES: Record<string, string> = {
  en: "en-IN",
  hi: "hi-IN",
  kn: "kn-IN",
  ta: "ta-IN",
  te: "te-IN",
  ml: "ml-IN",
  mr: "mr-IN",
  bn: "bn-IN",
  gu: "gu-IN",
  pa: "pa-IN",
  or: "or-IN",
};

export function localeFor(lang: string): string {
  return LOCALES[lang] ?? "en-IN";
}

export function inr(amount: number, lang = "en", withDecimals = false): string {
  const value = Number.isFinite(amount) ? amount : 0;
  return new Intl.NumberFormat(localeFor(lang), {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: withDecimals ? 2 : 0,
    minimumFractionDigits: 0,
  }).format(value);
}

export function inrCompact(amount: number, lang = "en"): string {
  const abs = Math.abs(amount);
  if (abs >= 10_000_000) return `₹${(amount / 10_000_000).toFixed(2)}Cr`;
  if (abs >= 100_000) return `₹${(amount / 100_000).toFixed(2)}L`;
  if (abs >= 1_000) return `₹${(amount / 1_000).toFixed(1)}k`;
  return inr(amount, lang);
}

export function pct(value: number, digits = 0): string {
  return `${(value * 100).toFixed(digits)}%`;
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function round(n: number, digits = 0): number {
  const f = 10 ** digits;
  return Math.round(n * f) / f;
}
