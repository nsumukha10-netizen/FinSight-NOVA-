import { prisma } from "@/lib/prisma";
import { categoryMeta, normalizePayee } from "@/lib/categories";
import { categorizeByRules } from "@/lib/categorize";
import { scoreAnomaly } from "@/lib/anomaly";
import { getFinanceSnapshot, invalidateFinance } from "@/lib/finance";
import { aiChat } from "@/lib/ai";
import { LANGUAGE_NAME } from "@/lib/ai";
import type { User } from "@prisma/client";

export interface PaymentRequest {
  payee: string;
  amount: number;
  category?: string;
  note?: string;
  date?: string;
}

export interface PaymentReview {
  decision: "commit" | "anomaly" | "impulse";
  payee: string;
  amount: number;
  category: string;
  confidence: number;
  source: string;
  balanceAfter: number;
  anomaly: { score: number; isAnomaly: boolean; reason: string | null; signals: string[] };
  impulse: {
    spent: number;
    limit: number;
    pct: number;
    healthScore: number;
    grade: string;
    shortage30: number;
    explanation: string;
  } | null;
  explanation: string;
}

async function learnedRules(userId: string) {
  const rules = await prisma.merchantRule.findMany({ where: { OR: [{ userId }, { userId: null }] } });
  return Object.fromEntries(rules.map((r) => [r.payeeKey, r.category]));
}

async function explain(facts: string, language: string, offline: string, guard: string): Promise<string> {
  const result = await aiChat(
    [
      {
        role: "system",
        content: `You are FinSight's ${guard}. Write ONE short sentence (maximum 32 words) explaining the risk using the exact numbers. Reply only in ${LANGUAGE_NAME[language] ?? "English"}. No greeting, no advice disclaimer.`,
      },
      { role: "user", content: facts },
    ],
    { maxTokens: 160, offline },
  );
  return result.text || offline;
}

export async function previewPayment(user: User, request: PaymentRequest): Promise<PaymentReview> {
  const snapshot = await getFinanceSnapshot(user.id);
  const amount = Math.abs(request.amount);
  const learned = await learnedRules(user.id);
  const categorized = categorizeByRules(request.payee, request.note ?? "", learned);
  const category = request.category && categoryMeta(request.category) ? request.category : categorized.category;

  const history = snapshot.transactions.slice(-260).map((t) => ({
    date: new Date(t.date),
    amount: t.amount,
    type: t.type,
    payee: t.payee,
    category: t.category,
  }));
  const anomaly = scoreAnomaly({ amount, payee: request.payee, category, date: new Date(request.date ?? Date.now()) }, history);

  const limitRow = snapshot.limits.find((l) => l.category === category);
  const spent = snapshot.spendByCategory[category] ?? 0;
  const limit = limitRow?.monthlyLimit ?? 0;
  const pct = limit > 0 ? spent / limit : 0;
  const shortage30 = snapshot.forecast.cumulativeShortage[29] ?? 0;
  const discretionary = categoryMeta(category).discretionary;
  const impulseHit = discretionary && (pct >= 0.8 || shortage30 >= 0.5);

  const balanceAfter = Math.round(snapshot.balance - amount);

  if (anomaly.isAnomaly) {
    const reasonText =
      anomaly.reason === "duplicate"
        ? "A matching payment was recorded minutes ago."
        : anomaly.reason === "unknown_payee"
          ? "This is the first payment to this payee and the amount is high."
          : anomaly.reason === "spike"
            ? `This is more than 3x your usual spend in ${category}.`
            : "This sits far outside your normal pattern.";
    const explanation = await explain(
      `Payment of ₹${amount} to ${request.payee} in ${category}. Signals: ${anomaly.signals.join(", ")}. Balance now ₹${snapshot.balance}, balance after ₹${balanceAfter}.`,
      user.language,
      `${reasonText} Your balance would be ₹${balanceAfter.toLocaleString("en-IN")} after this payment.`,
      "fraud and anomaly analyst",
    );
    return {
      decision: "anomaly",
      payee: request.payee,
      amount,
      category,
      confidence: categorized.confidence,
      source: categorized.source,
      balanceAfter,
      anomaly,
      impulse: null,
      explanation,
    };
  }

  if (impulseHit) {
    const facts = `Payment of ₹${amount} to ${request.payee} (${category}). Spent ₹${Math.round(spent)} of a ₹${Math.round(limit)} monthly limit (${Math.round(pct * 100)}%). Health score ${snapshot.health.score}/100. Probability of hitting zero within 30 days: ${Math.round(shortage30 * 100)}%.`;
    const explanation = await explain(
      facts,
      user.language,
      `${Math.round(pct * 100)}% of your ${category} budget is already used, and ${Math.round(shortage30 * 100)}% of simulations run short within 30 days.`,
      "spending checkpoint",
    );
    return {
      decision: "impulse",
      payee: request.payee,
      amount,
      category,
      confidence: categorized.confidence,
      source: categorized.source,
      balanceAfter,
      anomaly,
      impulse: {
        spent: Math.round(spent),
        limit: Math.round(limit),
        pct,
        healthScore: snapshot.health.score,
        grade: snapshot.health.grade,
        shortage30,
        explanation,
      },
      explanation,
    };
  }

  return {
    decision: "commit",
    payee: request.payee,
    amount,
    category,
    confidence: categorized.confidence,
    source: categorized.source,
    balanceAfter,
    anomaly,
    impulse: null,
    explanation: "",
  };
}

export async function commitPayment(user: User, request: PaymentRequest, meta?: { reviewed?: boolean; reviewNote?: string }) {
  const review = await previewPayment(user, request);
  const account = await prisma.bankAccount.findFirst({ where: { userId: user.id }, orderBy: { linkedAt: "desc" } });
  if (!account) throw new Error("no_bank_account");

  const date = request.date ? new Date(request.date) : new Date();
  const balanceAfter = Math.round(account.balance - review.amount);

  const transaction = await prisma.transaction.create({
    data: {
      userId: user.id,
      date,
      amount: review.amount,
      type: "DEBIT",
      payee: request.payee,
      rawDescription: `UPI/${request.payee.toUpperCase().replace(/\s+/g, "")}/${Math.floor(100000 + Math.random() * 899999)}`,
      category: review.category,
      isAnomaly: review.anomaly.isAnomaly,
      anomalyScore: review.anomaly.score,
      anomalyReason: review.anomaly.reason,
      note: request.note ?? null,
      balanceAfter,
    },
  });

  await prisma.bankAccount.update({ where: { id: account.id }, data: { balance: balanceAfter } });

  if (review.decision !== "commit" && meta?.reviewed) {
    await prisma.alert.create({
      data: {
        userId: user.id,
        type: review.decision === "anomaly" ? "anomaly" : "impulse",
        severity: review.decision === "anomaly" ? "critical" : "caution",
        message:
          review.decision === "anomaly"
            ? `₹${review.amount.toLocaleString("en-IN")} to ${review.payee} confirmed by you`
            : `₹${review.amount.toLocaleString("en-IN")} to ${review.payee} after a spending checkpoint`,
        explanation: meta.reviewNote || review.explanation,
        resolved: true,
      },
    });
  }

  const key = normalizePayee(request.payee);
  if (key && review.category !== "Other") {
    await prisma.merchantRule.upsert({
      where: { userId_payeeKey: { userId: user.id, payeeKey: key } },
      create: { userId: user.id, payeeKey: key, category: review.category, source: "USER", confidence: 0.95 },
      update: { category: review.category, source: "USER", confidence: 0.95 },
    });
  }

  invalidateFinance(user.id);
  return { transaction, review, balanceAfter };
}

export async function addTransaction(
  user: User,
  input: { amount: number; type: "DEBIT" | "CREDIT"; payee: string; category: string; note?: string; date?: string },
) {
  const account = await prisma.bankAccount.findFirst({ where: { userId: user.id }, orderBy: { linkedAt: "desc" } });
  if (!account) throw new Error("no_bank_account");
  const amount = Math.abs(input.amount);
  const balanceAfter = Math.round(account.balance + (input.type === "CREDIT" ? amount : -amount));
  const transaction = await prisma.transaction.create({
    data: {
      userId: user.id,
      date: input.date ? new Date(input.date) : new Date(),
      amount,
      type: input.type,
      payee: input.payee,
      rawDescription: `MANUAL/${input.payee.toUpperCase().replace(/\s+/g, "")}`,
      category: input.category,
      note: input.note ?? null,
      balanceAfter,
    },
  });
  await prisma.bankAccount.update({ where: { id: account.id }, data: { balance: balanceAfter } });
  invalidateFinance(user.id);
  return transaction;
}
