import { PrismaClient } from "@prisma/client";

/**
 * The managed MySQL endpoint hands out `?ssl={"rejectUnauthorized":true}` which the
 * Prisma MySQL connector does not read. Translate it to Prisma's `sslaccept=strict`.
 */
export function normalizeDatabaseUrl(url: string | undefined): string | undefined {
  if (!url) return url;
  try {
    const parsed = new URL(url);
    if (parsed.searchParams.has("ssl")) {
      parsed.searchParams.delete("ssl");
      parsed.searchParams.set("sslaccept", "strict");
    }
    return parsed.toString();
  } catch {
    return url;
  }
}

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: normalizeDatabaseUrl(process.env.DATABASE_URL),
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
