import { normalizePayee } from "@/lib/categories";

export interface RecurringTxn {
  date: Date;
  amount: number;
  type: "DEBIT" | "CREDIT";
  payee: string;
  category: string;
}

export interface RecurringGroup {
  key: string;
  payee: string;
  category: string;
  cadence: "weekly" | "monthly" | "yearly";
  averageAmount: number;
  amountVariance: number;
  occurrences: number;
  lastDate: Date;
  nextDue: Date;
  confidence: number;
}

function median(nums: number[]): number {
  const sorted = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function cadenceFor(gaps: number[]): { cadence: RecurringGroup["cadence"]; target: number } | null {
  const med = median(gaps);
  if (med >= 5 && med <= 9) return { cadence: "weekly", target: 7 };
  if (med >= 25 && med <= 35) return { cadence: "monthly", target: 30 };
  if (med >= 350 && med <= 380) return { cadence: "yearly", target: 365 };
  return null;
}

/**
 * Group by normalized payee, require at least 3 occurrences, regular interval
 * (weekly / monthly / yearly) and amount variance under 10 percent.
 */
export function detectRecurring(transactions: RecurringTxn[]): RecurringGroup[] {
  const byPayee = new Map<string, RecurringTxn[]>();
  for (const tx of transactions) {
    if (tx.type !== "DEBIT") continue;
    const key = normalizePayee(tx.payee);
    if (!key) continue;
    const list = byPayee.get(key) ?? [];
    list.push(tx);
    byPayee.set(key, list);
  }

  const groups: RecurringGroup[] = [];
  for (const [key, list] of byPayee) {
    if (list.length < 3) continue;
    const sorted = [...list].sort((a, b) => a.date.getTime() - b.date.getTime());
    const gaps: number[] = [];
    for (let i = 1; i < sorted.length; i++) {
      gaps.push((sorted[i].date.getTime() - sorted[i - 1].date.getTime()) / 86_400_000);
    }
    const cadence = cadenceFor(gaps);
    if (!cadence) continue;
    const amounts = sorted.map((t) => t.amount);
    const avg = amounts.reduce((s, a) => s + a, 0) / amounts.length;
    const variance = avg > 0 ? Math.sqrt(amounts.reduce((s, a) => s + (a - avg) ** 2, 0) / amounts.length) / avg : 1;
    if (variance > 0.1) continue;
    const intervalConsistent = gaps.filter((g) => Math.abs(g - cadence.target) <= cadence.target * 0.25).length >= gaps.length * 0.6;
    if (!intervalConsistent) continue;
    const last = sorted[sorted.length - 1];
    const next = new Date(last.date.getTime() + cadence.target * 86_400_000);
    groups.push({
      key,
      payee: last.payee,
      category: last.category,
      cadence: cadence.cadence,
      averageAmount: Math.round(avg),
      amountVariance: variance,
      occurrences: sorted.length,
      lastDate: last.date,
      nextDue: next,
      confidence: Math.min(0.98, 0.55 + sorted.length * 0.05 + (0.1 - variance)),
    });
  }
  return groups.sort((a, b) => b.averageAmount - a.averageAmount);
}

/** Mark recurring transactions and assign a stable group id. */
export function applyRecurringFlags<T extends { payee: string; type: string; isRecurring: boolean; recurringGroupId: string | null }>(
  transactions: T[],
  groups: RecurringGroup[],
): T[] {
  const keys = new Set(groups.map((g) => g.key));
  return transactions.map((tx) => {
    if (tx.type !== "DEBIT") return tx;
    const key = normalizePayee(tx.payee);
    if (!keys.has(key)) return tx;
    return { ...tx, isRecurring: true, recurringGroupId: key };
  });
}
