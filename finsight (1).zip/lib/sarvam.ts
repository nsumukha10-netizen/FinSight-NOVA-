/**
 * Sarvam AI client. Server-side only — the subscription key never reaches the browser.
 * Every call fails soft so the product keeps working without a key or network.
 */
const BASE = "https://api.sarvam.ai";
const CHAT_MODEL = process.env.SARVAM_CHAT_MODEL ?? "sarvam-105b-conversations";

export const SARVAM_LANG: Record<string, string> = {
  en: "en-IN",
  hi: "hi-IN",
  kn: "kn-IN",
  ta: "ta-IN",
  te: "te-IN",
  ml: "ml-IN",
  mr: "mr-IN",
  bn: "bn-IN",
  gu: "gu-IN",
  pa: "pa-IN",
  or: "od-IN",
};

export function sarvamEnabled(): boolean {
  return Boolean(process.env.SARVAM_API_KEY);
}

async function call(path: string, init: RequestInit, timeoutMs = 25_000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(`${BASE}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        "api-subscription-key": process.env.SARVAM_API_KEY ?? "",
        ...(init.headers ?? {}),
      },
    });
  } finally {
    clearTimeout(timer);
  }
}

export interface SarvamMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export async function sarvamChat(
  messages: SarvamMessage[],
  opts: { temperature?: number; maxTokens?: number } = {},
): Promise<string> {
  const res = await call("/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: CHAT_MODEL,
      messages,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 900,
    }),
  });
  if (!res.ok) throw new Error(`sarvam_chat_${res.status}`);
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("sarvam_chat_empty");
  return text;
}

export async function sarvamStt(
  audio: Blob,
  language: string,
): Promise<{ transcript: string; languageCode: string }> {
  const form = new FormData();
  form.append("file", audio, "speech.webm");
  form.append("model", "saarika:v2.5");
  form.append("language_code", SARVAM_LANG[language] ?? "unknown");
  const res = await call("/speech-to-text", { method: "POST", body: form }, 40_000);
  if (!res.ok) throw new Error(`sarvam_stt_${res.status}`);
  const data = (await res.json()) as { transcript?: string; language_code?: string };
  if (!data.transcript) throw new Error("sarvam_stt_empty");
  return { transcript: data.transcript, languageCode: data.language_code ?? language };
}

export async function sarvamTts(text: string, language: string): Promise<string> {
  const res = await call("/text-to-speech", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      inputs: [text.slice(0, 1200)],
      target_language_code: SARVAM_LANG[language] ?? "en-IN",
      speaker: "meera",
      model: "bulbul:v2",
    }),
  });
  if (!res.ok) throw new Error(`sarvam_tts_${res.status}`);
  const data = (await res.json()) as { audios?: string[]; audio_base64?: string };
  const audio = data.audios?.[0] ?? data.audio_base64;
  if (!audio) throw new Error("sarvam_tts_empty");
  return audio;
}

export async function sarvamTranslate(text: string, from: string, to: string): Promise<string> {
  const res = await call("/translate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      input: text,
      source_language_code: from,
      target_language_code: to,
      model: "mayura:v1",
    }),
  });
  if (!res.ok) throw new Error(`sarvam_translate_${res.status}`);
  const data = (await res.json()) as { translated_text?: string };
  if (!data.translated_text) throw new Error("sarvam_translate_empty");
  return data.translated_text;
}
