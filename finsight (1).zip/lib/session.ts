import { SignJWT, jwtVerify } from "jose";

export const SESSION_COOKIE = "finsight_session";

function secretKey(): Uint8Array {
  const secret =
    process.env.JWT_SECRET ||
    process.env.MANUS_JWT_SECRET ||
    "finsight-local-development-secret-please-rotate";
  return new TextEncoder().encode(secret);
}

export async function signSession(userId: string): Promise<string> {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secretKey());
}

export async function verifySession(token: string | undefined | null): Promise<string | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secretKey());
    return typeof payload.sub === "string" ? payload.sub : null;
  } catch {
    return null;
  }
}

/** Cross-site iframe (Preview) needs SameSite=None; plain-HTTP localhost cannot store Secure cookies. */
export function cookieOptions(host: string | null) {
  const isLocal =
    !!host && (host.startsWith("localhost") || host.startsWith("127.0.0.1") || host.startsWith("0.0.0.0"));
  return {
    httpOnly: true,
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
    sameSite: (isLocal ? "lax" : "none") as "lax" | "none",
    secure: !isLocal,
  };
}
