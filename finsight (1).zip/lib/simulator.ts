import { buildForecast } from "@/lib/forecast";
import type { ForecastInput, ForecastResult, ScenarioInput } from "@/lib/types";

export interface ScenarioResult {
  scenario: ScenarioInput;
  before: ForecastResult;
  after: ForecastResult;
  verdict: "Safe" | "Risky" | "Not advisable";
  reasons: string[];
  deltas: { endBalance: number; minBalance: number; shortageDays: number };
}

function daysUntil(date: string | null): number {
  if (!date) return 999;
  return Math.max(0, Math.round((new Date(date).getTime() - Date.now()) / 86_400_000));
}

export function runScenario(input: ForecastInput, scenario: ScenarioInput): ScenarioResult {
  const before = buildForecast({ ...input, scenario: null });
  const after = buildForecast({ ...input, scenario });

  const reasons: string[] = [];
  const endDelta = after.endP50 - before.endP50;
  const minDelta = after.minP50 - before.minP50;
  const beforeShort = daysUntil(before.shortageDate);
  const afterShort = daysUntil(after.shortageDate);

  if (after.shortageProbability >= 0.5 || afterShort < 20) {
    reasons.push(
      `After this move, ${Math.round(after.shortageProbability * 100)}% of simulations run out of money${after.shortageDate ? ` around ${after.shortageDate}` : ""}.`,
    );
  } else if (after.shortageProbability > 0.2) {
    reasons.push(`The buffer gets thin: ${Math.round(after.shortageProbability * 100)}% of simulations dip below zero.`);
  } else {
    reasons.push(`Your balance stays positive in ${Math.round((1 - after.shortageProbability) * 100)}% of simulations.`);
  }
  if (endDelta < 0) reasons.push(`Expected balance in ${input.horizon} days drops by ₹${Math.abs(Math.round(endDelta)).toLocaleString("en-IN")}.`);
  if (minDelta < 0) reasons.push(`Your lowest expected balance falls by ₹${Math.abs(Math.round(minDelta)).toLocaleString("en-IN")}.`);
  if (afterShort < beforeShort) reasons.push(`The money-empty date moves ${beforeShort - afterShort} days earlier.`);

  let verdict: ScenarioResult["verdict"] = "Safe";
  if (after.shortageProbability >= 0.5 || after.minP50 < 0 || afterShort < 15) verdict = "Not advisable";
  else if (after.shortageProbability >= 0.25 || endDelta < -input.monthlyIncome * 0.25) verdict = "Risky";

  return {
    scenario,
    before,
    after,
    verdict,
    reasons,
    deltas: { endBalance: Math.round(endDelta), minBalance: Math.round(minDelta), shortageDays: beforeShort - afterShort },
  };
}
