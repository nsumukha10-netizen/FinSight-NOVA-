"use client";

import { languageMeta } from "@/lib/i18n";

let currentAudio: HTMLAudioElement | null = null;

export function stopSpeaking() {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio = null;
  }
  if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
}

/**
 * Prefer Sarvam audio from the server; fall back to the browser's own voices.
 * Returns the engine that actually spoke.
 */
export async function speak(text: string, lang: string): Promise<"sarvam" | "browser" | "none"> {
  if (!text.trim()) return "none";
  stopSpeaking();
  try {
    const res = await fetch("/api/voice/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, language: lang }),
    });
    if (res.ok) {
      const data = (await res.json()) as { audio?: string; mime?: string };
      if (data.audio) {
        const audio = new Audio(`data:${data.mime ?? "audio/wav"};base64,${data.audio}`);
        currentAudio = audio;
        await audio.play();
        return "sarvam";
      }
    }
  } catch {
    /* fall through to browser speech */
  }
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return "none";
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = languageMeta(lang).bcp47;
  utterance.rate = 0.98;
  const voices = window.speechSynthesis.getVoices();
  const match = voices.find((v) => v.lang === utterance.lang) ?? voices.find((v) => v.lang.startsWith(lang));
  if (match) utterance.voice = match;
  window.speechSynthesis.speak(utterance);
  return "browser";
}
