export type PersonaKey = "SALARIED" | "IRREGULAR" | "BUSINESS";

export type LangCode =
  | "en"
  | "hi"
  | "kn"
  | "ta"
  | "te"
  | "ml"
  | "mr"
  | "bn"
  | "gu"
  | "pa"
  | "or";

export interface ForecastTxn {
  date: Date;
  amount: number;
  type: "DEBIT" | "CREDIT";
  category: string;
  payee: string;
  isAnomaly?: boolean;
}

export interface ForecastObligation {
  name: string;
  type: string;
  amount: number;
  dueDay: number;
}

export interface ScenarioInput {
  kind: "purchase" | "loan" | "prepay" | "salary";
  amount?: number;
  months?: number;
  interestRate?: number;
  newSalary?: number;
  effectiveDay?: number;
}

export interface ForecastInput {
  persona: PersonaKey;
  balance: number;
  monthlyIncome: number;
  incomeDay: number;
  dailySales?: number | null;
  obligations: ForecastObligation[];
  transactions: ForecastTxn[];
  horizon: number;
  startDate?: Date;
  scenario?: ScenarioInput | null;
  seed?: number;
}

export interface ForecastPoint {
  date: string;
  p10: number;
  p50: number;
  p90: number;
  expectedNet: number;
}

export interface ForecastResult {
  points: ForecastPoint[];
  probByDay: number[];
  cumulativeShortage: number[];
  shortageDate: string | null;
  shortageProbability: number;
  moneyEmptyDate: string | null;
  minP50: number;
  endP50: number;
  endP10: number;
  endP90: number;
  dailySpendMean: number;
  monthlyFixed: number;
  incomeModel: string;
  engine: string;
  drivers: { label: string; value: string }[];
}

export interface BacktestResult {
  mape: number;
  mae: number;
  hitRate: number;
  points: { date: string; actual: number; p10: number; p50: number; p90: number }[];
  trainDays: number;
  testDays: number;
}

export interface BudgetRow {
  category: string;
  group: "Needs" | "Wants" | "Savings";
  monthlyLimit: number;
  spent: number;
  reason: string;
  discretionary: boolean;
}

export interface HealthPart {
  key: string;
  label: string;
  score: number;
  weight: number;
  detail: string;
}

export interface HealthResult {
  score: number;
  grade: "Excellent" | "Good" | "Fair" | "At risk";
  parts: HealthPart[];
}

export interface TransactionView {
  id: string;
  date: string;
  amount: number;
  type: "DEBIT" | "CREDIT";
  payee: string;
  rawDescription: string;
  category: string;
  isRecurring: boolean;
  isAnomaly: boolean;
  anomalyScore: number;
  anomalyReason: string | null;
  voiceLabel: string | null;
  note: string | null;
  balanceAfter: number;
}

export interface UserView {
  id: string;
  name: string;
  email: string;
  phone: string;
  persona: PersonaKey;
  language: LangCode;
  monthlyIncome: number;
  incomeDay: number;
  survivalTarget: number | null;
  theme: string;
  voiceEnabled: boolean;
  onboarded: boolean;
  isDemo: boolean;
}

export interface GeneratedTxn {
  date: Date;
  amount: number;
  type: "DEBIT" | "CREDIT";
  payee: string;
  rawDescription: string;
  category: string;
  subcategory: string | null;
  isRecurring: boolean;
  recurringGroupId: string | null;
  isAnomaly: boolean;
  anomalyScore: number;
  anomalyReason: string | null;
  balanceAfter: number;
}

export interface GeneratedHistory {
  transactions: GeneratedTxn[];
  openingBalance: number;
  closingBalance: number;
}
