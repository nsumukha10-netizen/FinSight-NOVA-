# FinSight — Implementation Plan

## Product
An AI financial operating system for Indian individuals and small businesses. It reads a simulated
passbook, forecasts cash flow with uncertainty, warns before money runs out, intercepts risky
payments, and explains every number in the user's own language (voice included).

## Stack decisions
- **Next.js 14 App Router + TypeScript** for the whole product (pages + API route handlers).
- **Prisma ORM** against the platform-managed **MySQL** database (`DATABASE_URL`). The brief asks
  for SQLite; a published container has a temporary filesystem, so the managed MySQL instance is
  the durable equivalent. The Prisma schema is provider-agnostic apart from the datasource line, and
  `README.md` documents the one-line switch back to SQLite for local offline runs.
- **Forecasting**: the shipped, always-on engine is the pure TypeScript moving-average + weekday
  seasonality + 1,000-path Monte Carlo engine (`lib/forecast.ts`), which satisfies the "single start
  command, works even if the Python service fails" requirement. A complete **FastAPI** service lives
  in `services/forecast/` with `/forecast` and `/backtest`; `lib/forecast-client.ts` calls it when
  `FORECAST_SERVICE_URL` is set and silently falls back to the TypeScript engine on any failure.
- **AI**: Sarvam AI (`sarvam-m`, `saarika:v2.5`, `bulbul:v2`, `mayura:v1`) is implemented server-side
  exactly as specified. Because `SARVAM_API_KEY` is not present, every AI path has a first-class
  fallback: the platform's built-in LLM for chat/explanations, platform Whisper for speech-to-text,
  and the browser's `speechSynthesis` for text-to-speech. No key ever reaches the browser; the UI
  shows which engine answered.
- **Auth**: email + phone signup, HS256 JWT in an httpOnly `finsight_session` cookie (jose). Cookie
  is `SameSite=None; Secure` on HTTPS origins and `Lax` only for plain-HTTP localhost so screenshots
  and local runs work. Preview iframe compatibility preserved.
- **i18n**: JSON dictionaries for all 11 languages (English source of truth), a `LanguageProvider`
  for client components and a server-side `getDictionary()`; AI output is generated natively in the
  selected language rather than translated after the fact.

## Architecture
```
app/                      routes; (app) group is the authenticated shell
  api/                    route handlers: auth, bank, transactions, forecast, budget,
                          simulator, alerts, coach, voice, business, goals, settings, export
components/
  ui/                     shadcn-style primitives on Radix
  shell/                  sidebar, top bar, mobile tab bar, floating mic
  charts/                 Recharts forecast band, donut, budget bars, health ring, runway gauge
  modals/                 Impulse Checkpoint, Anomaly review, Voice assistant
  views/                  page-level client views fed by server components
lib/
  prisma.ts auth.ts session.ts sarvam.ts ai.ts forecast.ts forecast-client.ts
  categorize.ts recurring.ts anomaly.ts limits.ts health.ts simulator.ts money.ts dates.ts
  i18n/  types.ts
prisma/schema.prisma  prisma/migrations/  scripts/seed.mjs
services/forecast/        FastAPI + pandas/numpy/statsmodels
```
Server components read Prisma directly and pass typed props to client views; every mutation goes
through a route handler that re-checks the session and returns the recomputed financial snapshot.

## Core mechanics
1. **Payment pipeline** `POST /api/bank/pay`: categorize → anomaly score → impulse guard. Returns
   `review` payloads with numbers and an explanation; `confirm: true` commits, writes the transaction,
   recomputes balance, creates alerts, and returns the voice-label prompt.
2. **Forecast**: daily net series → recurring obligations placed on due dates → variable spend by
   weekday mean/σ → income by persona (fixed salary, Bernoulli lump income, business daily sales) →
   1,000 Monte Carlo paths → p10/p50/p90, shortage probability, money-empty date, plain-language
   uncertainty. Backtest holds out the last 30 days and reports MAPE, MAE and band hit rate.
3. **Limits**: 50/30/20 baseline, reallocated by actual obligation load and persona, cut when a
   shortage is forecast inside 30 days, each row carrying a `reason`.
4. **Health score**: weighted savings rate, runway, obligation ratio, anomaly count, budget adherence.
5. **Voice**: MediaRecorder → `/api/voice/stt` (Sarvam or Whisper) → transcript stored as payee label
   / note + `VoiceLog`; TTS prefers Sarvam audio, falls back to browser speech synthesis.
6. **Demo Mode**: three seeded personas (6 months, ~250 transactions each, planted anomalies) with
   one-click login and buttons that fire a Swiggy impulse payment and a ₹48,000 unknown-payee payment.

## Design
The brief fixes the visual language, so it is used directly rather than re-invented.
- **Design movement**: modern Indian fintech — glassmorphic "money OS", soft aurora light, precise
  data typography.
- **Core principles**: numbers first; calm surfaces with one loud alarm colour; every insight is
  explainable; motion communicates state, never decorates.
- **Colour philosophy**: deep indigo `#4F46E5` as trust anchor, emerald `#10B981` for safety,
  amber/rose reserved strictly for caution/critical; `#0B1020` night canvas, `#F8FAFC` day canvas.
- **Layout**: a fixed 260px rail on desktop with an editorial content column (max 1240px), asymmetric
  card spans (7/5, 8/4) instead of a uniform grid; bottom tab bar on mobile.
- **Signature elements**: a thin aurora gradient hairline on every card, the confidence-band chart
  that "breathes" on load, and a pulsing rose halo on shortage states.
- **Interaction**: modal springs for the two guard moments; inline "Why?" disclosures everywhere.
- **Animation**: 180–320ms ease-out, count-up balances, chart draw-in, waveform while listening.
- **Typography**: Poppins 600 for headings, Inter for UI, tabular-nums for money, Noto Sans Indic
  families for the nine Indian scripts.
- **Brand essence**: the financial early-warning system for people whose income isn't a straight line.
  Calm, candid, local.
- **Voice**: short, direct, never salesy — "You have 11 days of runway." / "This is ₹2,340 over your
  food budget."
- **Wordmark**: "FinSight" in Poppins 600 with the dot of the "i" replaced by a rising emerald spark;
  mark is a rising line inside a rounded indigo square.
- **Signature colour**: indigo-violet `#4F46E5` with an emerald pulse.
