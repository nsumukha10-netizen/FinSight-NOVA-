"""Generate the ten Indic UI dictionaries from the English source with the built-in LLM."""
import json
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor

from openai import OpenAI

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MESSAGES = os.path.join(ROOT, "lib", "i18n", "messages")
MODEL = "gpt-6.1-sol"

TARGETS = {
    "hi": ("Hindi", "हिन्दी"),
    "kn": ("Kannada", "ಕನ್ನಡ"),
    "ta": ("Tamil", "தமிழ்"),
    "te": ("Telugu", "తెలుగు"),
    "ml": ("Malayalam", "മലയാളം"),
    "mr": ("Marathi", "मराठी"),
    "bn": ("Bengali", "বাংলা"),
    "gu": ("Gujarati", "ગુજરાતી"),
    "pa": ("Punjabi", "ਪੰਜਾਬੀ"),
    "or": ("Odia", "ଓଡ଼ିଆ"),
}

client = OpenAI()


def extract_json(text: str) -> dict:
    fenced = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    body = fenced.group(1) if fenced else text
    start, end = body.find("{"), body.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("no json object in response")
    return json.loads(body[start : end + 1])


def translate(code: str, english: dict) -> None:
    name, native = TARGETS[code]
    prompt = (
        f"Translate the values of this JSON object into {name} ({native}) for a fintech app UI. "
        "Keep every key unchanged and return a JSON object with exactly the same keys. "
        "Keep placeholders such as {n}, {amount}, {name}, {date}, {prob}, {days}, {score}, {grade}, "
        "{category}, {limit}, {spent}, {low}, {high}, {day}, {h}, {p}, {train}, {test}, {shop} exactly as they are. "
        "Keep product names FinSight, SIP, UPI, EMI, MAPE, MAE, WhatsApp, Netflix, Swiggy unchanged. "
        "Write natural, short, modern app copy in the target language — not a literal word-for-word translation. "
        "Use the target script throughout. Return only the JSON object.\n\n"
        + json.dumps(english, ensure_ascii=False)
    )
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are a professional product localiser for Indian languages."},
            {"role": "user", "content": prompt},
        ],
        max_completion_tokens=16000,
        extra_body={"reasoning": {"effort": "low"}},
    )
    text = response.choices[0].message.content or ""
    translated = extract_json(text)
    missing = [k for k in english if k not in translated or not str(translated[k]).strip()]
    for key in missing:
        translated[key] = english[key]
    ordered = {k: translated[k] for k in english}
    path = os.path.join(MESSAGES, f"{code}.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(ordered, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(f"{code}: {len(ordered)} keys, {len(missing)} fallbacks", flush=True)


def main() -> None:
    with open(os.path.join(MESSAGES, "en.json"), encoding="utf-8") as handle:
        english = json.load(handle)
    only = sys.argv[1:] or list(TARGETS)
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(translate, code, english) for code in only]
        for future in futures:
            future.result()


if __name__ == "__main__":
    main()
