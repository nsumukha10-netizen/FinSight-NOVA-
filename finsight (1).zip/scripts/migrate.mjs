import { spawnSync } from "node:child_process";

/**
 * The managed MySQL URL carries ssl={"rejectUnauthorized":true}, which the
 * Prisma CLI does not translate into a TLS handshake. Prisma 5 wants
 * sslaccept=strict instead, so normalize the URL for the migration process.
 */
function normalizeDatabaseUrl(url) {
  if (!url) return url;
  try {
    const parsed = new URL(url);
    if (parsed.searchParams.has("ssl")) {
      parsed.searchParams.delete("ssl");
      parsed.searchParams.set("sslaccept", "strict");
    }
    return parsed.toString();
  } catch {
    return url;
  }
}

const result = spawnSync("pnpm", ["prisma", "migrate", "deploy"], {
  stdio: "inherit",
  env: { ...process.env, DATABASE_URL: normalizeDatabaseUrl(process.env.DATABASE_URL) },
});

process.exit(result.status ?? 1);
