import { PrismaClient } from "@prisma/client";
import { execFileSync } from "node:child_process";

function normalizeDatabaseUrl(url) {
  if (!url) return url;
  try {
    const parsed = new URL(url);
    if (parsed.searchParams.has("ssl")) {
      parsed.searchParams.delete("ssl");
      parsed.searchParams.set("sslaccept", "strict");
    }
    return parsed.toString();
  } catch {
    return url;
  }
}

const prisma = new PrismaClient({
  datasourceUrl: normalizeDatabaseUrl(process.env.DATABASE_URL),
});

try {
  const users = await prisma.user.count();
  if (users === 0) {
    console.log("Empty database — seeding the three demo personas.");
    execFileSync("node", ["scripts/seed.mjs"], { stdio: "inherit", env: process.env });
  } else {
    console.log(`Seed skipped: ${users} user(s) already exist.`);
  }
} catch (error) {
  console.error("Seed check failed:", error.message);
  process.exitCode = 1;
} finally {
  await prisma.$disconnect();
}
