import { PrismaClient } from "@prisma/client";
import { DEMOS, seedDemoUser } from "../lib/demo-seed.mjs";

function normalizeDatabaseUrl(url) {
  if (!url) return url;
  try {
    const parsed = new URL(url);
    if (parsed.searchParams.has("ssl")) {
      parsed.searchParams.delete("ssl");
      parsed.searchParams.set("sslaccept", "strict");
    }
    return parsed.toString();
  } catch {
    return url;
  }
}

const prisma = new PrismaClient({ datasourceUrl: normalizeDatabaseUrl(process.env.DATABASE_URL) });
const ifEmpty = process.argv.includes("--if-empty");

async function main() {
  if (ifEmpty) {
    const count = await prisma.user.count({ where: { isDemo: true } });
    if (count > 0) {
      console.log(`Seed skipped: ${count} demo users already exist.`);
      return;
    }
  }
  await prisma.user.deleteMany({ where: { email: { in: DEMOS.map((d) => d.email) } } });
  for (const demo of DEMOS) {
    const result = await seedDemoUser(prisma, demo);
    console.log(`Seeded ${result.email} — ${result.transactions} transactions, closing balance ₹${result.balance}`);
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
