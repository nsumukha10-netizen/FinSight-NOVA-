"""
FinSight forecasting microservice.

Optional Python companion to the TypeScript engine. The Next.js app uses its
built-in engine by default; set FORECAST_SERVICE_URL=http://127.0.0.1:8001 to
route /api/forecast through this service instead.

Run:
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8001
"""

from __future__ import annotations

from datetime import date, timedelta
from statistics import mean, pstdev
from typing import Literal

import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="FinSight Forecast Service", version="1.0.0")


class Txn(BaseModel):
    date: date
    amount: float
    type: Literal["CREDIT", "DEBIT"]
    category: str = "Other"
    payee: str = ""


class Obligation(BaseModel):
    amount: float
    dueDay: int = Field(ge=1, le=31)


class ForecastRequest(BaseModel):
    balance: float
    transactions: list[Txn] = []
    obligations: list[Obligation] = []
    horizon: int = Field(default=30, ge=7, le=180)
    simulations: int = Field(default=1000, ge=100, le=5000)


def weekday_profile(transactions: list[Txn], today: date) -> list[float]:
    buckets: list[list[float]] = [[] for _ in range(7)]
    for txn in transactions:
        if txn.type != "DEBIT":
            continue
        if (today - txn.date).days > 120:
            continue
        buckets[txn.date.weekday()].append(txn.amount)
    overall = mean([value for bucket in buckets for value in bucket]) if any(buckets) else 500.0
    return [mean(bucket) if len(bucket) >= 3 else overall for bucket in buckets]


@app.get("/health")
def health() -> dict:
    return {"ok": True, "service": "finsight-forecast"}


@app.post("/forecast")
def forecast(request: ForecastRequest) -> dict:
    today = date.today()
    profile = weekday_profile(request.transactions, today)
    daily_sigma = 0.22
    rng = np.random.default_rng(7)
    paths = np.zeros((request.simulations, request.horizon + 1))
    paths[:, 0] = request.balance

    for sim in range(request.simulations):
        spend_factor = max(0.5, 1 + rng.normal() * daily_sigma)
        balance = request.balance
        for day in range(1, request.horizon + 1):
            current = today + timedelta(days=day)
            balance -= max(0.0, profile[current.weekday()] * spend_factor + rng.normal() * 40)
            for obligation in request.obligations:
                if current.day == min(obligation.dueDay, 28):
                    balance -= obligation.amount
            if current.day == 1:
                credits = [t.amount for t in request.transactions if t.type == "CREDIT" and t.category == "Income"]
                if credits:
                    balance += mean(credits) * max(0.8, 1 + rng.normal() * 0.06)
            if rng.random() < 0.018:
                balance -= rng.uniform(600, 3800)
            paths[sim, day] = balance

    p10 = np.percentile(paths, 10, axis=0)
    p50 = np.percentile(paths, 50, axis=0)
    p90 = np.percentile(paths, 90, axis=0)
    below_zero = (paths[:, 1:] < 0).any(axis=1)
    first_negative = np.argmax(paths[:, 1:] < 0, axis=1)
    shortage_probability = float(below_zero.mean())
    shortage_date = None
    if below_zero.any():
        median_day = int(np.median(first_negative[below_zero])) + 1
        shortage_date = (today + timedelta(days=median_day)).isoformat()

    return {
        "engine": "python-fastapi-montecarlo",
        "horizon": request.horizon,
        "simulations": request.simulations,
        "shortageProbability": shortage_probability,
        "shortageDate": shortage_date,
        "points": [
            {
                "date": (today + timedelta(days=index)).isoformat(),
                "p10": round(float(p10[index]), 2),
                "p50": round(float(p50[index]), 2),
                "p90": round(float(p90[index]), 2),
            }
            for index in range(request.horizon + 1)
        ],
        "drivers": {
            "dailySpendMean": round(mean(profile), 2),
            "dailySpendSigma": round(pstdev(profile), 2),
            "fixedMonthly": round(sum(o.amount for o in request.obligations), 2),
        },
    }
