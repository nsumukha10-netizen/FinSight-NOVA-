import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "hsl(var(--canvas))",
        surface: "hsl(var(--surface))",
        elevated: "hsl(var(--elevated))",
        line: "hsl(var(--line))",
        ink: "hsl(var(--ink))",
        muted: "hsl(var(--muted))",
        faint: "hsl(var(--faint))",
        brand: {
          DEFAULT: "#4F46E5",
          50: "#EEF0FF",
          100: "#E0E3FF",
          200: "#C6CBFF",
          300: "#A5AAFF",
          400: "#8480FA",
          500: "#4F46E5",
          600: "#4338CA",
          700: "#3730A3",
        },
        safe: "#10B981",
        caution: "#F59E0B",
        critical: "#EF4444",
      },
      fontFamily: {
        sans: ["Inter", "Noto Sans Devanagari", "Noto Sans Kannada", "Noto Sans Tamil", "Noto Sans Telugu", "Noto Sans Malayalam", "Noto Sans Bengali", "Noto Sans Gujarati", "Noto Sans Gurmukhi", "Noto Sans Oriya", "system-ui", "sans-serif"],
        display: ["Poppins", "Inter", "Noto Sans Devanagari", "Noto Sans Kannada", "Noto Sans Tamil", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl: "0.875rem",
        "2xl": "1.125rem",
        "3xl": "1.5rem",
      },
      boxShadow: {
        glass: "0 1px 0 0 rgba(255,255,255,0.06) inset, 0 18px 50px -24px rgba(2,6,23,0.75)",
        lift: "0 24px 70px -32px rgba(79,70,229,0.55)",
      },
      backgroundImage: {
        aurora:
          "radial-gradient(1200px 600px at 12% -10%, rgba(79,70,229,0.22), transparent 60%), radial-gradient(900px 500px at 92% 8%, rgba(16,185,129,0.14), transparent 55%)",
        hairline: "linear-gradient(90deg, rgba(79,70,229,0.9), rgba(16,185,129,0.65), transparent)",
      },
      keyframes: {
        "pulse-glow": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(239,68,68,0.45)" },
          "50%": { boxShadow: "0 0 0 14px rgba(239,68,68,0)" },
        },
        wave: {
          "0%, 100%": { transform: "scaleY(0.35)" },
          "50%": { transform: "scaleY(1)" },
        },
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-6px)" },
        },
      },
      animation: {
        "pulse-glow": "pulse-glow 2.4s ease-in-out infinite",
        wave: "wave 1s ease-in-out infinite",
        shimmer: "shimmer 1.8s infinite",
        float: "float 6s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
