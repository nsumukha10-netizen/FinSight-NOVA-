import { fail, json, requireApiUser } from "@/lib/api";
import { getFinanceSnapshot, financeContextText } from "@/lib/finance";
import { aiChat, coachSystemPrompt, offlineCoachReply } from "@/lib/ai";
import { isLang } from "@/lib/i18n";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

export async function POST(request: Request) {
  const auth = await requireApiUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const message = String(body.message ?? "").trim();
  if (!message) return fail("message_required");
  const language = isLang(String(body.language ?? "")) ? String(body.language) : user.language;

  const history = Array.isArray(body.history) ? (body.history as ChatTurn[]).slice(-8) : [];
  const snapshot = await getFinanceSnapshot(user.id);

  const result = await aiChat(
    [
      { role: "system", content: coachSystemPrompt(financeContextText(snapshot), language) },
      ...history.map((turn) => ({ role: turn.role, content: String(turn.content).slice(0, 2000) })),
      { role: "user", content: message.slice(0, 2000) },
    ],
    { maxTokens: 700, offline: offlineCoachReply(language) },
  );

  return json({
    reply: result.text || offlineCoachReply(user.language),
    engine: result.engine,
    disclaimer: "general_guidance",
  });
}
