"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, Info, X, XCircle } from "lucide-react";
import { getDictionary, makeT, type LangCode, type Translator } from "@/lib/i18n";
import { cn } from "@/lib/utils";

type Theme = "dark" | "light";

interface I18nValue {
  lang: LangCode;
  t: Translator;
  setLang: (lang: LangCode) => void;
}

interface ThemeValue {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggle: () => void;
}

type ToastKind = "success" | "error" | "info";
interface ToastItem {
  id: number;
  kind: ToastKind;
  title: string;
  description?: string;
}

interface ToastValue {
  toast: (t: { kind?: ToastKind; title: string; description?: string }) => void;
}

const I18nContext = React.createContext<I18nValue | null>(null);
const ThemeContext = React.createContext<ThemeValue | null>(null);
const ToastContext = React.createContext<ToastValue | null>(null);

export function useI18n(): I18nValue {
  const ctx = React.useContext(I18nContext);
  if (!ctx) throw new Error("useI18n outside provider");
  return ctx;
}

export function useTheme(): ThemeValue {
  const ctx = React.useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme outside provider");
  return ctx;
}

export function useToast(): ToastValue {
  const ctx = React.useContext(ToastContext);
  if (!ctx) throw new Error("useToast outside provider");
  return ctx;
}

export function AppProviders({
  children,
  initialLang,
  initialTheme,
}: {
  children: React.ReactNode;
  initialLang: LangCode;
  initialTheme: Theme;
}) {
  const router = useRouter();
  const [lang, setLangState] = React.useState<LangCode>(initialLang);
  const [theme, setThemeState] = React.useState<Theme>(initialTheme);
  const [toasts, setToasts] = React.useState<ToastItem[]>([]);

  const t = React.useMemo(() => makeT(getDictionary(lang)), [lang]);

  const setLang = React.useCallback(
    (next: LangCode) => {
      setLangState(next);
      document.documentElement.lang = next;
      document.cookie = `finsight_lang=${next};path=/;max-age=31536000;samesite=lax`;
      fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language: next }),
      }).catch(() => undefined);
      router.refresh();
    },
    [router],
  );

  const setTheme = React.useCallback((next: Theme) => {
    setThemeState(next);
    document.documentElement.classList.toggle("dark", next === "dark");
    document.cookie = `finsight_theme=${next};path=/;max-age=31536000;samesite=lax`;
    fetch("/api/settings/theme", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ theme: next }),
    }).catch(() => undefined);
  }, []);

  const toggle = React.useCallback(() => setTheme(theme === "dark" ? "light" : "dark"), [setTheme, theme]);

  const toast = React.useCallback((item: { kind?: ToastKind; title: string; description?: string }) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-2), { id, kind: item.kind ?? "info", title: item.title, description: item.description }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);

  return (
    <I18nContext.Provider value={{ lang, t, setLang }}>
      <ThemeContext.Provider value={{ theme, setTheme, toggle }}>
        <ToastContext.Provider value={{ toast }}>
          {children}
          <div className="pointer-events-none fixed bottom-24 right-4 z-[90] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2 sm:bottom-6">
            <AnimatePresence>
              {toasts.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 14, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.98 }}
                  transition={{ duration: 0.22, ease: "easeOut" }}
                  className={cn(
                    "pointer-events-auto flex items-start gap-3 rounded-xl border p-3.5 shadow-2xl backdrop-blur-xl",
                    item.kind === "success" && "border-emerald-500/30 bg-emerald-500/10",
                    item.kind === "error" && "border-rose-500/30 bg-rose-500/10",
                    item.kind === "info" && "border-line bg-surface/95",
                  )}
                >
                  <span className="mt-0.5">
                    {item.kind === "success" && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
                    {item.kind === "error" && <XCircle className="h-4 w-4 text-rose-400" />}
                    {item.kind === "info" && <Info className="h-4 w-4 text-brand-300" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-medium text-ink">{item.title}</p>
                    {item.description && <p className="mt-0.5 text-xs leading-relaxed text-muted">{item.description}</p>}
                  </div>
                  <button
                    onClick={() => setToasts((prev) => prev.filter((t) => t.id !== item.id))}
                    className="text-faint transition-colors hover:text-ink"
                    aria-label="Dismiss"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </ToastContext.Provider>
      </ThemeContext.Provider>
    </I18nContext.Provider>
  );
}
