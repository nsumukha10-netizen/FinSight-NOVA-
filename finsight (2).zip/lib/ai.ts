import { sarvamChat, sarvamEnabled, type SarvamMessage } from "@/lib/sarvam";

export type AIMessage = SarvamMessage;

export interface AIResult {
  text: string;
  engine: "sarvam" | "platform" | "offline";
}

const PLATFORM_MODEL = process.env.AI_MODEL || "gpt-5-mini";

export const LANGUAGE_NAME: Record<string, string> = {
  en: "English",
  hi: "Hindi",
  kn: "Kannada",
  ta: "Tamil",
  te: "Telugu",
  ml: "Malayalam",
  mr: "Marathi",
  bn: "Bengali",
  gu: "Gujarati",
  pa: "Punjabi",
  or: "Odia",
};

async function platformChat(messages: AIMessage[], maxTokens: number): Promise<string> {
  const base = process.env.MANUS_API_URL;
  const key = process.env.MANUS_API_KEY;
  if (!base || !key) throw new Error("platform_ai_unavailable");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30_000);
  try {
    const res = await fetch(`${base}/v1/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: PLATFORM_MODEL,
        messages,
        max_completion_tokens: maxTokens,
      }),
    });
    const data = (await res.json()) as {
      error?: { message?: string };
      choices?: { message?: { content?: string } }[];
    };
    if (data.error) throw new Error(data.error.message ?? "platform_ai_error");
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("platform_ai_empty");
    return text;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Sarvam first (when configured), then the platform's built-in model, then a caller
 * supplied offline string. Never throws.
 */
export async function aiChat(
  messages: AIMessage[],
  opts: { maxTokens?: number; offline?: string } = {},
): Promise<AIResult> {
  const maxTokens = opts.maxTokens ?? 700;
  if (sarvamEnabled()) {
    try {
      return { text: await sarvamChat(messages, { maxTokens }), engine: "sarvam" };
    } catch {
      /* fall through */
    }
  }
  try {
    return { text: await platformChat(messages, maxTokens), engine: "platform" };
  } catch {
    return { text: opts.offline ?? "", engine: "offline" };
  }
}

function stripFence(text: string): string {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced ? fenced[1] : text;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  return start >= 0 && end > start ? body.slice(start, end + 1) : body;
}

export async function aiJson<T>(messages: AIMessage[], fallback: T): Promise<{ data: T; engine: AIResult["engine"] }> {
  const result = await aiChat(messages, { maxTokens: 500 });
  if (!result.text) return { data: fallback, engine: result.engine };
  try {
    return { data: JSON.parse(stripFence(result.text)) as T, engine: result.engine };
  } catch {
    return { data: fallback, engine: result.engine };
  }
}

export function coachSystemPrompt(context: string, language: string): string {
  return [
    "You are FinSight's money coach for Indian users. You are warm, concrete and brief (max 120 words unless asked for a plan).",
    `Always reply ONLY in ${LANGUAGE_NAME[language] ?? "English"} using that language's native script. Do not use English, transliteration, or mixed-language text unless the user explicitly asks for translation.`,
    "Use rupees and Indian examples (UPI, SIP, emergency fund, PPF, recurring deposits).",
    "Never guarantee returns, never present stock tips as certainties, and never recommend a specific regulated product as advice.",
    "End with one short line: 'This is general guidance, not regulated financial advice.' in the user's language.",
    "Here is the user's live financial snapshot:",
    context,
  ].join("\n");
}

export function offlineCoachReply(language: string): string {
  const replies: Record<string, string> = {
    en: "I can't reach the AI service right now, but here is the safe move: keep this month's fixed bills aside first, then cap discretionary spending at the smallest category limit on your Budget page. This is general guidance, not regulated financial advice.",
    hi: "अभी AI सेवा उपलब्ध नहीं है। सुरक्षित कदम: पहले इस महीने के तय बिल अलग रखें, फिर बजट पेज पर सबसे छोटी श्रेणी की सीमा तक ही खर्च करें। यह सामान्य मार्गदर्शन है, नियामकीय वित्तीय सलाह नहीं।",
    kn: "ಈಗ AI ಸೇವೆಯನ್ನು ಸಂಪರ್ಕಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತಿಲ್ಲ. ಸುರಕ್ಷಿತ ಕ್ರಮ: ಮೊದಲು ಈ ತಿಂಗಳ ನಿಗದಿತ ಬಿಲ್‌ಗಳಿಗೆ ಹಣವನ್ನು ಬೇರ್ಪಡಿಸಿ, ನಂತರ ಬಜೆಟ್ ಪುಟದಲ್ಲಿರುವ ಕಡಿಮೆ ಮಿತಿಯೊಳಗೆ ಐಚ್ಛಿಕ ಖರ್ಚು ಮಾಡಿ. ಇದು ಸಾಮಾನ್ಯ ಮಾರ್ಗದರ್ಶನ ಮಾತ್ರ, ನಿಯಂತ್ರಿತ ಹಣಕಾಸು ಸಲಹೆಯಲ್ಲ.",
    ta: "தற்போது AI சேவையை அணுக முடியவில்லை. பாதுகாப்பான வழி: முதலில் இந்த மாத நிலையான கட்டணங்களுக்கு பணத்தை ஒதுக்கி, பின்னர் பட்ஜெட் பக்கத்தில் உள்ள குறைந்த வரம்புக்குள் விருப்பச் செலவுகளை வைத்திருங்கள். இது பொதுவான வழிகாட்டுதல் மட்டுமே; ஒழுங்குபடுத்தப்பட்ட நிதி ஆலோசனை அல்ல.",
    te: "ప్రస్తుతం AI సేవను చేరుకోలేకపోతున్నాను. సురక్షితమైన మార్గం: ముందుగా ఈ నెల స్థిర బిల్లుల కోసం డబ్బు పక్కన పెట్టి, తర్వాత బడ్జెట్ పేజీలోని తక్కువ పరిమితిలో ఐచ్ఛిక ఖర్చులను ఉంచండి. ఇది సాధారణ మార్గదర్శకం మాత్రమే, నియంత్రిత ఆర్థిక సలహా కాదు.",
    ml: "ഇപ്പോൾ AI സേവനവുമായി ബന്ധപ്പെടാൻ കഴിയുന്നില്ല. സുരക്ഷിതമായ നടപടി: ആദ്യം ഈ മാസത്തെ സ്ഥിരബില്ലുകൾക്കായി പണം മാറ്റിവെക്കുക, തുടർന്ന് ബജറ്റ് പേജിലെ ഏറ്റവും കുറഞ്ഞ പരിധിക്കുള്ളിൽ ഐച്ഛിക ചെലവുകൾ നിയന്ത്രിക്കുക. ഇത് പൊതുവായ മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്; നിയന്ത്രിത സാമ്പത്തിക ഉപദേശം അല്ല.",
    mr: "सध्या AI सेवेशी संपर्क होऊ शकला नाही. सुरक्षित पाऊल: आधी या महिन्याची ठरलेली बिले बाजूला ठेवा आणि नंतर बजेट पेजवरील सर्वात कमी मर्यादेत ऐच्छिक खर्च ठेवा. हे सामान्य मार्गदर्शन आहे, नियमनबद्ध आर्थिक सल्ला नाही.",
    bn: "এই মুহূর্তে AI পরিষেবায় পৌঁছানো যাচ্ছে না। নিরাপদ পদক্ষেপ: আগে এই মাসের নির্দিষ্ট বিলের টাকা আলাদা রাখুন, তারপর বাজেট পৃষ্ঠার সবচেয়ে কম সীমার মধ্যে ইচ্ছাধীন খরচ রাখুন। এটি সাধারণ নির্দেশনা, নিয়ন্ত্রিত আর্থিক পরামর্শ নয়।",
    gu: "હમણાં AI સેવા ઉપલબ્ધ નથી. સુરક્ષિત પગલું: પહેલાં આ મહિનાના નક્કી બિલ માટે પૈસા અલગ રાખો, પછી બજેટ પેજની સૌથી ઓછી મર્યાદામાં વૈકલ્પિક ખર્ચ રાખો. આ સામાન્ય માર્ગદર્શન છે, નિયંત્રિત નાણાકીય સલાહ નથી.",
    pa: "ਇਸ ਵੇਲੇ AI ਸੇਵਾ ਨਾਲ ਸੰਪਰਕ ਨਹੀਂ ਹੋ ਰਿਹਾ। ਸੁਰੱਖਿਅਤ ਕਦਮ: ਪਹਿਲਾਂ ਇਸ ਮਹੀਨੇ ਦੇ ਨਿਸ਼ਚਿਤ ਬਿੱਲਾਂ ਲਈ ਪੈਸਾ ਵੱਖ ਰੱਖੋ, ਫਿਰ ਬਜਟ ਪੰਨੇ ਦੀ ਸਭ ਤੋਂ ਘੱਟ ਹੱਦ ਵਿੱਚ ਗੈਰ-ਜ਼ਰੂਰੀ ਖਰਚ ਰੱਖੋ। ਇਹ ਆਮ ਮਾਰਗਦਰਸ਼ਨ ਹੈ, ਨਿਯਮਤ ਵਿੱਤੀ ਸਲਾਹ ਨਹੀਂ।",
    or: "ବର୍ତ୍ତମାନ AI ସେବାକୁ ପହଞ୍ଚି ପାରୁନାହିଁ। ସୁରକ୍ଷିତ ପଦକ୍ଷେପ: ପ୍ରଥମେ ଏହି ମାସର ନିର୍ଦ୍ଧାରିତ ବିଲ ପାଇଁ ଟଙ୍କା ଅଲଗା ରଖନ୍ତୁ, ପରେ ବଜେଟ ପୃଷ୍ଠାର ସବୁଠାରୁ କମ ସୀମା ମଧ୍ୟରେ ଇଚ୍ଛାଧୀନ ଖର୍ଚ୍ଚ ରଖନ୍ତୁ। ଏହା ସାଧାରଣ ମାର୍ଗଦର୍ଶନ, ନିୟନ୍ତ୍ରିତ ଆର୍ଥିକ ପରାମର୍ଶ ନୁହେଁ।",
  };
  return replies[language] ?? replies.en;
}
